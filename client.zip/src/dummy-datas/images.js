// importing header images and icons
import truckIcon from '../assets/icons/header/truck.png';
import arrowDownIcon from '../assets/icons/header/arrow-down.png';
import phoneIcon from '../assets/icons/header/phone.png';
import profileIcon from '../assets/icons/header/profile.png';
import usaFlagIcon from '../assets/icons/header/usa-flag.png';
import franceFlagIcon from '../assets/icons/header/france-flag.png';
// importing nav images and icons
import logoIcon from '../assets/icons/nav/logo.png';
import blackArrowIcon from '../assets/icons/nav/black-arrow.png';
import shoppingCartIcon from '../assets/icons/nav/cart.png';
import shoppingCartIconW from '../assets/icons/nav/cartW.png';
import balanceIcon from '../assets/icons/nav/balance.png';
import balanceIconW from '../assets/icons/nav/balanceW.png';
import facebookIcon from '../assets/icons/nav/facebook.png';
import instagramIcon from '../assets/icons/nav/instagram.png';
import youtubeIcon from '../assets/icons/nav/youtube.png';
import twitterIcon from '../assets/icons/nav/twitter.png';
import heartIcon from '../assets/icons/nav/heart.png';
import heartIconW from '../assets/icons/nav/heartW.png';
// importing footer images and icons
import logoFooterIcon from '../assets/icons/footer/logo-footer.png';
import dutyFreeIcon from '../assets/icons/footer/duty-free.png';
import klarnaIcon from '../assets/icons/footer/klarna.png';
import leftArrowIcon from '../assets/icons/footer/left-arrow.png';
import locationIcon from '../assets/icons/footer/location.png';
import mailIcon from '../assets/icons/footer/mail.png';
import phoneFooterIcon from '../assets/icons/footer/phone-footer.png';
import payBrightIcon from '../assets/icons/footer/pay-bright.png';
import payPalIcon from '../assets/icons/footer/pay-pal.png';
import visaCardIcon from '../assets/icons/footer/visa-card.png';
import americanExpressIcon from '../assets/icons/footer/american-express.png';
import masterCardIcon from '../assets/icons/footer/master-card.png';
// importing home main-part icons
import arrowPrizeIcon from '../assets/icons/main/home/arrow-prize.png';
import bateryIcon from '../assets/icons/main/home/batery.png';
import currusIcon from '../assets/icons/main/home/currus.png';
import downOrangeArrowIcon from '../assets/icons/main/home/down-orange-arrow.png';
import heartBlackBorderIcon from '../assets/icons/main/home/heart-black-border.png';
import heartRedBgIcon from '../assets/icons/main/home/heart-red-bg.png';
import heartRedBorderIcon from '../assets/icons/main/home/heart-red-border.png';
import heartWhiteBorderIcon from '../assets/icons/main/home/heart-white-border.png';
import immotionIcon from '../assets/icons/main/home/immotion.png';
import instagramBigIcon from '../assets/icons/main/home/instagram-big.png';
import kingSongIcon from '../assets/icons/main/home/king-song.png';
import rightBlackArrowIcon from '../assets/icons/main/home/right-black-arrow.png';
import leafIcon from '../assets/icons/main/home/leaf.png';
import leftWhiteArrowIcon from '../assets/icons/main/home/left-white-arrow.png';
import miniMotorsIcon from '../assets/icons/main/home/minitors.png';
import moneyPrizeIcon from '../assets/icons/main/home/money-prize.png';
import onePrizeIcon from '../assets/icons/main/home/one-prize.png';
import rightOrangeSmallArrowIcon from '../assets/icons/main/home/right-orange-small-arrow.png';
import rightRedArrowIcon from '../assets/icons/main/home/right-red-arrow.png';
import rightRedBigArrowIcon from '../assets/icons/main/home/right-red-big-arrow.png';
import rightWhiteArrowIcon from '../assets/icons/main/home/right-white-arrow.png';
import rollerIcon from '../assets/icons/main/home/roller.png';
import scheduleIcon from '../assets/icons/main/home/schedule.png';
import segWayIcon from '../assets/icons/main/home/segway.png';
import speedIcon from '../assets/icons/main/home/speed.png';
import starOrangeBgIcon from '../assets/icons/main/home/star-orange-bg.png';
import starOrangeBorderIcon from '../assets/icons/main/home/star-orange-border.png';
import starOrangePeaceOfBgIcon from '../assets/icons/main/home/star-orange-peace-of-bg.png';
import tickInCircleIcon from '../assets/icons/main/home/tick-in-circle.png';
import tickPrizeIcon from '../assets/icons/main/home/tick-prize.png';
import upBlackArrowIcon from '../assets/icons/main/home/up-black-arrow.png';
import wepedsIcon from '../assets/icons/main/home/wepeds.png'; 
// importing home main-part images
import wheelImage from '../assets/images/main/home/prod-1.png';
import scooterImage from '../assets/images/main/home/prod-2.png';
import skateImage from '../assets/images/main/home/prod-3.png';
import sportBagImage from '../assets/images/main/home/prod-4.png';
import bestSellerImage from '../assets/images/main/home/prod-5.png';
import twoScootersImage from '../assets/images/main/home/prod-6.png';
import twoVirtualsImage from '../assets/images/main/home/prod-7.png';
import playerImage from '../assets/images/main/home/prod-8.png';
import s18Image from '../assets/images/main/home/prod-9.png';
import l8fImage from '../assets/images/main/home/prod-10.png';
import freeMotionImage from '../assets/images/main/home/prod-11.png';
import girlOnBikeImage from '../assets/images/main/home/prod-12.png';
import productsBgImage from '../assets/images/main/home/prod-13.png';
import manOnBikeImage from '../assets/images/main/home/prod-14.png';
import mmanOnMotorbikeImage from '../assets/images/main/home/prod-15.png';
import blackScooterImage from '../assets/images/main/home/prod-17.png';
import prod18Image from '../assets/images/main/home/prod-18.png';
import prod19Image from '../assets/images/main/home/prod-19.png';
import girlWithHelmetImage from '../assets/images/main/home/prod-20.png';
import girlInRedImage from '../assets/images/main/home/prod-21.png';
import girlWithGlassesImage from '../assets/images/main/home/prod-22.png';
import e_scooterImage from '../assets/images/main/home/prod-23.png';
import scooterAtTheStreetImage from '../assets/images/main/home/prod-24.png';
// importing nav icons after hover
import scooterIcon from '../assets/icons/nav/hover/scooter.png';
import skateboardIcon from '../assets/icons/nav/hover/skateboard.png';
import unicycleIcon from '../assets/icons/nav/hover/unicycle.png';
import wheelIcon from '../assets/icons/nav/hover/wheel.png';
import currusHoverIcon from '../assets/icons/nav/hover/currus.png';
import gwIcon from '../assets/icons/nav/hover/GW.png';
import inmotionIcon from '../assets/icons/nav/hover/inmotion.png';
import kingsongIcon from '../assets/icons/nav/hover/kingsong.png';
import minimotorsIcon from '../assets/icons/nav/hover/minimotors.png';
import segwayIcon from '../assets/icons/nav/hover/segway.png';
import wepedzIcon from '../assets/icons/nav/hover/wepedz.png';
import truckHoverIcon from '../assets/icons/nav/hover/truck.png';
import phoneHoverIcon from '../assets/icons/nav/hover/phone.png';
// importing products page images and icons
import newLabel from '../assets/icons/main/products/new.png';
import orangeBorderCartIcon from '../assets/icons/main/products/cart-orange-border.png';
import orangeBGCartIcon from '../assets/icons/main/products/cart-orange-bg.png';
import blackCompareIcon from '../assets/icons/main/products/balance-small.png';
import orangeCompareIcon from '../assets/icons/main/products/balance-orange.png';
import blackHeartIcon from '../assets/icons/main/products/heart-small-black.png';
import orangeHeartIcon from '../assets/icons/main/products/heart-orange.png';
import previousArrowIcon from '../assets/icons/main/products/left-arrow.png';
import nextArrowIcon from '../assets/icons/main/products/right-arrow.png';
import resetItemIcon from '../assets/icons/main/products/reset-icon.png';
// importing single product page images and icons
import eUnicycleImage from '../assets/images/main/single-product/e-Unicycle.png';
import eUnicyclesImage from '../assets/images/main/single-product/e-Unicycles.png';
import image_1 from '../assets/images/main/single-product/img-1.png';
import image_2 from '../assets/images/main/single-product/img-2.png';
import image_3 from '../assets/images/main/single-product/img-3.png';
import image_4 from '../assets/images/main/single-product/img-4.png';
import image_5 from '../assets/images/main/single-product/img-5.png';
import image_6 from '../assets/images/main/single-product/img-6.png';
import veteranImage from '../assets/images/main/single-product/veteran.png';
import wheel_image from '../assets/images/main/single-product/wheel.png';
import copy_icon from '../assets/icons/main/single-product/copy.png';
import duty_free_icon from '../assets/icons/main/single-product/duty-free.png';
import klarna_icon from '../assets/icons/main/single-product/klarna.png';
import pay_bright_icon from '../assets/icons/main/single-product/pay-bright.png';
import play_butn_icon from '../assets/icons/main/single-product/play-butn.png';
import share_icon from '../assets/icons/main/single-product/share.png';
import tick_icon from '../assets/icons/main/single-product/tick.png';
import vector_down_icon from '../assets/icons/main/single-product/vector-down.png';
import vector_up_icon from '../assets/icons/main/single-product/vector-up.png';
import minus_icon from '../assets/icons/main/single-product/minus.png';
import plus_icon from '../assets/icons/main/single-product/plus.png';
import tick_prize_icon from '../assets/icons/main/home/tick-prize.png';
import arrow_prize_icon from '../assets/icons/main/home/arrow-prize.png';
import one_prize_icon from '../assets/icons/main/home/one-prize.png';
import money_prize_icon from '../assets/icons/main/home/money-prize.png';
// importing modals icons and images 
import yellowStarIcon from '../assets/icons/modals/star-yellow.png';
import grayStarIcon from '../assets/icons/modals/star-gray.png';



// exporting header images and icons
export const headerImages = {
    truckIcon,
    arrowDownIcon,
    phoneIcon,
    profileIcon,
    usaFlagIcon,
    franceFlagIcon,
};

// exporting nav images andicons
export const navImages = {
    logoIcon,
    balanceIcon,
    balanceIconW,
    blackArrowIcon,
    shoppingCartIcon,
    shoppingCartIconW,
    facebookIcon,
    instagramIcon,
    youtubeIcon,
    twitterIcon,
    heartIcon,
    heartIconW,
};

// exporting footer images and icons
export const footerImages = {
    logoFooterIcon,
    dutyFreeIcon,
    klarnaIcon,
    leftArrowIcon,
    locationIcon,
    phoneFooterIcon,
    payBrightIcon,
    mailIcon,
    facebookIcon,
    instagramIcon,
    youtubeIcon,
    twitterIcon,
    payPalIcon,
    visaCardIcon,
    masterCardIcon,
    americanExpressIcon,
};

// exporting home main-part icons
export const homeMainIcons = {
    arrowPrizeIcon,
    bateryIcon,
    currusIcon,
    downOrangeArrowIcon,
    heartBlackBorderIcon,
    heartRedBgIcon,
    heartRedBorderIcon,
    heartWhiteBorderIcon,
    immotionIcon,
    instagramBigIcon,
    kingSongIcon,
    rightBlackArrowIcon,
    leafIcon,
    leftWhiteArrowIcon,
    miniMotorsIcon,
    moneyPrizeIcon, 
    rightOrangeSmallArrowIcon,
    rightRedArrowIcon,
    rightRedBigArrowIcon,
    rightWhiteArrowIcon,
    rollerIcon,
    scheduleIcon, 
    segWayIcon,
    speedIcon,
    starOrangeBgIcon,
    starOrangeBorderIcon,
    starOrangePeaceOfBgIcon,
    tickInCircleIcon,
    tickPrizeIcon,
    upBlackArrowIcon,
    wepedsIcon,
    onePrizeIcon,
};

// exporting home main-part images
export const homeMainImages = {
    wheelImage,
    scooterImage,
    skateImage,
    sportBagImage,
    bestSellerImage,
    twoScootersImage,
    twoVirtualsImage,
    playerImage,
    s18Image,
    l8fImage,
    freeMotionImage,
    girlOnBikeImage,
    productsBgImage,
    manOnBikeImage,
    mmanOnMotorbikeImage,
    blackScooterImage,
    prod18Image,
    prod19Image,
    girlWithHelmetImage,
    girlInRedImage,
    girlWithGlassesImage,
    e_scooterImage,
    scooterAtTheStreetImage,
};

// exporting nav icons after hover
export const navHoverIcons = {
    scooterIcon,
    skateboardIcon,
    wheelIcon,
    unicycleIcon,
    currusHoverIcon,
    gwIcon,
    wepedzIcon,
    minimotorsIcon,
    segwayIcon,
    kingsongIcon,
    inmotionIcon,
    truckHoverIcon,
    phoneHoverIcon,
}; 

// exporting products page images and icons
export const productsMainImages = {
    newLabel,
    orangeBorderCartIcon,
    orangeBGCartIcon,
    blackCompareIcon,
    orangeCompareIcon,
    blackHeartIcon,
    orangeHeartIcon,
    previousArrowIcon,
    nextArrowIcon,
    resetItemIcon,
}; 

// exporting single product page images and icons
export const singleProductImages = {
    eUnicycleImage,
    eUnicyclesImage,
    image_1,
    image_2,
    image_3,
    image_4,
    image_5,
    image_6,
    veteranImage,
    wheel_image,
    copy_icon,
    duty_free_icon,
    klarna_icon,
    pay_bright_icon,
    play_butn_icon,
    share_icon,
    tick_icon,
    vector_down_icon,
    vector_up_icon,
    minus_icon,
    plus_icon,
    tick_prize_icon,
    arrow_prize_icon,
    one_prize_icon,
    money_prize_icon,
};  

export const modalsImagesAndIcons = {
    yellowStarIcon,
    grayStarIcon,
};