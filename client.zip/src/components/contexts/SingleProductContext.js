import React, { useState } from 'react'

export const PassingSingleProduct = React.createContext({
  singleProduct: {},
  passSingleProduct: () => {},
})

const SingleProductContext = ({ children }) => {
  const [product, setProduct] = useState({})

  const passProductHandler = (product) => {
    setProduct(product)
  }

  return (
    <PassingSingleProduct.Provider
      value={{
        singleProduct: product,
        passSingleProduct: passProductHandler,
      }}
    >
      {children}
    </PassingSingleProduct.Provider>
  )
}

export default SingleProductContext
