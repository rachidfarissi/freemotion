import React, { useEffect, useState } from 'react'
import './discountedProductComponent.scss'
import DiscountedProducts from '../items/home-page/DiscountedProducts'
import axios from 'axios'

import OWLcorusel from 'react-owl-carousel'
import 'owl.carousel/dist/assets/owl.carousel.min.css'
import 'owl.carousel/dist/assets/owl.theme.default.min.css'

function DiscountedProductComponent() {
  let url = 'https://freemotion-shop-back.herokuapp.com'

  const [data, setData] = useState([])

  useEffect(() => {
    axios
      .get(`${url}/product/get/three`)
      .then((res) => setData(res.data.product))
      .catch((e) => console.log(e))
  }, [])

  return (
    <>
      <div className="ecommerce-home__discounted-products">
        {data &&
          data.map((product, index) => (
            <DiscountedProducts
              product={product}
              key={product.id}
              index={index}
            />
          ))}
      </div>
      <div className="discounted-products__slider">
        {data && data.length > 0 && (
          <OWLcorusel items="1" center autoplayHoverPause dots loop margin={6}>
            {data.map((product, index) => (
              <DiscountedProducts
                product={product}
                key={product.id}
                index={index}
              />
            ))}
          </OWLcorusel>
        )}
      </div>
    </>
  )
}

export default DiscountedProductComponent
