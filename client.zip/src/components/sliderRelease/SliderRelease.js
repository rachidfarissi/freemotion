import React, { useState, useEffect } from 'react'
import './sliderRelease.scss'
import NewReleaseProducts from "../items/home-page/NewReleaseProducts";
import axios from 'axios';
// import SliderButtons from "../";


import OWLcorusel from 'react-owl-carousel'
import 'owl.carousel/dist/assets/owl.carousel.min.css'
import 'owl.carousel/dist/assets/owl.theme.default.min.css'




const options = {
    responsive: {
        0: {
            items: 1,
        },
        400: {
            items: 1,
        },
        650: {
            items: 2,
        },
        1000: {
            items: 3,
  
        }
    },
  };
  

  

function SliderRelease({title}) {
    let url = 'https://freemotion-shop-back.herokuapp.com'

    const [data, setData] = useState([])
    
    useEffect(() => {
        axios.get(`${url}/product/new/release`)
        .then(res => setData(res.data.new_release))
        .catch(e => console.log(e))
    
    },[url])


    console.log(data);
    // { NEW_RELEASED_PRODUCTS.map((product) => <NewReleaseProducts  product={ product } key={ product.id } />) }
    return(
        <div className="slider-release">
            <div className="slider-release__container wrapper">
                <div className="new-release__slider-actions">
                    <h2 className="new-release__title"> {title} </h2>
                    {/* <SliderButtons className="new-release__slider-btns" /> */}
                </div>
                <div className='slider'>
                   { data.length > 0 && <OWLcorusel  items='3'   center autoplayHoverPause dots loop  margin={6}  responsive={options.responsive} >
                        {data.map((product) => <NewReleaseProducts  product={ product } key={ product.id } />) }
                    </OWLcorusel>
                    }
                </div>
                {/* <div className="new-release__products">
                    { NEW_RELEASED_PRODUCTS.map((product) => <NewReleaseProducts  product={ product } key={ product.id } />) }
                </div>   */}
            </div>
        </div>
    )
}

export default SliderRelease