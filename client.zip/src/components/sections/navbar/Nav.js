import React, { useState, useEffect } from 'react'
import { headerImages } from '../../../dummy-datas/images'
import { Link, NavLink } from 'react-router-dom'
import './Nav.scss'
import axios from 'axios'
import { navImages } from '../../../dummy-datas/images'
import DropdownCard from '../../UI/cards/DropdownCard'
import LightButton from '../../UI/buttons/LightButton'
import HoverCard from '../../UI/cards/HoverCard'
import NavFilterButton from '../../UI/buttons/NavFilterButton'
import {
  FILTERED_PRODUCTS,
  FILTERED_DEALS,
} from '../../../dummy-datas/dummyDatas'
import Search from '../../searchInput/Search'
import { url } from '../../../configs/config'
import { useHistory } from 'react-router'

const Nav = () => {
  const [chosenLanguage, setChosenLanguage] = useState('English')
  const [chosenCurrency, setChosenCurrency] = useState('(USD) US Dollar')
  console.log(FILTERED_DEALS, 'www')
  const [dataBrands, setDataBrands] = useState([])
  const token = localStorage.getItem('token') && localStorage.getItem('token')
  const history = useHistory()

  useEffect(() => {
    axios
      .get(`${url}/brand/list/brand`)
      .then((res) => setDataBrands(res.data.brand_list))
      .catch((e) => console.log(e))
  }, [])

  // console.log(dataBrands , '777')

  return (
    <header className="ecommerce-header">
      <section className="ecommerce-header__container">
        <div className="ecommerce-header__free-shipping">
          <div className="free-shipping__icon">
            <img src={headerImages.truckIcon} alt="truck" />
          </div>
          <h3 className="free-shipping__text">
            {' '}
            FREE SHIPPING from Los Angels across USA & CANADA{' '}
          </h3>
        </div>
        <div className="ecommerce-header__menu-container">
          <div className="ecommerce-header__menu mobile__menu">
            <ul className="menu-list">
              <li>
                {' '}
                <NavLink to="/about-us" className="menu-list__about-us">
                  {' '}
                  About Us{' '}
                </NavLink>{' '}
              </li>
              <li>
                {' '}
                <NavLink to="/blog" className="menu-list__blog">
                  {' '}
                  Blog{' '}
                </NavLink>{' '}
              </li>
              <li>
                {' '}
                <NavLink to="/financing" className="menu-list__financing">
                  {' '}
                  Financing{' '}
                </NavLink>{' '}
              </li>
              <li>
                {' '}
                <NavLink to="/support" className="menu-list__support">
                  {' '}
                  Support{' '}
                </NavLink>{' '}
              </li>
            </ul>
          </div>
          <div className="ecommerce-header__currency mobile__menu">
            {/* some logic here will be added later */}
            <div className="ecommerce-header__currency-container ">
              <div className="currency__icon">
                <img src={headerImages.usaFlagIcon} alt="USA flag" />
              </div>
              <div className="currency__text-box">
                <h3 className="currency__text"> / USD $ </h3>
                <i />
              </div>
            </div>
            <div className="language-and-currency">
              <form
                action="/"
                className="language-and-currency__container"
                id="language_and_currency"
                onSubmit={(event) => event.preventDefault()}
              >
                <h6 className="language-and-currency__title"> Language </h6>
                <DropdownCard className="dropdown-card__language">
                  <div className="language">
                    <div className="language__icon">
                      <img
                        src={
                          chosenLanguage === 'English'
                            ? headerImages.usaFlagIcon
                            : headerImages.franceFlagIcon
                        }
                        alt="USA flag"
                      />
                    </div>
                    <p className="language__title"> {chosenLanguage} </p>
                  </div>
                  <i className="language__arrow-icon" />
                  <div className="dropdown-card__language-option">
                    <label
                      htmlFor="english"
                      className={`dropdown-card__english ${
                        chosenLanguage === 'English' && 'active'
                      }`}
                    >
                      <div className="language">
                        <div className="language__icon">
                          <img src={headerImages.usaFlagIcon} alt="USA flag" />
                        </div>
                        <p className="language__title"> English </p>
                      </div>
                    </label>
                    <input
                      type="radio"
                      name="lang"
                      id="english"
                      className="option-input"
                      onChange={(event) =>
                        setChosenLanguage(event.target.checked && 'English')
                      }
                    />
                    <label
                      htmlFor="french"
                      className={`dropdown-card__franch ${
                        chosenLanguage === 'French' && 'active'
                      }`}
                    >
                      <div className="language">
                        <div className="language__icon">
                          <img
                            src={headerImages.franceFlagIcon}
                            alt="France flag"
                          />
                        </div>
                        <p className="language__title"> French </p>
                      </div>
                    </label>
                    <input
                      type="radio"
                      name="lang"
                      id="french"
                      className="option-input"
                      onChange={(event) =>
                        setChosenLanguage(event.target.checked && 'French')
                      }
                    />
                  </div>
                </DropdownCard>
                <h6 className="language-and-currency__title"> Currency </h6>
                <DropdownCard className="dropdown-card__currency">
                  <p className="currency__title"> {chosenCurrency} </p>
                  <i className="currency__arrow-icon" />
                  <div className="dropdown-card__currency-option">
                    <label
                      htmlFor="usd"
                      className={`dropdown-card__english ${
                        chosenCurrency === '(USD) US Dollar' && 'active'
                      }`}
                    >
                      <p className="currency__title"> (USD) US Dollar </p>
                    </label>
                    <input
                      type="radio"
                      name="currency"
                      id="usd"
                      className="option-input"
                      onChange={(event) =>
                        setChosenCurrency(
                          event.target.checked && '(USD) US Dollar'
                        )
                      }
                    />
                    <label
                      htmlFor="euro"
                      className={`dropdown-card__franch ${
                        chosenCurrency === 'Euro' && 'active'
                      }`}
                    >
                      <p className="currency__title"> Euro </p>
                    </label>
                    <input
                      type="radio"
                      name="currency"
                      id="euro"
                      className="option-input"
                      onChange={(event) =>
                        setChosenCurrency(event.target.checked && 'Euro')
                      }
                    />
                  </div>
                </DropdownCard>
                <LightButton butnType="submit" label="Save" />
              </form>
            </div>
          </div>
          <div className="ecommerce-header__contacts">
            <div>
              <i />
              <span className="contacts__call"> Call 24/7 </span>
            </div>
            <div className="ecommerce-header__tel">
              <a href="tel:(626) 295-6599" className="contacts__phone-number">
                {' '}
                (626) 295-6599{' '}
              </a>
              <a href="tel:(514) 922-7332" className="contacts__phone-number">
                {' '}
                (514) 922-7332{' '}
              </a>
            </div>
          </div>
          <div className="ecommerce-nav__my-action mobile__menu-icons">
            <div className="ecommerce-nav__balance">
              <img src={navImages.balanceIconW} alt="balance" />
            </div>
            <Link to="/wishlist" className="ecommerce-nav__heart">
              <img src={navImages.heartIconW} alt="heart" />
              <p className="ecommerce-nav__favor-items-count"> 3 </p>
            </Link>
            <div className="ecommerce-nav__cart">
              <img src={navImages.shoppingCartIconW} alt="cart" />
              <p className="ecommerce-nav__cart-items-count"> 3 </p>
            </div>
          </div>
          <Link
            to={token ? '/my-account' : '/signin'}
            className="ecommerce-header__profile"
          />
        </div>
      </section>
      <div className="ecommerce-nav">
        <section className="ecommerce-nav__container">
          <div className="ecommerce-nav__logo-and-navigation">
            <div className="hamburger">
              <span className="hamburger__item" />
            </div>
            <Link className="ecommerce-nav__logo" to="/">
              <img src={navImages.logoIcon} alt="logo" />
            </Link>
            <ul className="ecommerce-nav__navigation  mobile__menu">
              <li className="ecommerce-nav__navigation-box navigation-box__products">
                <NavLink to="/products" className="title">
                  {' '}
                  Products{' '}
                </NavLink>
                <i />
                <HoverCard className="hover-card__products">
                  {FILTERED_PRODUCTS.map((product, index) => {
                    return (
                      <NavFilterButton
                        className="nav-filter-btn__products"
                        key={index}
                      >
                        <Link
                          to={{
                            pathname: '/products',
                            state: product.title,
                          }}
                          className="filtered-items__icon"
                        >
                          <img src={product.icon} alt="product" />
                        </Link>
                        <h5 className="filtered-items__title">
                          {' '}
                          {product.title}{' '}
                        </h5>
                      </NavFilterButton>
                    )
                  })}
                </HoverCard>
              </li>
              <li className="ecommerce-nav__navigation-box navigation-box__brands">
                <NavLink to="/brands" className="title">
                  {' '}
                  Brands{' '}
                </NavLink>
                <i />
                <HoverCard className="hover-card__brands">
                  {dataBrands &&
                    dataBrands.map((brand, index) => {
                      return (
                        <NavFilterButton
                          className="nav-filter-btn__brands"
                          key={index}
                        >
                          <div className="filtered-items__icon">
                            <img src={`${url}/${brand.img}`} alt="brand" />
                          </div>
                        </NavFilterButton>
                      )
                    })}
                </HoverCard>
              </li>
              <li className="ecommerce-nav__navigation-box navigation-box__deals">
                <NavLink to="/deals" className="title">
                  {' '}
                  Deals{' '}
                </NavLink>
                <i />
                <HoverCard className="hover-card__deals">
                  {FILTERED_DEALS.map((deal, index) => {
                    return (
                      <NavFilterButton
                        className="nav-filter-btn__deals"
                        key={index}
                      >
                        <div className="filtered-items__icon">
                          <img src={deal.icon} alt="deal" />
                        </div>
                        <h5 className="filtered-items__title">
                          {' '}
                          {deal.title}{' '}
                        </h5>
                      </NavFilterButton>
                    )
                  })}
                </HoverCard>
              </li>
            </ul>
          </div>
          <div className="ecommerce-nav__actions ">
            <ul className="ecommerce-nav__social-media  mobile__menu">
              <li>
                <a
                  href="https://www.instagram.com/"
                  target="_blank"
                  rel="noreferrer noopener"
                >
                  <i className="ecommerce-nav__media-box media-box__insta" />
                </a>
              </li>
              <li>
                <a
                  href="https://www.facebook.com/"
                  target="_blank"
                  rel="noreferrer noopener"
                >
                  <i className="ecommerce-nav__media-box media-box__facebook" />
                </a>
              </li>
              <li>
                <a
                  href="https://twitter.com/"
                  target="_blank"
                  rel="noreferrer noopener"
                >
                  <i className="ecommerce-nav__media-box media-box__twitter" />
                </a>
              </li>
              <li>
                <a
                  href="https://www.youtube.com/"
                  target="_blank"
                  rel="noreferrer noopener"
                >
                  <i className="ecommerce-nav__media-box media-box__youtube" />
                </a>
              </li>
            </ul>
            {/* <div className="ecommerce-nav__search">
                            <input type="text" placeholder="Search..." />
                            <i />
                        </div> */}
            <Search />
            <div className="ecommerce-nav__my-action  mobile__menu">
              <div className="ecommerce-nav__balance">
                <img src={navImages.balanceIcon} alt="balance" />
              </div>
              <Link to="/wishlist" className="ecommerce-nav__heart">
                <img src={navImages.heartIcon} alt="heart" />
                <p className="ecommerce-nav__favor-items-count"> 3 </p>
              </Link>
              <div className="ecommerce-nav__cart">
                <img src={navImages.shoppingCartIcon} alt="cart" />
                <p className="ecommerce-nav__cart-items-count"> 3 </p>
              </div>
            </div>
          </div>
        </section>
        <section className="free-shipping__mobile">
          <div className="free-shipping__mobile-icon">
            <img src={headerImages.truckIcon} alt="truck" />
            <h2 className="free-shipping__mobile-title">FREE SHIPPING</h2>
            <img src={headerImages.truckIcon} alt="truck" />
          </div>
          <h3 className="free-shipping__mobile-text">
            from Los Angels across USA & CANADA{' '}
          </h3>
        </section>
      </div>
    </header>
  )
}

export default Nav
