import React, { useState, useEffect } from 'react'
import './Main.css'
import ScrollToTop from './scrollToTop/ScrollToTop'
import { Switch, Route } from 'react-router-dom'
import AboutUs from '../pages/aboutUs/AboutUs'
import Blog from '../pages/blog/Blog'
import Brands from '../pages/brands/Brands'
import Financing from '../pages/financing/Financing'
import Home from '../pages/home/Home'
import Support from '../pages/supportPage/Support'
import Products from '../pages/products/Products'
import SingleProduct from '../pages/singleProduct/SingleProduct'
import SignUp from '../pages/signUp/SignUp'
import SignIn from '../pages/signIn/SignIn'
import ResetPassword from '../pages/ResetPassword'
import Congratulations from '../pages/Congratulations'
import MyAccount from '../pages/MyAccount'
import Orders from '../pages/Orders'
import Shipping from '../pages/Shipping'
import Profile from '../pages/Profile'
import Affiliate from '../pages/Affiliate'
// import AffiliateProgram from '../pages/AffiliateProgram'
import Sidebar from '../UI/Sidebar'
import FAQ from '../pages/FAQ/FAQ'
import ShippingAndReturns from '../pages/shippingAndReturns/ShippingAndReturns'
import BuyingGuide from '../pages/buyingGuide/BuyingGuide'
import WarrantyRegistration from '../pages/warrantyRegistration/WarrantyRegistration'
import NoMatch from '../pages/NoMatch/NoMatch'
import { useSelector, useDispatch } from 'react-redux'
import Wishlist from '../pages/wishlist/Wishlist'
import PrivacyPolicy from '../pages/privacyPolicy/PrivacyPolicy'
import TermsOfService from '../pages/TermsOfService/TermsOfService'
import WhyBuyFromUs from '../pages/whyBuyFromUs/WhyBuyFromUs'
import Deals from '../pages/deals/Deals'
import CustomerTestimonials from '../pages/customerTestimonials/CustomerTestimonials'
// import AffiliateProgram from '../pages/affiliateProgram/AffiliateProgram'
import AffiliateProgram from '../pages/affiliateProgram/AffiliateProgram'
import SingleBlog from '../pages/singleBlog/SingleBlog'
// import WishlistRegistration from "../pages/wishlistRegistration/WishlistRegistration";
// import SignUp from "../pages/SignUp";
import { Redirect, useLocation } from 'react-router'
import jwtDecode from 'jwt-decode'

const Main = () => {
  const Token = localStorage.getItem('token')
    ? localStorage.getItem('token')
    : null
  const dispatch = useDispatch()

  useEffect(() => {
    if (Token) {
      let token = jwtDecode(Token)
      dispatch({
        type: 'USER',
        payload: token,
      })
    }
  }, [])
  const user = useSelector((store) => console.log(store, 'store'))
  console.log(user, 'user')

  const [isLogedIn, setIsLogedIn] = useState()

  const loginHandler = () => setIsLogedIn(true)
  const logoutHandler = () => setIsLogedIn(false)
  const { pathname } = useLocation()

  const data = useSelector((state) => state.unicycleReducer)

  const getLocation = () => {
    if (
      pathname === '/my-account' ||
      pathname === '/orders' ||
      pathname === '/shipping' ||
      pathname === '/profile' ||
      pathname === '/my-account' ||
      pathname === '/affiliate'
    ) {
      return (
        <div className={'ecommerce-main__account wrapper2'}>
          <Sidebar onLogout={logoutHandler} />
          <Switch>
            <Route exact path="/" component={Home} />
            <Route exact path="/my-account" component={MyAccount} />
            <Route exact path="/orders" component={Orders} />
            <Route exact path="/shipping" component={Shipping} />
            <Route exact path="/profile" component={Profile} />
            <Route exact path="/deals" component={Deals} />
            <Route exact path="/affiliate" component={Affiliate} />
            <Route
              exact
              path="/customer-testimonials"
              component={CustomerTestimonials}
            />

            <Route exact path="/shipping" component={Shipping} />
          </Switch>
        </div>
      )
    } else {
      return ''
    }
  }
  return (
    <main className="ecommerce-main">
      <ScrollToTop />
      {pathname && getLocation()}
      {Token ? (
        <Switch>
          <Route exact path="/" component={Home} />
          <Redirect exact path="/signin" component={Home} />
          <Route exact path="/orders" component={Orders} />
          <Route exact path="/shipping" component={Shipping} />
          <Route exact path="/profile" component={Profile} />
          <Route exact path="/deals" component={Deals} />
          <Route
            exact
            path="/customer-testimonials"
            component={CustomerTestimonials}
          />
          <Route exact path="/single-blog/:id" component={SingleBlog} />
          <Route exact path="/affiliate-program" component={AffiliateProgram} />
          <Route exact path="/deals" component={Deals} />
          <Route exact path="/reset-password" component={ResetPassword} />
          <Route exact path="/congrats" component={Congratulations} />
          <Route exact path="/products" component={Products} />
          <Route exact path="/single-product/:id" component={SingleProduct} />
          <Route exact path="/about-us" component={AboutUs} />
          <Route exact path="/blog" component={Blog} />
          <Route exact path="/brands" component={Brands} />
          <Route exact path="/financing" component={Financing} />
          <Route exact path="/support" component={Support} />
          <Route exact path="/faq" component={FAQ} />
          <Route exact path="/privacypolicy" component={PrivacyPolicy} />
          <Route exact path="/termsofservice" component={TermsOfService} />
          <Route exact path="/termsofuse" component={WhyBuyFromUs} />
          <Route exact path="/wishlist" component={Wishlist} />
          {/* <Route exact path="/wishlistRegistration" component={ WishlistRegistration } /> */}
          <Route exact path="/buyingGuide" component={BuyingGuide} />
          <Route
            exact
            path="/shippingAndReturns"
            component={ShippingAndReturns}
          />
          <Route
            exact
            path="/warrantyRegistration"
            component={WarrantyRegistration}
          />
          <Route component={NoMatch} />
        </Switch>
      ) : (
        <Switch>
          <Route exact path="/" component={Home} />
          <Route exact path="/affiliate-program" component={AffiliateProgram} />
          <Route
            exact
            path="/customer-testimonials"
            component={CustomerTestimonials}
          />
          <Route
            exact
            path="/signup"
            component={() => <SignUp onLogin={loginHandler} />}
          />
          <Route exact path="/single-blog/:id" component={SingleBlog} />
          <Route
            exact
            path="/signin"
            component={() => <SignIn onLogin={loginHandler} />}
          />
          {/* <Route exact path="/sign-up" component={ () => <SignUp onLogin={ loginHandler } /> } /> */}
          <Route exact path="/deals" component={Deals} />
          <Route exact path="/reset-password" component={ResetPassword} />
          <Route exact path="/congrats" component={Congratulations} />
          <Route exact path="/products" component={Products} />
          <Route exact path="/single-product/:id" component={SingleProduct} />
          <Route exact path="/about-us" component={AboutUs} />
          <Route exact path="/blog" component={Blog} />
          <Route exact path="/brands" component={Brands} />
          <Route exact path="/financing" component={Financing} />
          <Route exact path="/support" component={Support} />
          <Route exact path="/faq" component={FAQ} />
          <Route exact path="/privacypolicy" component={PrivacyPolicy} />
          <Route exact path="/termsofservice" component={TermsOfService} />
          <Route exact path="/termsofuse" component={WhyBuyFromUs} />
          <Route exact path="/wishlist" component={Wishlist} />
          {/* <Route exact path="/wishlistRegistration" component={ WishlistRegistration } /> */}
          <Route exact path="/buyingGuide" component={BuyingGuide} />
          <Route
            exact
            path="/shippingAndReturns"
            component={ShippingAndReturns}
          />
          <Route
            exact
            path="/warrantyRegistration"
            component={WarrantyRegistration}
          />
          <Route component={NoMatch} />
        </Switch>
      )}
    </main>
  )
}

export default Main
