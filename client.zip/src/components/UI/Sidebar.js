import React from 'react'
import { NavLink, Link } from 'react-router-dom'
import { useHistory } from 'react-router'
import './Sidebar.css'

function Sidebar({ onLogout }) {
  const history = useHistory()

  return (
    <section className="sidebar">
      <div className="ecommerce-products__navigation">
        <ul className="ecommerce-products__navigation-list">
          <li>
            {' '}
            <Link to="/"> Home / </Link>{' '}
          </li>
          <li>
            {' '}
            <Link to="/my-account"> My account </Link>{' '}
          </li>
        </ul>
      </div>
      <div className="sidebar__content">
        <ul className="sidebar__list">
          <li>
            {' '}
            <NavLink to="my-account">
              {' '}
              <i /> My Account{' '}
            </NavLink>{' '}
          </li>
          <li>
            {' '}
            <NavLink to="orders">
              {' '}
              <i /> Orders{' '}
            </NavLink>{' '}
          </li>
          <li>
            {' '}
            <NavLink to="shipping">
              {' '}
              <i /> Shipping / Billing{' '}
            </NavLink>{' '}
          </li>
          <li>
            {' '}
            <NavLink to="profile">
              {' '}
              <i /> Profile{' '}
            </NavLink>{' '}
          </li>
          <li>
            {' '}
            <NavLink to="affiliate">
              {' '}
              <i /> Affiliate program{' '}
            </NavLink>{' '}
          </li>
        </ul>
      </div>
      <button
        type="button"
        className="sidebar__logout-btn"
        onClick={() => {
          onLogout()
          localStorage.removeItem('token')
          history.push('/signin')
        }}
      >
        <span className="sidebar__logout-text"> Log out </span>
      </button>
    </section>
  )
}

export default Sidebar
