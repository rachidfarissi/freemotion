import React, { useState } from 'react';
import { singleProductImages } from '../../../dummy-datas/images';
import './ChooseProductQuantity.css';


const ChooseProductQuantity = () => {
    const [productQuantity, setProductQuantity] = useState(1);

    const isUnderTheLowestLimit = productQuantity <= 1;
    const isOverTheHighestLimit = productQuantity >= 12;

    return (
        <div className="product-intro__quantity">
            <h6 className="quantity__label"> Quantity: </h6>
            <div className="quantity__actions">
                <button
                    type="button"
                    className="decrease-quantity__butn"
                    onClick={ () => setProductQuantity((prevState) => prevState - 1) }
                    disabled={ isUnderTheLowestLimit }
                >
                    <img src={ singleProductImages.minus_icon } alt="minus" />
                </button>
                <span className="single-product__quantity"> { productQuantity } </span>
                <button
                    type="button"
                    className="increase-quantity__butn"
                    onClick={ () => setProductQuantity((prevState) => prevState + 1) }
                    disabled={ isOverTheHighestLimit }
                >
                    <img src={ singleProductImages.plus_icon } alt="plus" />
                </button>
                <p className="quantity__info"> 12 <em> In stock </em> </p>
            </div>
        </div>
    );
};

export default ChooseProductQuantity;
