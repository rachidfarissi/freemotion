import React, { useState } from 'react';
import { useHistory } from 'react-router';
import { useValidity } from '../../../custom-hooks/form-validity';
import DarkButton from '../../buttons/DarkButton';
import './ForgotPassword.css';


function ForgotPassword() {
    const history = useHistory();

    const [emailIsSent, setEmailIsSent] = useState(false);

    const {
        enteredValue: enteredEmailAddress,
        inputIsValid: emailAddressInputIsValid,
        inputIsInvalid: emailAddressInputIsInvalid,
        changeInputValueHandler: changeEmailAddressInputValueHandler,
        blurInputHandler: blurEmailAddressInputHandler
    } = useValidity(value => (/\w+(\.|-|_)?\w+@\w+\.\w{2,3}/.test(value)));

    const forgotPasswordFormIsValid = emailAddressInputIsValid;

    const submitForgotPasswordForm = (evt) => { 
        evt.preventDefault();
        if(!forgotPasswordFormIsValid) return;
        const forgotPasswordFormData = {
            email: enteredEmailAddress
        };
        console.log(forgotPasswordFormData); 
        setEmailIsSent(true); 
    };

    return (
        <div className="forgot-password">
            <h2 className="forgot-password__title"> Reset password </h2>
            <div className="forgot-password__form-container">
                {
                    (emailIsSent) 
                    ? (
                        <div className="forgot-password__info-box">
                            <h3 className="forgot-password__info-msg"> Reset password link sent </h3>
                            <p className="forgot-password__text"> Please check your email for a link to reset your password. </p>
                            <DarkButton
                                className="forgot-password__reset-password-btn"
                                butnType="button" 
                                label="Close" 
                                onButnClick={ () => history.push('/reset-password') }
                            />
                        </div>
                    )
                    : (
                        <>
                            <p className="forgot-password__text"> Enter your email address below, and if an account exists, we’ll send you a link to reset your password. </p>
                            <form action="#" name="forgotPasswordForm" id="forgot-password-form" onSubmit={ submitForgotPasswordForm }>
                                <div className="ecommerce-input__container">
                                    <label 
                                        htmlFor="email-address" 
                                        className={ `ecommerce-input__label ${ emailAddressInputIsInvalid && "invalid-label" }` }
                                    > 
                                        Email 
                                    </label>
                                    <div className={ `ecommerce-input__input-box ${ emailAddressInputIsInvalid && "invalid-input" }` }>
                                        <input 
                                            type="email"
                                            id="email-address"
                                            className="ecommerce-input__input ecommerce-input__forgot-pass-input"
                                            value={ enteredEmailAddress }
                                            onChange={ changeEmailAddressInputValueHandler }
                                            onBlur={ blurEmailAddressInputHandler }
                                            placeholder="Enter email"
                                            autoComplete="off"
                                        />
                                    </div>
                                    { emailAddressInputIsInvalid && <p className="invalid-msg-info"> Unknown email address. Check again or try your username. </p> }
                                </div>
                                <DarkButton
                                    className="forgot-password__reset-password-btn"
                                    butnType="submit" 
                                    label="Reset password" 
                                    butnDisabled={ !forgotPasswordFormIsValid }
                                />
                            </form>
                        </>
                    )
                }
            </div>
        </div>
    )
}

export default ForgotPassword;
