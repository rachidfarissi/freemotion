import React, { useState } from 'react';
import './AddToCart.scss';
import { productsMainImages } from '../../../../dummy-datas/images';


const AddToCart = () => {
    const [isAddedToCart, setIsAddedToCart] = useState(false);

    const image_src = isAddedToCart ? productsMainImages.orangeBGCartIcon : productsMainImages.orangeBorderCartIcon;
    const text = isAddedToCart ? "Remove" : "Add to cart";

    return (
        <button 
            className="add-to-cart"
            onClick={ () => setIsAddedToCart((prevState) => !prevState) }    
        >
            <img src={ image_src } alt="add to cart" />
            <span className="add-to-cart__text"> { text } </span>
        </button>
    );
};

export default AddToCart;
