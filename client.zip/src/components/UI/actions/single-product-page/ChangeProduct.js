import React, { useState } from 'react';
import Scooters from '../../../items/single-product-page/Scooters';
import Skateboards from '../../../items/single-product-page/Skateboards';
import Unicycles from '../../../items/single-product-page/Unicycles';
import './ChangeProduct.css';


const CHANGABLE_PRODUCTS_NAMES = ["E-Unicycle", "E-Scooter", "E-Skateboard"];

const ChangeProduct = () => {
    const [selectedProductName, setSelectedProductName] = useState("E-Unicycle");

    return (
        <div className="change-product">
            <h2 className="change-product__title"> Сhange product </h2>
            <div className="change-product__content">
                <ul className="change-product__products-names-list">
                    {
                        CHANGABLE_PRODUCTS_NAMES.map((productName, index) => {
                            return (
                                <li key={ index }>
                                    <button
                                        type="button"
                                        className="change-product__nav-btn"
                                        onClick={ () => setSelectedProductName(productName) }
                                    > 
                                        { productName }
                                    </button>  
                                </li>
                            );
                        })
                    }
                </ul>
                <div className="change-product__changable-products">
                    { (selectedProductName === "E-Unicycle") && <Unicycles /> }
                    { (selectedProductName === "E-Scooter") && <Scooters />}
                    { (selectedProductName === "E-Skateboard") && <Skateboards /> }
                </div>
            </div>
        </div>
    );
};

export default ChangeProduct;
