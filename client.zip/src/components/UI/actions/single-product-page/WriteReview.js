import React from 'react';
import { modalsImagesAndIcons } from '../../../../dummy-datas/images';
import DarkButton from '../../buttons/DarkButton';
import LightButton from '../../buttons/LightButton';
import './WriteReview.css';


const WriteReview = ({ onClose }) => {
    return (
        <div className="write-review">
            <h2 className="write-review__title"> Write a review </h2>
            <div className="write-review__content">
                <form action="#" name="writeReviewForm" id="write_review_form" onSubmit={ (e) => e.preventDefault() }>
                    <label htmlFor="overall_rating" className="write-review__label label--color">
                        Your overall rating 
                    </label>
                    <div className="write-review__rating-stars">
                        <div className="rating-stars__icon">
                            <img src={ modalsImagesAndIcons.yellowStarIcon } alt="yellow star" />
                        </div>
                        <div className="rating-stars__icon">
                            <img src={ modalsImagesAndIcons.yellowStarIcon } alt="yellow star" />
                        </div>
                        <div className="rating-stars__icon">
                            <img src={ modalsImagesAndIcons.grayStarIcon } alt="gray star" />
                        </div>
                        <div className="rating-stars__icon">
                            <img src={ modalsImagesAndIcons.grayStarIcon } alt="gray star" />
                        </div>
                        <div className="rating-stars__icon">
                            <img src={ modalsImagesAndIcons.grayStarIcon } alt="gray star" />
                        </div>
                    </div>
                    <div className="write-review__box">
                        <label htmlFor="pros" className="write-review__label"> Pros </label>
                        <input 
                            type="text"
                            id="pros"
                            className="write-review__input" 
                            placeholder="Enter pros"
                        />
                    </div>
                    <div className="write-review__box">
                        <label htmlFor="cons" className="write-review__label"> Cons </label>
                        <input 
                            type="text"
                            id="cons"
                            className="write-review__input" 
                            placeholder="Enter cons"
                        />
                    </div>
                    <div className="write-review__box">
                        <label htmlFor="your_review" className="write-review__label"> Your Review * </label>
                        <textarea 
                            id="your_review"
                            className="write-review__textarea" 
                            placeholder="Description..."
                        />
                    </div>
                    <div className="write-review__name-email-container">
                        <div className="write-review__box">
                            <label htmlFor="name" className="write-review__label"> Name * </label>
                            <input 
                                type="text"
                                id="name"
                                className="write-review__input" 
                                placeholder="Enter name"
                            />
                        </div>
                        <div className="write-review__box">
                            <label htmlFor="email" className="write-review__label"> Email * </label>
                            <input 
                                type="email"
                                id="email"
                                className="write-review__input" 
                                placeholder="Enter email"
                            />
                        </div>
                    </div>
                    <div className="write-review__actions">
                        <LightButton 
                            butnType={ "reset" }
                            className={ "write-review__cancel-btn" }
                            label={ "Cancel" }
                            onButnClick={ onClose }
                        />
                        <DarkButton 
                            butnType={ "submit" }
                            className={ "write-review__submit-btn" }
                            label={ "Submit Review" }
                        />
                    </div>
                </form>
            </div>
        </div>
    );
};

export default WriteReview;
