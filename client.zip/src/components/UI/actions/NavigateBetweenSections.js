import React from 'react';
import './NavigateBetweenSections.scss';
import { Link } from 'react-scroll';


function NavigateBetweenSections() {
    // const {
    //     description_id,
    //     parameters_id,
    //     shipping_and_warranty_id,
    //     FAQ_id,
    //     photo_and_video_id,
    //     reviews_id
    // } = props;

    return (
        <div className="navigate-between-sections"> 
            <ul className="navigate-between-sections__list">
                <li>
                    <Link true='true' to='description' smooth={true} duration={500} offset={-150}> Description </Link>
                </li>
                <li>
                    <Link true='true' to='parameters' smooth={true} duration={1000} offset={-150}> { "Parameters" } </Link>
                </li>
                <li>
                    <Link true='true' to='shipping' smooth={true} duration={1000} offset={-150} > { "Shipping & Warranty" } </Link>
                </li>
                <li>
                    <Link true='true' to='faq' smooth={true} duration={1000} offset={-150} > FAQ </Link>
                </li>
                <li>
                    <Link true='true' to='photoVideo' smooth={true} duration={1500} offset={-150} > Photo and Video </Link>
                    {/* <a href={ 'fsd' }> { "Photo and Video" } </a> */}
                </li>
                <li>
                    <Link true='true' to='reviews' smooth={true} duration={1500} offset={-150} > Reviews </Link>
                    {/* <a href={ 'reviews' }> Reviews </a> */}
                </li>
            </ul>
        </div>
    );
};

export default NavigateBetweenSections;
