import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { productsMainImages } from '../../../../dummy-datas/images';
import './AddToFavourite.scss';


const AddToFavourite = () => {
    const [isAddedToFavourite, setIsAddedToFavourite] = useState(false);

    const image_src = isAddedToFavourite ? productsMainImages.orangeHeartIcon : productsMainImages.blackHeartIcon;
    const text = isAddedToFavourite ? "Remove" : "Add to";

    return (
        <button 
            className="add-to-favourite"
            onClick={ () => setIsAddedToFavourite((prevState) => !prevState) }
        >
            <img src={ image_src } alt="add to favourite" />
            <span className="add-to-favourite__text"> 
                { text } { !isAddedToFavourite && <Link to="*"> Favourite </Link> } 
            </span>
        </button>
    );
};

export default AddToFavourite;
