import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { productsMainImages } from '../../../../dummy-datas/images';
import './AddToCompare.scss';


const AddToCompare = () => {
    const [isAddedToCompare, setIsAddedToCompare] = useState(false);
           
    const image_src = isAddedToCompare ? productsMainImages.orangeCompareIcon : productsMainImages.blackCompareIcon;
    const text = isAddedToCompare ? "Remove" : "Add to";

    return (
        <button 
            className="add-to-compare"
            onClick={ () => setIsAddedToCompare((prevState) => !prevState) }
        >
            <img src={ image_src } alt="add to compare" />
            <span className="add-to-compare__text"> 
                { text } { !isAddedToCompare && <Link to="*"> Compare </Link> } 
            </span>
        </button>
    );
};

export default AddToCompare;
