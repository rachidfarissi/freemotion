import React, { useState } from 'react';
import { singleProductImages } from '../../../../dummy-datas/images';
import DarkButton from '../../buttons/DarkButton';
import CustomModal from '../../custom-modal';
import './BuyTogetherAndSave.scss';
import ChangeProduct from '../single-product-page/ChangeProduct';


const BuyTogetherAndSave = () => {
    const [modalIsOpen, setModalIsOpen] = useState(false);

    const openModalHandler = () => setModalIsOpen(true);
    const closeModalHandler = () => setModalIsOpen(false); 

    return (
        <React.Fragment>
            <div className="buy-together-and-save">
                <h2 className="buy-together-and-save__title"> Buy together and save </h2>
                <div className="buy-together-and-save__content">
                    <div className="content__products">
                        <div className="content__products-box">
                            <div className="content__product-info">
                                <div className="content__product-image">
                                    <img src={ singleProductImages.eUnicycleImage } alt="product" />
                                </div>
                                <h6 className="content__product-description"> 
                                    SEGWAY ES2 SCOOTER + Extended battery (Used certified) 
                                </h6>
                            </div>
                        </div>
                        <div className="content__products-box second-box">
                            <div className="content__product-info">
                                <div className="content__product-image">
                                    <img src={ singleProductImages.wheel_image } alt="product" />
                                </div>
                                <div className="content__product-des-and-price">
                                    <h6 className="content__product-description"> 
                                        Vee Rubber VRM217 (110/50 R6.5) Street Tire 
                                    </h6>
                                    <div className="product-intro__price-info">
                                        <div className="new-price-box">
                                            <span className="new-price-box__currency"> C$ </span>
                                            <p className="electric-unicycle__new-price"> { "1000" } </p>
                                        </div>
                                        <div className="old-price-box">
                                            <span className="old-price-box__currency"> C$ </span>
                                            <p className="electric-unicycle__old-price"> { "3300.00" } </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button
                                type="button"
                                className="content__change-btn"
                                onClick={ openModalHandler }
                            >
                                Сhange product 
                            </button>
                        </div>
                    </div> 
                    <div className="content__action">
                        <h6 className="product-intro__info"> SKU: <em> { "2231" } </em> </h6>
                        <div className="action__buy-bundle">
                            <div className="new-price-box">
                                <span className="new-price-box__currency"> C$ </span>
                                <p className="electric-unicycle__new-price"> { "3999" } </p>
                            </div>
                            <DarkButton 
                                className={ "action__buy-bundle-btn" }
                                butnType={ "button" }
                                label={ "Buy bundle" }
                                // onButnClick={}
                            />
                        </div>
                    </div> 
                </div>
            </div>
            { modalIsOpen && (
                <CustomModal 
                    popupClassName={ "change-product__popup" } 
                    closerClassName={ "change-product__closer" }
                    closeModal={ closeModalHandler }
                > 
                    <ChangeProduct /> 
                </CustomModal>
            ) }
        </React.Fragment>
    );
};

export default BuyTogetherAndSave;
