import React from 'react';
import ReactDOM from 'react-dom';
import './custom-modal.css';
import closer from '../../assets/icons/closer.png';


export const Overlay = ({ overlayClassName, onClose }) => {
    const _overlay_class_name = `modal__overlay ${ overlayClassName }`;
    const _overlay = <div className={ _overlay_class_name } onClick={ onClose } />;
    return _overlay;
};

export const Popup = ({ children, popupClassName, closerClassName, onClose }) => {
    const _closer_icon = <img src={ closer } alt="closer" />;
    const _closer_class_name = `modal__closer ${ closerClassName }`;   
    const _popup_class_name = `modal__popup ${ popupClassName }`;
    const _popup = (
        <div className={ _popup_class_name }> 
            <button
                type="button"
                className={ _closer_class_name }
                onClick={ onClose }
            >
                { _closer_icon }
            </button> 
            { children } 
        </div>
    );
    return _popup;
};

const CustomModal = ({ children, overlayClassName, popupClassName, closerClassName, closeModal }) => {
    const _portal = document.getElementById("modal");
    const _overlay = <Overlay overlayClassName={ overlayClassName } onClose={ closeModal } />;
    const _popup = (
        <Popup 
            popupClassName={ popupClassName } 
            closerClassName={ closerClassName } 
            onClose={ closeModal }
        > 
            { children } 
        </Popup>
    );
    const _custom_modal = (
        <React.Fragment>
            { ReactDOM.createPortal(_overlay, _portal) }
            { ReactDOM.createPortal(_popup, _portal) }
        </React.Fragment>
    );
    return _custom_modal;
};

export default CustomModal;
