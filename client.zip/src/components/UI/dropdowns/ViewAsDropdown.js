import React, { useState } from 'react';
import './SmallDropdowns.css';


const PRODUCTS_VIEW_OPTIONS = ["_list_view"];

const ViewAsDropdown = ({ onPass }) => {
    const [productsViewOptions, setProductsViewOptions] = useState(PRODUCTS_VIEW_OPTIONS);
    const [chosenViewOption, setChosenViewOption] = useState("_gallery_view");

    const chooseViewOptionHandler = (option) => {
        setChosenViewOption(option);
        setProductsViewOptions((prevViewOption) => [...prevViewOption.filter(viewOption => viewOption !== option), chosenViewOption]);
        onPass(option);
    };

    return (
        <div className="products-actions__view-as">
            <div className="view-as">
                <span className="view-as__text"> View as: </span>
                <div className="view-as__dropdown">
                    <div className="view-as__info">
                        <p className="view-as__limit"> 
                            { (chosenViewOption === "_gallery_view") && <i className="view-as__gallery" /> }  
                            { (chosenViewOption === "_list_view") && <i className="view-as__list" /> }
                        </p>
                        <i className="actions__icon" />
                    </div>
                    <ul className="view-as__products-view-list list">
                        {
                            productsViewOptions.map((option, index) => {
                                return (
                                    <li
                                        key={ index }
                                        onClick={ chooseViewOptionHandler.bind(null, option) }
                                    >
                                        { (productsViewOptions.includes("_gallery_view")) && <p className="view-as__option"> Gallery view <i className="view-as__gallery" /> </p> }  
                                        { (productsViewOptions.includes("_list_view")) && <p className="view-as__option"> List view <i className="view-as__list" />  </p> }
                                    </li>
                                );
                            })
                        }
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default ViewAsDropdown;
