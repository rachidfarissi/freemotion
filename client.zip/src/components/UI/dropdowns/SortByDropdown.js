import React, { useState } from 'react';
import './SmallDropdowns.css';


const SORTABLE_OPTIONS = ["Alphabetically, Z-A", "Top Products"];

const SortByDropdown = () => {
    const [sortableOptions, setSortableOptions] = useState(SORTABLE_OPTIONS);
    const [chosenSortableOption, setChosenSortableOption] = useState("Alphabetically, A-Z");

    const chooseSortableOptionHandler = (option) => {
        setChosenSortableOption(option);
        setSortableOptions((prevOption) => [...prevOption.filter(sortedOption => sortedOption !== option), chosenSortableOption]);
    };

    return (
        <div className="products-actions__sort-by">
            <span className="sort-by__text"> Sort by: </span>
            <div className="sort-by__dropdown">
                <div className="sort-by__info">
                    <p className="sort-by__limit"> { chosenSortableOption } </p>
                    <i className="actions__icon" />
                </div>
                <ul className="sort-by__products-sort-list list">
                    {
                        sortableOptions.map((option, index) => {
                            return (
                                <li
                                    key={ index }
                                    onClick={ chooseSortableOptionHandler.bind(null, option) }
                                > 
                                    { option } 
                                </li>
                            );
                        }) 
                    }
                </ul>
            </div>
        </div>
    );
};

export default SortByDropdown;
