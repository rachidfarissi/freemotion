import React, { useState } from 'react';
import './SelectDropdown.css';


const WHEEL_SIZES = ["80mm Slick wheels", "120mm Slick wheels"];

const WheelSizeDropdown = () => {
    const [selectedWheelSize, setSelectedWheelSize] = useState("80mm Slick wheels");

    return (
        <div className="select-dropdown">
            <h6 className="select-dropdown__label"> Wheel Size: </h6>
            <div className="select-dropdown__box">
                <div className="select-dropdown__content">
                    <p className="select-dropdown__selected"> { selectedWheelSize } </p>
                </div>
                <div className="select-dropdown__options">
                    {
                        WHEEL_SIZES.map((wheelSize, index) => {
                            return (
                                <div 
                                    className="option" 
                                    key={ index }
                                    onClick={ () => setSelectedWheelSize(wheelSize) }
                                >
                                    { wheelSize }
                                </div>
                            )
                        })
                    }
                </div>
            </div>
        </div>
    );
};

export default WheelSizeDropdown;
