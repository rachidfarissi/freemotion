import React, { useState } from 'react';
import './SelectDropdown.css';


const AVAILABLE_COLORS = ["Black", "White", "Red and Black"];

const ColorDropdown = () => {
    const [selectedColor, setSelectedColor] = useState("Black");

    const selectedColorClassName = `
        select-dropdown__selected ${
            (selectedColor === "Black") 
            ? "color-black" 
            : (selectedColor === "White")  
            ? "color-white"
            : (selectedColor === "Red and Black")
            ? "color-red-and-black"
            : "" 
        }
    `;

    return (
        <div className="select-dropdown">
            <h6 className="select-dropdown__label"> Colors: <em> (3 available) </em> </h6>
            <div className="select-dropdown__box">
                <div className="select-dropdown__content">
                    <p className={ selectedColorClassName }>
                        { (selectedColor === "Red and Black") && <i className="circle" /> }
                        { selectedColor }
                    </p>
                </div>
                <div className="select-dropdown__options">
                    {
                        AVAILABLE_COLORS.map((color, index) => {
                            const colorClassName = `
                                select-dropdown__selected ${
                                    (color === "Black") 
                                    ? "color-black" 
                                    : (color === "White")  
                                    ? "color-white"
                                    : (color === "Red and Black")
                                    ? "color-red-and-black"
                                    : "" 
                                }
                            `;
                            
                            return (
                                <div 
                                    className="option" 
                                    key={ index }
                                    onClick={ () => setSelectedColor(color) }
                                >
                                    <p className={ colorClassName }>
                                        { (color === "Red and Black") && <i className="circle" /> }
                                        { color } 
                                    </p>
                                </div>
                            )
                        })
                    }
                </div>
            </div>
        </div>
    );
};

export default ColorDropdown;
