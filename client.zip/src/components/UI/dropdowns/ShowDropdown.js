import React, { useState } from 'react';
import './SmallDropdowns.css';


const LIMITS = [6, 9, 15];

const ShowDropdown = ({ onPass }) => {
    const [limits, setLimits] = useState(LIMITS);
    const [chosenLimit, setChosenLimit] = useState(12);

    const chooseLimitHandler = (limit) => {
        setChosenLimit(limit);
        setLimits((prevLimits) => [...prevLimits.filter(prevLimit => prevLimit !== limit), chosenLimit].sort((a, b) => a - b));
        onPass(limit);
    };

    return (
        <div className="actions__show-box">
            <span className="show-box__text"> Show: </span>
            <div className="show-box__dropdown">
                <div className="show-box__info">
                    <p className="show-box__limit"> { chosenLimit } </p>
                    <i className="actions__icon" />
                </div>
                <ul className="show-box__products-quantity-list list">      
                    {
                        limits.map((limit, index) => {
                            return (
                                <li 
                                    key={ index } 
                                    onClick={ chooseLimitHandler.bind(null, limit) }
                                > 
                                    { limit } 
                                </li>
                            );
                        }) 
                    }
                </ul>
            </div>
        </div>
    );
};

export default ShowDropdown;
