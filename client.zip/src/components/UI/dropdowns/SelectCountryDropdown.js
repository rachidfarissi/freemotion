import React, { useState } from 'react';
import './SelectCountryDropdown.css';
import arrowDownIcon from '../../../assets/icons/main/register/arrow-down.png';


const COUNTRIES = ["aaa", "bbb", "ccc", "ddd", "eee", "fff", "ggg", "hhh"];

function SelectCountryDropdown({ onPass, selectedCountry, countryInputIsInvalid, onReset }) {
    const [countryDropdownIsOpen, setCountryDropdownIsOpen] = useState(false);

    const selectCountryHandler = (country) => {
        onPass(country); 
        setCountryDropdownIsOpen(false);
    };

    return (
        <div className="ecommerce-input__container select-county-dropdown">
            <label 
                htmlFor="country" 
                className={ `ecommerce-input__label ${countryInputIsInvalid && "invalid-label" }` }
            > 
                Country * 
            </label>
            <div 
                className={ `ecommerce-input__input-box ${ countryInputIsInvalid && "invalid-input" }` } 
                onClick={ () => {
                    setCountryDropdownIsOpen((prevState) => !prevState);
                    onReset();
                } }
            >
                <span className={`ecommerce-input__selected ${ (selectedCountry) && "selected--color" }`}> { (selectedCountry) ? selectedCountry : "Select country" } </span>
                <img src={ arrowDownIcon } alt="arrow down" className={ `select-county-dropdown__icon ${ (countryDropdownIsOpen) && "icon--rotate" }` } />
            </div>
            { countryInputIsInvalid && <p className="invalid-msg-info"> Invalid country msg </p> }
            {
                (countryDropdownIsOpen) && (
                    <div className="country-dropdown">
                        <ul className="country-list">
                            {
                                COUNTRIES.map((country, index) => {
                                    return (
                                        <li 
                                            key={ index }
                                            className="country-dropdown__country-box"
                                            onClick={ selectCountryHandler.bind(null, country) }    
                                        >
                                            { country }
                                        </li>
                                    );
                                })
                            }
                        </ul>
                    </div>
                )
            }
        </div>
    );
}

export default SelectCountryDropdown;
