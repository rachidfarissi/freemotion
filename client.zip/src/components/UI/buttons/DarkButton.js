import React from 'react';
import './DarkButton.css';


const DarkButton = ({ className, butnType, label, onButnClick, butnDisabled }) => {
    return (
        <button 
            type={ butnType } 
            className={ `dark-btn ${ className }` }
            onClick={ onButnClick && onButnClick }
            disabled={ butnDisabled }
        >
            { label }
        </button>
    );
};

export default DarkButton;
