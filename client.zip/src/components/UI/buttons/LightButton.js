import React from 'react';
import './LightButton.css';


const LightButton = ({ className, label, butnType, onButnClick, butnDisabled }) => {
    return (
        <button 
            type={ butnType } 
            className={ `light-btn ${ className }` }
            onClick={ onButnClick && onButnClick }
            disabled={ butnDisabled }
        >
            { label }
        </button>
    );
};

export default LightButton;
