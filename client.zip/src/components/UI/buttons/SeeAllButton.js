import React from 'react';
import './SeeAllButton.css';


const SeeAllButton = ({ onShow }) => {
    return (
        <button
            className="see-all-butn"
            type="button"
            onClick={ onShow }
        >
            See All
        </button>
    );
};

export default SeeAllButton;
