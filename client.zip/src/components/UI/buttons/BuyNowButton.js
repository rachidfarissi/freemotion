import React, { useState } from 'react'
import './BuyNowButton.css'

const BuyNowButton = ({
  favourIcon,
  checkedFavourIcon,
  uncheckedFavourIcon,
  arrowIcon,
  className,
  checkboxId,
  singleProductHandler,
}) => {
  const [isCheckedAsFavour, setIsCheckedAsFavour] = useState(false)
  const [isCheckedOnce, setIsCheckedOnce] = useState(false)

  return (
    <div className="buy-now__actions">
      <label htmlFor={checkboxId} className="favour-label">
        <img
          src={
            isCheckedOnce && isCheckedAsFavour
              ? checkedFavourIcon
              : isCheckedOnce && !isCheckedAsFavour
              ? uncheckedFavourIcon
              : favourIcon
          }
          alt="heart"
        />
      </label>
      <input
        className="favour-input"
        type="checkbox"
        name="favourProduct"
        id={checkboxId}
        onChange={(event) => {
          setIsCheckedAsFavour(event.target.checked)
          setIsCheckedOnce(true)
        }}
        checked={isCheckedAsFavour}
      />
      <button
        className={`buy-now-btn ${className}`}
        type="button"
        onClick={singleProductHandler}
      >
        Buy now
        <img src={arrowIcon} alt="right arrow" className="buy-now__button" />
      </button>
    </div>
  )
}

export default BuyNowButton
