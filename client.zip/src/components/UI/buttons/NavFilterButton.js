import React from 'react';
import './NavFilterButton.css';


const NavFilterButton = ({ children, className }) => {
    return (
        <button 
            type="button"
            className={`nav-filter-btn ${className}`}
            // onClick={  }
        >
            { children }
        </button>
    );
};

export default NavFilterButton;
