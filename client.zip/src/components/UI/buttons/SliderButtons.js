import React from 'react';
import './SliderButtons.css';


const SliderButtons = ({ className }) => {
    return (
        <div className="slider-btns__box">
            <div className={`slider-buttons ${className}`} />
            <div className={`slider-buttons ${className}`} />
        </div>
    );
};

export default SliderButtons;