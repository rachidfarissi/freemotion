import React from 'react';
import './ShowPasswordButton.css';
import showIcon from '../../../assets/icons/main/register/show.png';
import hideIcon from '../../../assets/icons/main/register/hide.png';


function ShowPasswordButton({ isShown, onShow }) {
    const passwordIcon = (isShown) ? <img src={ hideIcon } alt="hide password" /> : <img src={ showIcon } alt="show password" />;
    const passwordText = (isShown) ? "Hide" : "Show";

    return (
        <button
            type="button"
            className="show-password-btn"
            onClick={ onShow }
        >
            { passwordIcon } 
            <span> { passwordText } </span>
        </button>
    );
}

export default ShowPasswordButton;