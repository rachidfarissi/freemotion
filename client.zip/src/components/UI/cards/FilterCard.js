import React, { useState } from 'react';
import './FilterCard.css';


const FilterCard = ({ children, title }) => {
    const [filteringItemsAreOpen, setFilteringItemsAreOpen] = useState(false);

    return (
        <div className="filter-card">
            <button 
                type="button" 
                className="filter-card__btn"
                onClick={ () => setFilteringItemsAreOpen((prevState => !prevState)) }
            >
                <h5 className="filter-card__title"> { title } </h5>
                <i className={`filter-card__icon ${ !filteringItemsAreOpen && "rotate" }`} />
            </button>
            { filteringItemsAreOpen && children }
        </div>
    );
};

export default FilterCard;