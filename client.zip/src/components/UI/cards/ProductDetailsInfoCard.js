import React from 'react';
import './ProductDetailsInfoCard.css';


const ProductDetailsInfoCard = ({ details, title }) => {
    // const checkedNumbers = /\d+/
    // console.log(typeof checkedNumbers);
    console.log(details)
    return (
        <div className="product-details__info-card">
            <h3 className="product-details__details"> { details } </h3>
            <h5 className="product-details__title"> { title } </h5>
        </div>
    );
};

export default ProductDetailsInfoCard;
