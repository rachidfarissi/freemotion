import React from 'react';
import './HoverCard.css';


const HoverCard = ({ children, className }) => {
    return (
        <div className={ `hover-card ${className}` }>
            <div className="hover-card__container">
                { children }
            </div>
        </div>
    );
};

export default HoverCard;
