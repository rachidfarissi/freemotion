import React from 'react';
import './DropdownCard.css';


const DropdownCard = ({ children, className }) => {
    return (
        <div className={`dropdown-card ${className}`}>
            { children }
        </div>
    );
};

export default DropdownCard;