import React, { useState, useEffect } from 'react'
import './popularBrands.scss'
import axios from 'axios'

import OWLcorusel from 'react-owl-carousel'
import 'owl.carousel/dist/assets/owl.carousel.min.css'
import 'owl.carousel/dist/assets/owl.theme.default.min.css'
import { Link } from 'react-router-dom'

const options = {
  responsive: {
    0: {
      items: 2,
      center: true,
    },

    850: {
      items: 3,
      center: true,
    },
    1000: {
      items: 5,
    },
  },
}

function PopularBrands({ title }) {
  let url = 'https://freemotion-shop-back.herokuapp.com'

  const [data, setData] = useState([])

  useEffect(() => {
    axios
      .get(`${url}/brand/list/simple`)
      // .then(res => console.log(res.data , '++00++'))
      .then((res) => setData(res.data.brand_list))
      .catch((e) => console.log(e))
  }, [url])

  return (
    <div className="popular-brands">
      <div className="popular-brands-container wrapper">
        <h2 className="popular-brands__title"> Popular Brands </h2>
        {data.length > 0 && (
          <OWLcorusel
            className="wrapper"
            items="3"
            autoplayHoverPause
            dots
            loop
            margin={50}
            responsive={options.responsive}
          >
            {data.map((brands, index) => (
              <Link
                key={brands.id}
                index={index}
                to={'/brands'}
                rel="noreferrer noopener"
              >
                <img
                  src={`${url}/${brands.img}`}
                  alt="INMOTION website"
                  loading="lazy"
                />
              </Link>
            ))}
          </OWLcorusel>
        )}
      </div>
    </div>
  )
}

export default PopularBrands
