import React from 'react'
import './bestSeller.scss'
import BestSellers from '../../components/items/home-page/BestSellers'
import BestSellerProduct from '../../components/items/home-page/BestSellerProduct'
import { BEST_SELLER_PRODUCT, BEST_SELLERS } from '../../dummy-datas/dummyDatas'

function BestSeller() {
  return (
    <div className="ecommerce-home__best-sellers">
      <BestSellerProduct product={BEST_SELLER_PRODUCT} />
      <div className="best-seller__products">
        {BEST_SELLERS.map((product) => (
          <BestSellers product={product} key={product.id} />
        ))}
        <div className="best-seller__slider-btns">
          <div className="slider-btns" />
          <div className="slider-btns" />
        </div>
      </div>
    </div>
  )
}

export default BestSeller
