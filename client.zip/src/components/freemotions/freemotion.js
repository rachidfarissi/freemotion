import React from 'react'
import './freemotion.scss'
import {homeMainImages } from "../../dummy-datas/images";

import OWLcorusel from 'react-owl-carousel'
import 'owl.carousel/dist/assets/owl.carousel.min.css'
import 'owl.carousel/dist/assets/owl.theme.default.min.css'


const options = {
    responsive: {
        0: {
            items: 1,
        },
        400: {
            items: 2,
        },
        650: {
            items: 3,
        },
        1000: {
            items: 4,
        }
    },
  };
  

function  Freemotion(){


    return(
        <div className="freemotion">
            <div className="freemotion-container">
                    <h2 className="freemotion__title wrapper"><span>@Freemotion</span> on instagram</h2>
                    <div className="freemotion__slider wrapper">
                        <OWLcorusel  items='3' autoplay autoplayHoverPause dots loop  margin={6}  responsive={options.responsive} >
                            <div className="freemotion__image-item">
                                <img src={ homeMainImages.girlWithHelmetImage } alt="instagram data" />
                            </div>
                            <div className="freemotion__image-item">
                                <img src={ homeMainImages.scooterAtTheStreetImage } alt="instagram data" />
                            </div>
                            <div className="freemotion__image-item">
                                <img src={ homeMainImages.freeMotionImage } alt="instagram data" />
                            </div>
                            <div className="freemotion__image-item">
                                <img src={ homeMainImages.e_scooterImage } alt="instagram data" />
                            </div>
                        </OWLcorusel>
                    </div>
            </div>
        </div>
    )
}

export default  Freemotion