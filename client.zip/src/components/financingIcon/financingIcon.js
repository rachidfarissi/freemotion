import React from 'react'
import './financingIcon.scss'
import klarnaIcon from './../../assets/images/financing/Klarna.png'
import arrow from './../../assets/images/financing/arrow.png'


import { Link } from 'react-router-dom';

const FinancingIcon = () => {
    return (
        <article className='financing__item'>
            <div className='financing__item__info'>
                <img src={klarnaIcon} alt='klarna icon'/>
                <Link to='' className='financing__link'> Visit website <img src={arrow} alt='arrow icon' className='financing__link-icon'/></Link>
            </div>
            <div className='financing__content'>
                <h2 className='financing__title'>Klarna</h2>
                <p className='financing__text'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                <h3 className='financing__subtitle'>Title</h3>
                <ul className='financing__ul'>
                    <li className='financing__list'>Lorem Ipsum is simply dummy text of the printing and industry.</li>
                    <li className='financing__list'>Lorem Ipsum is simply dummy text of the printing and industry.</li>
                    <li className='financing__list'>Lorem Ipsum is simply dummy text of the printing and industry.</li>
                    <li className='financing__list'>Lorem Ipsum is simply dummy text of the printing and industry.</li>
                    <li className='financing__list'>Lorem Ipsum is simply dummy text of the printing and industry.</li>
                </ul>
            </div>
        </article>
    )
}

export default FinancingIcon