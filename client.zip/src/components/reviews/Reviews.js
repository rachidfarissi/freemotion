import React , {useState , useEffect} from 'react'
import './reviews.scss'
import ProductReview from "../items/home-page/ProductReview";
// import { homeMainIcons, homeMainImages } from "../../dummy-datas/images";
// import { PRODUCTS_REVIEWS } from "../../dummy-datas/dummyDatas";
import axios from 'axios';



import OWLcorusel from 'react-owl-carousel'
import 'owl.carousel/dist/assets/owl.carousel.min.css'
import 'owl.carousel/dist/assets/owl.theme.default.min.css'



const options = {
    responsive: {
        0: {
            items: 1,
        },
        400: {
            items: 1,
        },
        650: {
            items: 2,
        },
        1000: {
            items: 3,
  
        }
    },
  };
  


function Reviews(){
    let url = 'https://freemotion-shop-back.herokuapp.com'

    const [data , setData] = useState([])

    useEffect(() => {
        axios.get(`${url}/review/list`)
        // .then(res => console.log(res.data.review , '++55++'))
        // .then(res => setData(res.data.review))
        .then(res => {console.log(res.data, '---+-+++--++') ; setData(res.data.review); })
    }, [url])

    useEffect(() => {
        console.log(data, 'data')
    },[data])

    // console

    return(
        <div className="reviews-home">
            <div className="reviews-home__container">
                <div className="reviews-home__slider wrapper">
                    <h2 className="reviews-home__title"> Reviews </h2>
                    {/* <SliderButtons className="reviews__slider-btns" /> */}
                </div>
                <div className="reviews-home__details wrapper">
                {/* <OWLcorusel   items='3'   center autoplayHoverPause dots loop  margin={6}  responsive={options.responsive} > */}
                    {/* { data && data.map((productReview) => <h1>TTTTTTTTTTTT</h1>) } */}
                {/* </OWLcorusel> */}
                    {data.length > 0 && (<OWLcorusel   items='3'   center autoplayHoverPause dots loop  margin={6}  responsive={options.responsive} >
                        {  data.map((productReview) => <ProductReview productReview={ productReview } key={ productReview.id } />) }
                    </OWLcorusel>
                    )}
                </div>
            </div>
        </div>
    )
}

export default Reviews