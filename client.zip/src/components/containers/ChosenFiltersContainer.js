import React from 'react'
import FilteredBrand from '../items/products-page/FilteredBrand'
import FilteredCategory from '../items/products-page/FilteredCategory'
import FilteredColour from '../items/products-page/FilteredColour'
import FilteredMaxLoad from '../items/products-page/FilteredMaxLoad'
import FilteredMaxSpeed from '../items/products-page/FilteredMaxSpeed'
import './ChosenFiltersContainer.css'

const ChosenFiltersContainer = (props) => {
  const {
    // passAndChangeCategoryHandler
    removeHandler,
    chosenCategories,
    chosenBrands,
    chosenMaxSpeeds,
    chosenMaxLoads,
    chosenColours,
    passAndChangeCategoryHandler,
    passAndChangeBrandHandler,
    passAndChangeMaxSpeedHandler,
    passAndChangeMaxLoadHandler,
    passAndChangeColourHandler,
  } = props

  const chosenCategoriesList = chosenCategories.map((chosenCategory) => {
    return (
      <FilteredCategory
        onPass={passAndChangeCategoryHandler}
        key={chosenCategory.id}
        id={chosenCategory.id}
        removeHandler={removeHandler}
        chosenCategory={chosenCategory}
        passAndChangeChosenCategory={passAndChangeCategoryHandler}
      />
    )
  })

  const choseBrandsList = chosenBrands.map((chosenBrand) => {
    return (
      <FilteredBrand
        key={chosenBrand.id}
        chosenBrand={chosenBrand}
        id={chosenBrand.id}
        removeHandler={removeHandler}
        onPass={passAndChangeBrandHandler}
        passAndChangeChosenCategory={passAndChangeBrandHandler}
      />
    )
  })

  const chosenMaxSpeedsList = chosenMaxSpeeds.map((chosenMaxSpeed) => {
    return (
      <FilteredMaxSpeed
        key={chosenMaxSpeed.id}
        chosenMaxSpeed={chosenMaxSpeed}
        removeHandler={removeHandler}
        onPass={passAndChangeMaxSpeedHandler}
        passAndChangeChosenMaxSpeed={passAndChangeMaxSpeedHandler}
      />
    )
  })

  const chosenMaxLoadsList = chosenMaxLoads.map((chosenMaxLoad) => {
    return (
      <FilteredMaxLoad
        key={chosenMaxLoad.id}
        chosenMaxLoad={chosenMaxLoad}
        removeHandler={removeHandler}
        onPass={passAndChangeMaxLoadHandler}
        passAndChangeChosenMaxLoad={passAndChangeMaxLoadHandler}
      />
    )
  })

  const chosenColoursList = chosenColours.map((chosenColour) => {
    return (
      <FilteredColour
        key={chosenColour.id}
        chosenColour={chosenColour}
        onPass={passAndChangeColourHandler}
        passAndChangeChosenColour={passAndChangeColourHandler}
      />
    )
  })

  const noChosenItems =
    chosenCategoriesList.length === 0 &&
    choseBrandsList.length === 0 &&
    chosenMaxSpeedsList.length === 0 &&
    chosenMaxLoadsList.length === 0 &&
    chosenColoursList.length === 0

  return (
    <div className="chosen-filters__container">
      <div className="chosen-filters__filtered-items">
        {chosenCategoriesList}
        {choseBrandsList}
        {chosenMaxSpeedsList}
        {chosenMaxLoadsList}
        {chosenColoursList}
      </div>
      {!noChosenItems && (
        <button
          type="button"
          className="chosen-filters__reset-all-butn"
          // onClick={ () => {} }
        >
          reset all
        </button>
      )}
    </div>
  )
}

export default ChosenFiltersContainer
