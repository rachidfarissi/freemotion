import React from 'react'
import './AdTextContainer.css'

const AdTextContainer = () => {
  return (
    <div className="ad-text__container">
      <h2 className="ad-text__title"> Electric Scooters </h2>
      <h4 className="ad-text__subtitle">
        {' '}
        Why Walk When You Can Ride? FreeMotionshop Is Here With The Ultimate
        Solution!{' '}
      </h4>
      <p className="ad-text__content">
        It’s the 21st-century. Why use 20th-century technology to get around?
        Electric mobility is easy, efficient, hassle-free, and ecologically
        friendly. Electric scooters save time and money for the traveller or
        commuter.
      </p>
      <p className="ad-text__content">
        FreeMotionshop is the premier place to purchase an e scooter or other
        electric mobility device in the United States or Canada. The customer
        service team at FreeMotion can assist the customer to make the right
        decision when considering 21st-century electric mobility.
      </p>
      <p className="ad-text__content">
        Free Motion offers the latest technology in electric scooters and other
        mobility solutions. Why walk or search for a parking space when you can
        ride your own 21st-century transportation?
      </p>
      <h4 className="ad-text__subtitle"> A scooter for an Adult? </h4>
      <p className="ad-text__content">
        Think only kids love our vehicles? Well, you are wrong!
      </p>
      <p className="ad-text__content">
        An electric kick scooter (eScooter) is an adult kick scooter powered
        using 21st-century electric motors and computer systems for control. It
        has become obvious that electric mobility is the wave of the future.
        FreeMotion stands at the forefront of this emerging technology.
        eScooters provide high-speed, reliable, Urban transportation for the
        working adult.
      </p>
      <p className="ad-text__content">
        eScooters can use bike lanes and are not subject to urban traffic jams.
        They do not cause pollution. In the case of Stairs or other obstacles,
        the eScooter is foldable and can easily be carried over the obstacle.
        Then set it down and start riding again. The price of an eScooter is
        generally less than the yearly maintenance cost of an automobile. And
        parking is no worry; take it up to your office. eScooters have a very
        short learning curve and most people can ride one minute after seeing
        it.
      </p>
      <p className="ad-text__content">
        FreeMotionshop is the premier online website to shop for eScooter for
        adults in North America.
      </p>
      <h4 className="ad-text__subtitle"> But are eScooters worth it? </h4>
      <p className="ad-text__content">
        This is a resounding YES! But there are things to consider. An electric
        scooter or other electric mobility device carries you physically from
        place to place, sometimes at speeds exceeding a fast run. For this
        reason quality is important.
      </p>
      <p className="ad-text__content">
        FreeMotion has a great battery-powered scooter option that you can
        choose from, for example:
        <span> the Currus NF Electric scooter </span>
        <span> the Dualtron Raptor Electric scooter </span>
        <span> the Dualtron Thunder Electric Scooter </span>
      </p>
      <p className="ad-text__content">
        All of the above are very stylish & speedy commuting machines. These
        eScooters are solidly built but they represent the heavier end of the
        eScooter line.
      </p>
      <h4 className="ad-text__subtitle">
        {' '}
        Consider Lightweight Folding Mobility Scooters{' '}
      </h4>
      <p className="ad-text__content">
        Perhaps you do not commute to work but would want to enjoy outdoor
        outings with your family and friends. Then a lightweight foldable
        electric scooter would be a great option, These lightweight folding
        mobility scooters make all your regular activities more enjoyable and
        easy. A lightweight mobility scooter is compact and can be transported
        and used easily. These portable scooters for adults will increase your
        mobility and give you the independence to move around conveniently.
      </p>
      <p className="ad-text__content">
        Of course, the FreeMotion shop offers some of the best lightweight
        electric scooters available in the market.
      </p>
      <h4 className="ad-text__subtitle">
        {' '}
        The fastest Electric Scooters in 2020?{' '}
      </h4>
      <p className="ad-text__content">
        The Dualtron Raptor is the fastest e scooter of 2020. With its dual
        motors of 1300 watts, it is faster and more powerful than most scooters.
        Even with its small form factor, the motors provide a total output of
        2600 watts. This enables the scooter to ascend an incline as steep as 25
        degrees.
      </p>
      <p className="ad-text__content">
        Because of its small size, it’s a great choice for commuters who want to
        avoid traffic. The fastest electric scooter of 2020 is still a
        sustainable means of transportation. It doesn’t contribute to global
        warming and is ecologically friendly. So, go ahead and start browsing
        for brand new stylish electric scooter models on FreeMotionshop today.
      </p>
    </div>
  )
}

export default AdTextContainer
