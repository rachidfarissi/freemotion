import React , {useState} from 'react'
import './blogSubscribe.scss'


function BlogSubscribe() {
    
    const [email, setEmail] = useState("")

    function subscribe(event) {
        event.preventDefault(); 
        setEmail(email => "")
    }

    return(
        <form className='blogSubscribe' onSubmit={(e) => subscribe(e)}>
            <h2 className='blogSubscribe__title'>Subscribe for news</h2>
            <p className='blogSubscribe__text'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been</p>
            <input className='blogSubscribe__input' placeholder='Enter your email' onChange={e => setEmail(e.target.value)} value={email} type='email' required/>
            <button className='blogSubscribe__btn'>Subscribe</button>
        </form>
    )
}

export default BlogSubscribe