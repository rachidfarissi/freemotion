import React , { useState } from "react";
import './ExclusiveDeals.scss'


const ExclusiveDeals = () => {

    const [Text, setText] = useState("")

    const Subscribe = (event)  => {
        if(Text !== ""){
            alert(Text)
            setText(Text => "")
            event.preventDefault(); 
        }
        else {
            alert('error')
            event.preventDefault(); 
        }
    }

    return (
        <div className="exclusive-deals">
            <div className="exclusive-deals-container wrapper">
                <div className="exclusive-deals-content wrapper">
                    <h1 className="exclusive-deals__title"> Exclusive deals </h1>
                    <p className="exclusive-deals__text"> Want to receive exclusive deals on the latest products? Sign up below to get promo codes in your inbox </p>
                    <form name="" id="" className="exclusive-deals__subscribe-form" onSubmit={(e) => Subscribe(e)}>
                        <div className="exclusive-deals__subscribe-box">
                            <input type="text" placeholder="Enter your email" onChange={e => setText(e.target.value)} value={Text}/>
                            <button type="submit" className="exclusive-deals__subscribe-btn"> Subscribe </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default ExclusiveDeals;
