import React from 'react'
import { Link } from 'react-router-dom'
import './Footer.scss'
import { footerImages } from '../../dummy-datas/images'

const Footer = (props) => {
  const classes = `ecommerce-footer ${props.className}`

  return (
    <footer className={classes}>
      <section className="ecommerce-footer__container">
        <div className="ecommerce-footer__contact-info">
          <div className="ecommerce-footer__contact">
            <div className="ecommerce-footer__logo">
              <img src={footerImages.logoFooterIcon} alt="logo footer" />
            </div>
            <ul className="contact__list">
              <li>
                {' '}
                <address className="footer__location">
                  {' '}
                  San Diego, California, USA Montreal, QC, Canada{' '}
                </address>{' '}
              </li>
              <li>
                {' '}
                <a href="tel:+136262956599"> (626) 295-6599 </a>{' '}
                <a href="tel:+135149227332"> (514) 922-7332 </a>{' '}
              </li>
              <li>
                {' '}
                <a href="mailto:info@freemotion.com">
                  {' '}
                  info@freemotion.com{' '}
                </a>{' '}
              </li>
            </ul>
          </div>
          <div className="ecommerce-footer__acquaintance">
            <h4 className="acquaintance__title"> SHOP </h4>
            <ul className="acquaintance__list">
              <li>
                {' '}
                <Link to="#"> Electric Scooters </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="#"> Electric Unicycles </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="#"> E-Skateboards </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="#"> Hoverboards </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="#"> Used Certified </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="#"> Accessories </Link>{' '}
              </li>
            </ul>
          </div>
          <div className="ecommerce-footer__acquaintance">
            <h4 className="acquaintance__title"> CUSTOMER SERVICES </h4>
            <ul className="acquaintance__list">
              <li>
                {' '}
                <Link to="/support"> Contact Freemotion </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="affiliate-program"> Affiliate Program </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="/support"> Become Partner </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="/customer-testimonials">
                  {' '}
                  Customer Testimonials{' '}
                </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="#"> Freemotion Safety </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="/faq"> FAQ </Link>{' '}
              </li>
            </ul>
          </div>
          <div className="ecommerce-footer__acquaintance">
            <h4 className="acquaintance__title"> INFORMATION </h4>
            <ul className="acquaintance__list">
              <li>
                {' '}
                <Link to="/blog"> Our Blog </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="/about-us"> Our Story </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="/termsofuse"> Why Buy From Us </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="/shippingAndReturns"> Shipping & Returns </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="/financing"> Warranty policy </Link>{' '}
              </li>
              <li>
                {' '}
                <Link to="/buyingGuide"> Buying Guide </Link>{' '}
              </li>
            </ul>
          </div>
        </div>
        <div className="ecommerce-footer__payments">
          <div className="ecommerce-footer__duty-free">
            <img src={footerImages.dutyFreeIcon} alt="duty free" />
          </div>
          <div className="ecommerce-footer__payment-options">
            <div className="payment-options__klarna">
              <img src={footerImages.klarnaIcon} alt="klarna" />
            </div>
            <div className="payment-options__pay-bright">
              <img src={footerImages.payBrightIcon} alt="paybright" />
            </div>
            <div className="payment-options__visa-card">
              <img src={footerImages.visaCardIcon} alt="visa card" />
            </div>
            <div className="payment-options__american-express">
              <img
                src={footerImages.americanExpressIcon}
                alt="american express"
              />
            </div>
            <div className="payment-options__master-card">
              <img src={footerImages.masterCardIcon} alt="master card" />
            </div>
            <div className="payment-options__pay-pal">
              <img src={footerImages.payPalIcon} alt="PayPal" />
            </div>
          </div>
        </div>
        <div className="ecommerce-footer__extra-info">
          <div className="ecommerce-footer__copyrights">
            <p className="copyrights__text">
              {' '}
              © 2020 Freemotion. All Rights Reserved{' '}
            </p>
          </div>
          <div className="ecommerce-footer__extra-contacts">
            <ul className="ecommerce-nav__social-media">
              <li>
                <a
                  href="https://www.instagram.com/"
                  target="_blank"
                  rel="noreferrer noopener"
                >
                  <i className="ecommerce-nav__media-box media-box__insta" />
                </a>
              </li>
              <li>
                <a
                  href="https://www.facebook.com/"
                  target="_blank"
                  rel="noreferrer noopener"
                >
                  <i className="ecommerce-nav__media-box media-box__facebook" />
                </a>
              </li>
              <li>
                <a
                  href="https://twitter.com/"
                  target="_blank"
                  rel="noreferrer noopener"
                >
                  <i className="ecommerce-nav__media-box media-box__twitter" />
                </a>
              </li>
              <li>
                <a
                  href="https://www.youtube.com/"
                  target="_blank"
                  rel="noreferrer noopener"
                >
                  <i className="ecommerce-nav__media-box media-box__youtube" />
                </a>
              </li>
            </ul>
            <div className="ecommerce-footer__extra-info-pages">
              <ul className="extra-info-pages__list">
                <li>
                  {' '}
                  <Link to="/privacypolicy">
                    {' '}
                    Privacy Policy <em> | </em>{' '}
                  </Link>{' '}
                </li>
                <li>
                  {' '}
                  <Link to="/termsofservice">
                    {' '}
                    Terms and Conditions <em> | </em>{' '}
                  </Link>{' '}
                </li>
                <li>
                  {' '}
                  <Link to="#">
                    {' '}
                    Terms of Use <em> | </em>{' '}
                  </Link>{' '}
                </li>
                <li>
                  {' '}
                  <Link to="#"> Site Map </Link>{' '}
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </footer>
  )
}

export default Footer
