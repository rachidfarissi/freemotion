import React from 'react'
import './runingText.scss'
import leaf from './../../assets/icons/main/home/leaf.png'
import truck from './../../assets/icons/main/home/truck.png'



function RuningText(){
    return(
        <div className="runingText">
            <div className='left-gradient'/>
            <div className="runingText__slider-box ">
                <ul className="runingText__list">
                    <img src={leaf} alt='leaf icon'/>
                    <li> FREE SHIPPING FROM LOS ANGELES ACROSS USA & CANADA </li>
                    <img src={truck} alt='truck icon'/>
                    <li> canada duty free </li>
                </ul>
                <ul className="runingText__list">
                    <img src={leaf} alt='leaf icon'/>
                    <li> FREE SHIPPING FROM LOS ANGELES ACROSS USA & CANADA </li>
                    <img src={truck} alt='truck icon'/>
                    <li> canada duty free </li>
                </ul>
            </div>
            <div className='right-gradient'/>
        </div>
    )
}

export default RuningText