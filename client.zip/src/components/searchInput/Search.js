import React, {useState} from 'react'
import onClickOutside from 'react-onclickoutside';
// import { useHistory } from "react-router-dom";
import './searchInput.scss';
import search from './../../assets/icons/searchIcon.png'

function SearchInput(){
// function SearchInput({isSearchValue ,setIsSearchValue}){
    const [isSearchOpen, setIsSearchOpen] = useState(true)
    const [isSearchValue, setIsSearchValue] = useState("")
    // let history = useHistory();

    SearchInput.handleClickOutside = () => setIsSearchOpen(true);
    function searchData(event){
        event.preventDefault(); 
        if(isSearchValue.length === 1){
            alert(isSearchValue)
        }
    }
    function serchOpen(){
        if(window.innerWidth <= 650){
            setIsSearchOpen(isSearchOpen => !isSearchOpen)
            console.log(window.innerWidth) 
        }
        else{
            setIsSearchOpen(false)
        }
    }
    function serchRight(e){
        setIsSearchValue(e.target.value)
        // history.push("/search");
        console.log(isSearchValue)
    }

    return(
        <>
            <form className={isSearchOpen ? 'searchInp__Container' : 'searchInp__Container__mobile'} onSubmit={searchData}>
                <label className='searchInp__container'>
                    {/* <span className='visually-hidden'>searchInp</span> */}
                    <input className='searchInp' type='text' onChange={serchRight} value={isSearchValue}/>
                    <button className='searchInpBtn' type='submite'><img src={search} alt='searchIcon' className='searchIcon'/></button>
                </label>
            </form>
            <button className='searchBtn' onClick={serchOpen}>
                <img src={search} alt='searchIcon' className='searchIcon'/>
            </button>
        </>
    )
}

const clickOutsideConfig = {
    handleClickOutside: () =>
    SearchInput.handleClickOutside,
};
  
export default onClickOutside(SearchInput , clickOutsideConfig);