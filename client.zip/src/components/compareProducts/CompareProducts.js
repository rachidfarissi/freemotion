import React from 'react'
import './compareProducts.scss'
import { Link } from 'react-router-dom'
import bg from '../../assets/images/main/home/prod-13.png'

function CompareProducts() {
  return (
    <div className="compare-products">
      <div className="compare-products__box">
        <h2 className="compare-products__title">TTT Compare products </h2>
        <Link to="signup" className="compare-products__action" type="button">
          {' '}
          Get started{' '}
        </Link>
      </div>
      <img
        src={bg}
        className="compare-products__img"
        alt="products baner"
        draggable="false"
      />
    </div>
  )
}

export default CompareProducts
