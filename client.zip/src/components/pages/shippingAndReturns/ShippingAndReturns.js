import React from 'react';
import './shippingAndReturns.scss';
// import { Link } from 'react-router-dom';
import { ReactComponent as Trek } from '../../../assets/icons/support/Trek.svg';
import postalService from './../../../assets/icons/support/postalService.png'

import dutyFree from '../../../assets/images/dutyFree.png'


const ShippingAndReturns = () => {


    // const ulArr = ['Receiving defects or the wrong item111111111', 'Delayed shipment11111111111111111111' , 'We will apply restocking fees for opened, tested, or used items depending on the condition of the item.111111111111111111111' , '•  We, unfortunately, must require a 10% restocking fee for customer changing their minds or refusing a shipment.111111111111111111111111111']

    return (
        <div className="shippingAndReturns wrapper2">
            <div className="shippingAndReturns__container">

                <section className="shippingAndReturns__baner">
                    <div className="shippingAndReturns__baner-content">
                        <div>
                            <h1 className="shippingAndReturns__baner-title">FREE SHIPPING</h1>
                            <p className="shippingAndReturns__baner-text">from Los Angels across USA & CANADA</p>
                        </div>
                        <Trek  className="shippingAndReturns__baner-icon"/>
                    </div>
                    <img src={dutyFree} alt='dutyFree logo' className="shippingAndReturns__baner-logo"/>
                </section>
                <div>
                    <h1 className="shippingAndReturns__title">Shipping methods</h1>
                    <p className="shippingAndReturns__text">We work with the following carriers to deliver items. If you have an issue with your delivery, you can contact the carrier directly. </p>
                </div>
                <section className='shippingAndReturns__cards'>
                    {/* {ulArr.map((item) => (
                                <li className="shippingAndReturns__text">{item}</li>
                            ))} */}


                    <article className='shippingAndReturns__item'>
                        <div className='shippingAndReturns__item-content'>
                            <img src={postalService} className='shippingAndReturns__item-img' alt='compani logo'/>
                            <p className='shippingAndReturns__item-name'>Us Postal Service</p>
                        </div>
                        <div className='shippingAndReturns__item-tel'>
                            <a href='tel:1-800-742-5877' className='shippingAndReturns__item-number'>1-800-742-5877 </a>
                        </div>
                    </article>
                    <article className='shippingAndReturns__item'>
                        <div className='shippingAndReturns__item-content'>
                            <img src={postalService} className='shippingAndReturns__item-img' alt='compani logo'/>
                            <p className='shippingAndReturns__item-name'>Us Postal Service</p>
                        </div>
                        <div className='shippingAndReturns__item-tel'>
                            <a href='tel:1-800-742-5877' className='shippingAndReturns__item-number'>1-800-742-5877 </a>
                        </div>
                    </article>
                    <article className='shippingAndReturns__item'>
                        <div className='shippingAndReturns__item-content'>
                            <img src={postalService} className='shippingAndReturns__item-img' alt='compani logo'/>
                            <p className='shippingAndReturns__item-name'>Us Postal Service</p>
                        </div>
                        <div className='shippingAndReturns__item-tel'>
                            <a href='tel:1-800-742-5877' className='shippingAndReturns__item-number'>1-800-742-5877 </a>
                        </div>
                    </article>
                    <article className='shippingAndReturns__item'>
                        <div className='shippingAndReturns__item-content'>
                            <img src={postalService} className='shippingAndReturns__item-img' alt='compani logo'/>
                            <p className='shippingAndReturns__item-name'>Us Postal Service</p>
                        </div>
                        <div className='shippingAndReturns__item-tel'>
                            <a href='tel:1-800-742-5877' className='shippingAndReturns__item-number'>1-800-742-5877 </a>
                        </div>
                    </article>
                    
                </section>
                <div className='shippingAndReturns__content'>
                    <div className='shippingAndReturns__block'>
                        <h2 className="shippingAndReturns__title">Order traking</h2>
                        <p className="shippingAndReturns__text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                    </div>
                    <div className='shippingAndReturns__block'>
                        <h3 className="shippingAndReturns__subTitle">Order traking tips & considerations</h3>
                        <ul>
                            {/* {ulArr.map((item) => (
                                <li className="shippingAndReturns__text">{item}</li>
                            ))} */}
                            <li className="shippingAndReturns__text">*Please allow 1-2 additional business days processing time for all personalized products</li>
                            <li className="shippingAndReturns__text">*Shipping times may vary during high volume order periods</li>
                        </ul>
                    </div>
                    <div className='shippingAndReturns__block'>
                        <p className="shippingAndReturns__text">If your order has not shipped after three business days, you will receive an email notifying you.  Some reasons for the delay could include the following:</p>
                    </div>
                    <div className='shippingAndReturns__block'>
                        <ul>
                            {/* {ulArr.map((item) => (
                                <li className="shippingAndReturns__text">{item}</li>
                            ))} */}
                            <li className="shippingAndReturns__text"> We are experiencing higher order volume during this time</li>
                            <li className="shippingAndReturns__text"> Item(s) in your order may be on backorder in the next 72 hours</li>
                            <li className="shippingAndReturns__text"> Item(s) in your order may be out of stock due to high demand</li>
                            <li className="shippingAndReturns__text"> Shipping address outside of the continental United States</li>
                            <li className="shippingAndReturns__text"> A payment issue may have occurred while placing the order</li>
                        </ul>
                    </div>
                    <div className='shippingAndReturns__block'>
                        <p className="shippingAndReturns__text">If you need further assistance, please contact us at (626) 295-6599, and we are happy to assist.</p>
                    </div>
                </div>
                <div className='shippingAndReturns__content'>
                    <div className='shippingAndReturns__block'>
                        <h2 className="shippingAndReturns__title">Shipping time</h2>
                        <p className="shippingAndReturns__text">Due to the coronavirus's impact and the mandates in place, your order may experience a shipping delay. This delay is due to several factors, including travel restrictions, available staffing, and/or federal/state/local mandates.</p>
                        <ul>
                            {/* {ulArr.map((item) => (
                                <li className="shippingAndReturns__text">{item}</li>
                            ))} */}
                            <li className="shippingAndReturns__text">Standard shipping is 3-5 days plus an additional 1-3 days for processing.</li>
                            <li className="shippingAndReturns__text">Standard shipping of Personalized product is 3-5 days plus 2-6 days for processing.</li>
                        </ul>
                    </div>
                </div>
                <div className='shippingAndReturns__content'>
                    <div className='shippingAndReturns__block'>
                        <h2 className="shippingAndReturns__title">Return policy</h2>
                        <p className="shippingAndReturns__text">FreeMotion is happy to offer 14 days of free returns. A return request must meet the following criteria:</p>
                        <ul>                
                            {/* {ulArr.map((item) => (
                                <li className="shippingAndReturns__text">{item}</li>
                            ))} */}

                            <li className="shippingAndReturns__text"> Receiving defects or the wrong item</li> 
                            <li className="shippingAndReturns__text"> Delayed shipment</li> 
                            <li className="shippingAndReturns__text"> We will apply restocking fees for opened, tested, or used items depending on the condition of the item.</li> 
                            <li className="shippingAndReturns__text"> We, unfortunately, must require a 10% restocking fee for customer changing their minds or refusing a
                               shipment.</li> 
                            <li className="shippingAndReturns__text"> All customers must provide a Return Merchandise Authorization (RMA) code and a reason for the return.</li> 
                            <li className="shippingAndReturns__text"> We will gladly provide your refund 3 days after we receive the item and inspect it.</li> 
                            <li className="shippingAndReturns__text"> Any shipping charges incurred when returning the product to FreeMotion are the responsibility of the
                               customer. -Returned products must be undamaged, clean, and in otherwise new condition with all
                               original materials i.e. original packaging, manuals, and accessories, and must be accompanied by the
                               original invoice.</li> 
                            <li className="shippingAndReturns__text"> All customers must provide a Return Merchandise Authorization (RMA) code and a reason for the return.
                               Contact us for an RMA code.</li> 
                            <li className="shippingAndReturns__text"> We, unfortunately, must charge a minimum of 10% restocking fee for customers simply changing their
                               minds or refusing a shipment without one of the listed reasons.</li> 
                            <li className="shippingAndReturns__text"> Defective Device</li> 
                            <li className="shippingAndReturns__text"> Wrong Item received</li> 
                            <li className="shippingAndReturns__text"> Severely delayed shipment</li> 
                            <li className="shippingAndReturns__text"> We might apply additional restocking fees for opened, tested, or used items depending on the condition
                               of the item, on a case by case basis.</li> 
                            <li className="shippingAndReturns__text"> Any shipping charges incurred when returning the product to FreeMotion are the responsibility of the
                               customer.</li> 
                            <li className="shippingAndReturns__text"> All returned items will be inspected and a refund will be issued within 3 business days of receipt of the
                               item.</li> 
                            <li className="shippingAndReturns__text"> Returned products must be undamaged, clean, and in otherwise new condition with all original materials
                               i.e. original packaging, manuals, and accessories, and must be accompanied by the original invoice.</li> 
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ShippingAndReturns;
