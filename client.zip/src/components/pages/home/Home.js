import React from "react";
import './Home.css';
// import DiscountedProducts from "../../items/home-page/DiscountedProducts";
import DiscountedProduct from '../../discountedProduct/DiscountedProduct'
import ExclusiveRangeOfProducts from "../../items/home-page/ExclusiveRangeOfProducts";
import PopularBrands from '../../popularBrands/PopularBrands'
import Slider from './../../../components/sliderRelease/SliderRelease'
// import leaf from './../../../assets/icons/main/home/leaf.png'
// import truck from './../../../assets/icons/main/home/truck.png'
import { EXCLUSIVE_RANGE_OF_PRODUCTS } from "../../../dummy-datas/dummyDatas";
import ExclusiveDeals from "../../exclusiveDeals/ExclusiveDeals";
import Blog from "./../../../components/blog/Blog";
import Freemotion from "../../freemotions/freemotion";
import Reviews from "../../reviews/Reviews";
// import { Link } from "react-router-dom";
import CompareProducts from "../../compareProducts/CompareProducts";
import BestSeller from "../../bestSeller/BestSeller";
// import axios from "axios";
import RuningText from "../../runingText/RuningText";
import DiscountedProductComponent from "../../discountedProductComponent/DiscountedProductComponent";



const Home = () => {

    return (
        <section className="ecommerce-home">
            <DiscountedProductComponent/>
            <DiscountedProduct/>
            <div className="ecommerce-home__exclusive-range">
                { EXCLUSIVE_RANGE_OF_PRODUCTS.map((product) => <ExclusiveRangeOfProducts product={ product } key={ product.id } />) }
            </div>
            <RuningText/>
            <BestSeller/>
            <CompareProducts/>
            <Slider title={'New release'}/>
            <PopularBrands/>
            <Reviews/>
            <Freemotion/>
            <Blog/>
            <ExclusiveDeals/>
        </section>
    );
};

export default Home;