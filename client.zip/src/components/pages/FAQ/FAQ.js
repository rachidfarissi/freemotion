import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import FAQItem from '../../items/single-product-page/faqItem/FAQItem'
import Search from '../../../assets/icons/support/search.png'

// import FAQItem from '../../';
import './FAQ.scss'

import { ReactComponent as Mexa } from '../../../assets/icons/support/mexa.svg'
import { ReactComponent as Book } from '../../../assets/icons/support/Book.svg'
import { ReactComponent as Trek } from '../../../assets/icons/support/Trek.svg'
import { ReactComponent as List } from '../../../assets/icons/support/List.svg'

const FAQ = () => {
  const [searchValue, setSearchValue] = useState('')

  const search = (event) => {
    alert(searchValue)
    event.preventDefault()
  }

  let url = 'https://freemotion-shop-back.herokuapp.com'

  const [data, setData] = useState([])

  useEffect(() => {
    axios
      .post(`${url}/faq/list`, {
        category: [
          'string',
          'general',
          'shipping_returns',
          'warranty',
          'payment',
        ],
      })
      .then((res) => setData(res.data.faq))
      // .then(res => console.log(res.data.faq))
      .catch((e) => console.log(e))
  }, [])

  function dataFiltering(categoryName) {
    if (data) {
      const filtered = data.filter((item) => item.category === categoryName)
      return filtered.map((faq, index) => (
        <FAQItem faq={faq} key={faq.id} index={index} />
      ))
    }
  }

  // useEffect(() => {
  //     axios.post(`${url}/faq/list`,{
  //         "category": [
  //         "string", "general"
  //         ]
  //       })
  //     // .then(res => setData(res.data.faq))
  //     .then(res => setData(res.data.faq))
  //     .catch(e => console.log(e))
  // }, [])

  console.log(data, 'fuck')

  return (
    <div className="faq">
      <section className="faq__bg">
        <h1 className="faq__title">How can we help you?</h1>
        <form className="search" onSubmit={(e) => search(e)}>
          <img className="search__icon" src={Search} alt="search icon" />
          <input
            className="search__input"
            type="search"
            placeholder="What are you looking for?"
            onChange={(e) => setSearchValue(e.target.value)}
            value={searchValue}
          />
          <button className="search__btn">Search</button>
        </form>
      </section>
      <section className="support-nav wrapper">
        <Link to="/faq" className="support-nav__item">
          <List className="support-nav__item-img" alt="search icon" />
          General
        </Link>
        <Link to="/shippingAndReturns" className="support-nav__item">
          <Book className="support-nav__item-img" alt="search icon" />
          Shipping & Returns
        </Link>
        <Link to="buyingGuide" className="support-nav__item">
          <Trek className="support-nav__item-img" alt="search icon" />
          Buying guide
        </Link>
        <Link to="warrantyRegistration" className="support-nav__item">
          <Mexa className="support-nav__item-img" />
          Warranty registration
        </Link>
      </section>
      <div className="faq__container">
        <div className="faq__box">
          <h2 className="faq__title">General</h2>
          <div className="faq__content">
            {/* { data && data.map((faq, index) => <FAQItem faq={ faq } key={ faq.id } index={ index } />) } */}
            {dataFiltering('general')}
          </div>
        </div>
        <div className="faq__box">
          <h2 className="faq__title">Shipping & Returns</h2>
          <div className="faq__content">
            {/* { data && data.map((faq, index) => <FAQItem faq={ faq } key={ faq.id } index={ index } />) } */}
            {dataFiltering('shipping_returns')}
          </div>
        </div>
        <div className="faq__box">
          <h2 className="faq__title">Warranty</h2>
          <div className="faq__content">
            {/* { data && data.map((faq, index) => <FAQItem faq={ faq } key={ faq.id } index={ index } />) } */}
            {dataFiltering('warranty')}
          </div>
        </div>
        <div className="faq__box">
          <h2 className="faq__title">Payment</h2>
          <div className="faq__content">
            {/* { data && data.map((faq, index) => <FAQItem faq={ faq } key={ faq.id } index={ index } />) } */}
            {dataFiltering('payment')}
          </div>
        </div>
      </div>
    </div>
  )
}

export default FAQ
