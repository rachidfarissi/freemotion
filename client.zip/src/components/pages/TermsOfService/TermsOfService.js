import React from 'react'
import './termsOfService.scss'

function TermsOfService() {
  return (
    <div className="terms-of-service wrapper">
      <h1 className="terms-of-service__title">Freemotion Terms & Conditions</h1>
      <div className="terms-of-service__box">
        <h2 className="terms-of-service__subtitle">TERMS</h2>
        <h3 className="terms-of-service__box-name">Canada & USA Customers:</h3>
        <p className="terms-of-service__text">
          FreeMotion is happy to accept as payment all major credit cards,
          PayPal, and Klarna. We have financing options available – Klarna for
          US customers and Paybright for Canadian customers. We offer USD prices
          for United States customers and CAD prices for Canadian customers. If
          your item is in stock it will ship within 1-3 business days of
          approved and cleared payment. Orders are processed in order of receipt
          and approved payment. If your item is not in stock or stock is
          depleted it will be back-ordered. Back ordering generally adds an
          additional 2-10 business days. If the item will not be in stock within
          the backorder time period, you will have the option to wait for a
          backorder, modify the order, or cancel the order with a full refund.
          FreeMotion offers free shipping within Canada and the contiguous 48
          United States.
        </p>
        <p className="terms-of-service__box-name">International Customers:</p>
        <p className="terms-of-service__text">
          {' '}
          Freemotion does not currently ship internationally.{' '}
        </p>
      </div>
      <div className="terms-of-service__box">
        <h2 className="terms-of-service__subtitle">DELIVERY INFORMATION</h2>
        <p className="terms-of-service__text">
          All Domestic orders include Free Standard Shipping, excluding Alaska,
          Hawaii, and outlying territories.
        </p>
        <p className="terms-of-service__text">
          Under normal circumstances, your item(s) will ship from our U.S.
          Warehouse within 24-48 hours of your payment clearing. We only ship
          Monday through Friday. Any in-stock orders placed Friday through
          Sunday will ship the following week.
        </p>
        <p className="terms-of-service__text">
          We only ship to verified addresses which match the credit card used.
          We will not change the delivery address once payment has been
          submitted.
        </p>
        <p className="terms-of-service__text">
          The estimated delivery time is 4 to 5 days, except during holidays,
          when delivery may take longer.
        </p>
        <p className="terms-of-service__text">
          Your order will be shipped by the carrier that can best meet the
          delivery timeframe; we will use either FedEx or UPS if shipped within
          the continental 48 states and Canada.
        </p>
      </div>
      <div className="terms-of-service__box">
        <h2 className="terms-of-service__subtitle">DELIVERY INFORMATION</h2>
        <p className="terms-of-service__text">
          All Domestic orders include Free Standard Shipping, excluding Alaska,
          Hawaii, and outlying territories. All Domestic orders include Free
          Standard Shipping, excluding Alaska, Hawaii, and outlying territories.
          Under normal circumstances, your item(s) will ship from our U.S.
          Warehouse within 24-48 hours of your payment clearing. We only ship
          Monday through Friday. Any in-stock orders placed Friday through
          Sunday will ship the following week. We only ship to verified
          addresses which match the credit card used. We will not change the
          delivery address once payment has been submitted. The estimated
          delivery time is 4 to 5 days, except during holidays, when delivery
          may take longer. Your order will be shipped by the carrier that can
          best meet the delivery timeframe; we will use either FedEx or UPS if
          shipped within the continental 48 states and Canada.
        </p>
        <p className="terms-of-service__box-name">ORDER CANCELLATION:</p>
        <p className="terms-of-service__text">
          {' '}
          You can cancel your order if your item has not been shipped yet.
        </p>
        <p className="terms-of-service__text">
          If you refuse the package upon delivery, you will, unfortunately, be
          charged for the RETURN shipping.
        </p>
        <p className="terms-of-service__box-name">TRACKING PACKAGES:</p>
        <p className="terms-of-service__text">
          A tracking number will be provided once your item is shipped. A
          shipment notification, including the tracking number, will be sent to
          the email you provide us with.{' '}
        </p>
        <p className="terms-of-service__box-name">SHIPPING PROBLEMS:</p>
        <p className="terms-of-service__text">
          In case your order is not delivered or is delayed or lost please
          contact us by email or by phone as quickly as possible so that we may
          assist you.
        </p>
      </div>
      <div className="terms-of-service__box">
        <h2 className="terms-of-service__subtitle">GENERAL TERMS</h2>
        <p className="terms-of-service__text">
          All prices and specifications are subject to change without notice.
          Prices are final as of the time of your order. All products are
          shipped F.O.B. (Freight On Board) and become the sole property of the
          purchaser upon delivery to the specified shipping agent. In case of
          shipping damage, you should contact us immediately, so we can promptly
          file a damage claim with the carrier and expedite a replacement. Any
          discrepancy, including wrong items or missing items, should be
          reported to FreeMotion within 36 hours. By purchasing from our web
          site, you acknowledge that you have read and agreed to all terms and
          conditions. All brands and product names mentioned are trademarks
          and/or registered trademarks of their respective holders. Product
          images are for representation purposes only. Actual products may have
          slight cosmetic differences.
        </p>
        <p className="terms-of-service__box-name">
          Items Damaged During Transit:
        </p>
        <p className="terms-of-service__text">
          {' '}
          You can cancel your order if your item has not been shipped yet.
        </p>
        <p className="terms-of-service__text">
          If you refuse the package upon delivery, you will, unfortunately, be
          charged for the RETURN shipping.
        </p>
        <p className="terms-of-service__box-name">TRACKING PACKAGES:</p>
        <p className="terms-of-service__text">
          If you receive a damaged item, you must contact us within 7 days by
          calling +1 (626) 295-6599 /{' '}
        </p>
        <p className="terms-of-service__text">
          +1 (514) 922-7332, or by email at info@freemotionshop.com. If you do
          not contact us within this time period, your damage claim may be
          denied by the carrier. You assume all responsibility for the damaged
          item before it is picked up by the corresponding carrier agents.
        </p>
      </div>

      <div className="terms-of-service__box">
        <p className="terms-of-service__text">
          All prices and specifications are subject to change without notice.
          Prices are final as of the time of your order. All products are
          shipped F.O.B. (Freight On Board) and become the sole property of the
          purchaser upon delivery to the specified shipping agent. In case of
          shipping damage, you should contact us immediately, so we can promptly
          file a damage claim with the carrier and expedite a replacement. Any
          discrepancy, including wrong items or missing items, should be
          reported to FreeMotion within 36 hours. By purchasing from our web
          site, you acknowledge that you have read and agreed to all terms and
          conditions. All brands and product names mentioned are trademarks
          and/or registered trademarks of their respective holders. Product
          images are for representation purposes only. Actual products may have
          slight cosmetic differences.
        </p>
        <ul className="terms-of-service__ul">
          <li className="terms-of-service__list">
            Receiving defects or the wrong item
          </li>
          <li className="terms-of-service__list">Delayed shipment</li>
        </ul>
        <p className="terms-of-service__text">
          We will apply restocking fees for opened, tested, or used items
          depending on the condition of the item.
        </p>
        <p className="terms-of-service__text">
          We, unfortunately, must require a 10% restocking fee for customer
          changing their minds or refusing a shipment.
        </p>
        <p className="terms-of-service__text">
          All customers must provide a Return Merchandise Authorization (RMA)
          code and a reason for the return.
        </p>
        <p className="terms-of-service__text">
          We will gladly provide your refund 3 days after we receive the item
          and inspect it.
        </p>
        <p className="terms-of-service__text">
          Any shipping charges incurred when returning a product to FreeMotion
          are the responsibility of the customer. Returned products must be
          undamaged, clean, and in otherwise new condition with all original
          materials i.e. original packaging, manuals, and accessories, and must
          be accompanied by the original invoice.
        </p>
      </div>

      <div className="terms-of-service__box">
        <h2 className="terms-of-service__subtitle">WARRANTY INFORMATION</h2>
        <p className="terms-of-service__text">
          We offer a generous 12-month Limited Warranty that covers the original
          purchaser from any defects under normal use from the date of purchase.
          We also offer free technical support for 12 months, including the help
          of getting repair service and spare parts.
        </p>
        <p className="terms-of-service__text">
          We offer a 6 months warranty for our used certified items.
        </p>
        <p className="terms-of-service__text">
          Unfortunately, our warranty does not cover water damage or any kind of
          physical damage including road accidents.
        </p>
        <p className="terms-of-service__text">
          Items modified by the customer are not covered.
        </p>

        <p className="terms-of-service__box-name">Warranty Limitations:</p>
        <p className="terms-of-service__text">
          This Limited Warranty covers the original purchaser from any defects
          in material or workmanship under normal use for one year from the date
          of the invoice. This warranty is only offered to the original
          purchaser of the product and is not transferable to a subsequent
          purchaser.
        </p>
        <p className="terms-of-service__text">
          Freemotion will either repair or replace the product at no charge,
          using new or refurbished replacement parts at our discretion.
          Replacements may be different but functionally equivalent models. This
          Limited Warranty does not cover any problem that is caused by
          conditions, malfunctions, or damage not resulting from defects in
          material or workmanship. These conditions may include but are not
          limited to, road hazards, accidents, and improper operation or
          maintenance. Items returned for refund must be returned within 30 days
          from delivery. Under no circumstances will we issue refunds after 30
          days of delivery.
        </p>
        <p className="terms-of-service__box-name">
          Replacement Extended Warranty:
        </p>
        <p className="terms-of-service__text">
          All replacement products are covered by the standard warranty starting
          at the date of the original delivery. If for various reasons the
          replacement procedure extends beyond the warranty period, we at our
          discretion will extend the warranty coverage on such replacement up to
          an additional 30 days. Please be advised that this extended warranty
          is final and any additional extensions are non-negotiable.
        </p>
        <p className="terms-of-service__box-name">Limits and Exclusions:</p>
        <p className="terms-of-service__text">
          There are no express warranties except as listed above. FreeMotion
          shall not be liable for special, incidental, consequential or punitive
          damages, including, without limitation, direct or indirect damages for
          personal injury, loss of goodwill, profits or revenue, loss of use
          this product or any associated equipment, cost of substitute
          equipment, downtime cost, or any other losses, or claims of any party
          dealing with buyers from such damages, resulting from the use of or
          inability to use this product or arising from breach of warranty or
          contract, negligence, or any other legal theory.
        </p>
        <p className="terms-of-service__text">
          In no event shall FreeMotion be liable for any incidental, indirect,
          special or consequential damages or liabilities (including but not
          limited to incidental or consequential damages for loss of time,
          inconvenience, loss of use of product, or any other consequential or
          incidental loss) in connection with the purchase, use, or operation of
          the product. FreeMotion is not liable for property damage, personal
          injury, or death. All express and implied warranties, including the
          warranties of merchantability and fitness for a particular purpose,
          are limited to the applicable warranty period set forth above.
        </p>
      </div>
      <div className="terms-of-service__box">
        <h2 className="terms-of-service__subtitle">REPAIR REQUESTS</h2>
        <p className="terms-of-service__text">
          We do offer the option to repair our items. However, the customer must
          register the product for the warranty in our website.
        </p>
        <p className="terms-of-service__text">
          You must send a repair request through our repair form.
        </p>
        <p className="terms-of-service__text">
          You can ship the item back for repair only once its request is
          approved.
        </p>
        <p className="terms-of-service__text">
          The repair request can be sent by email or through our repair form
          request only.
        </p>
        <p className="terms-of-service__text">
          We offer two repairs center in the US and Canada; we also offer the
          option to provide parts and repair instructions for the customers who
          wish to do the repair/s themselves.
        </p>
        <p className="terms-of-service__text">
          You the customer have the responsibility for any damaged or lost
          packaging during the transit to our warehouse.
        </p>
        <p className="terms-of-service__text">
          You the customer have to pay the shipping to our repair center for
          repair.
        </p>
        <p className="terms-of-service__text">
          We do offer 7 days of customer service – we can be reached by phone or
          text, email, Facebook or Whatsapp.
        </p>
        <p className="terms-of-service__box-name">Cancellations:</p>
        <p className="terms-of-service__text">
          If you have placed an order, it has not yet shipped, and you wish to
          cancel, please forward your order confirmation to
          cancellation@freemotion.com to request cancel. Since the cancellation
          process may take up to 24 hours, please note that any orders that do
          ship in the meantime will have to be rejected and/or returned to us.
          Any shipping charges incurred when returning a product to FreeMotion
          are the responsibility of the customer. Furthermore, if received, the
          box should remain unopened. Once we receive the returned order, the
          refund will be processed within 48 hours. The shipping charge is not
          refundable. Thanks for your understanding and cooperation.
        </p>
        <p className="terms-of-service__box-name">State Law Rights:</p>
        <p className="terms-of-service__text">
          Some states do not allow the exclusion or limitation of incidental or
          consequential damages or limitations on how long an implied warranty
          lasts, so the above limitations or exclusions may not apply to you.
          This warranty gives you specific legal rights, and you may also have
          other rights, which vary, from state to state.
        </p>
        <p className="terms-of-service__text">
          We are not responsible for typographical errors. Product photos are
          for illustration only: the actual product may have cosmetic
          differences.
        </p>
      </div>
    </div>
  )
}

export default TermsOfService
