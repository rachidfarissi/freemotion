import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import FilterCard from '../../UI/cards/FilterCard'
import axios from 'axios'
import './Products.scss'
// import ReactPaginate from "react-hooks-paginator";
import {
  BRANDS,
  CATEGORIES,
  MAX_SPEEDS,
  MAX_LOADS,
  COLOURS,
  ELECTRIC_UNICYCLES,
} from '../../../dummy-datas/dummyDatas'
import CategoryItem from '../../items/products-page/CategoryItem'
import BrandItem from '../../items/products-page/BrandItem'
import SeeAllButton from '../../UI/buttons/SeeAllButton'
import MaxSpeedItem from '../../items/products-page/MaxSpeedItem'
import MaxLoadItem from '../../items/products-page/MaxLoadItem'
import ColourItem from '../../items/products-page/ColourItem'
import { Slider } from '@material-ui/core'
import ShowDropdown from '../../UI/dropdowns/ShowDropdown'
import SortByDropdown from '../../UI/dropdowns/SortByDropdown'
import ViewAsDropdown from '../../UI/dropdowns/ViewAsDropdown'
import ChosenFiltersContainer from '../../containers/ChosenFiltersContainer'
import GalleryViewElectricUnicycle from '../../items/products-page/galleryViewElectricUnicycle/GalleryViewElectricUnicycle'
import AdTextContainer from '../../containers/AdTextContainer'
import { useFilterByChecked } from '../../custom-hooks/filter-by-checked'

const Products = () => {
  const [filterAreaIsOpen, setFilterAreaIsOpen] = useState(true)
  const [allBrandsAreShown, setAllBrandsAreShown] = useState(false)
  const [allMaxSpeedsAreShown, setAllMaxSpeedsAreShown] = useState(false)
  const [chosenLimit, setChosenLimit] = useState(12)
  const [chosenViewOption, setChosenViewOption] = useState('_gallery_view')
  const [pageNumber, setPageNumber] = useState(0)
  const [allProcudts, setAllProducts] = useState({
    categories: [
      'Hoverboards',
      'Electric Unicycles',
      'Electric Scooter',
      'Electric Skateboards',
      'Extras',
    ],
  })
  const [selectBrand, setSelectBrand] = useState([])
  const [selectSpeed, setSelectSpeed] = useState([])

  // changing dummy datas states
  const [categories, passAndChangeCategoryHandler, chosenCategories] =
    useFilterByChecked(CATEGORIES)
  const [brands, passAndChangeBrandHandler, chosenBrands] =
    useFilterByChecked(BRANDS)
  const [maxSpeeds, passAndChangeMaxSpeedHandler, chosenMaxSpeeds] =
    useFilterByChecked(MAX_SPEEDS)
  const [maxLoads, passAndChangeMaxLoadHandler, chosenMaxLoads] =
    useFilterByChecked(MAX_LOADS)
  const [colours, passAndChangeColourHandler, chosenColours] =
    useFilterByChecked(COLOURS)

  // pagination
  const itemsPerPage = chosenLimit
  const pagesVisited = pageNumber * itemsPerPage
  const itemsQuantity = pagesVisited + itemsPerPage
  const pageCount = Math.ceil(ELECTRIC_UNICYCLES.length / itemsPerPage)

  // const changePageHandler = ({ selected }) => {
  //     setPageNumber(selected);
  // };

  // const prev = <img src={ productsMainImages.previousArrowIcon } alt="prev" />
  // const next = <img src={ productsMainImages.nextArrowIcon } alt="next" />

  const passLimitHandler = (limit) => {
    setChosenLimit(limit)
  }
  const passViewOptionHandler = (viewOption) => {
    setChosenViewOption(viewOption)
  }

  const SHOWN_BRANDS = allBrandsAreShown ? brands : brands.slice(0, 6)
  const SHOWN_MAX_SPEEDS = allMaxSpeedsAreShown
    ? maxSpeeds
    : maxSpeeds.slice(0, 8)
  const SHOWN_ELECTRIC_UNICYCLES = ELECTRIC_UNICYCLES.slice(
    pagesVisited,
    itemsQuantity
  )
  const [d, setd] = useState(false)

  let url = 'https://freemotion-shop-back.herokuapp.com'

  const [data, setData] = useState()

  useEffect(() => {
    axios
      .post(`${url}/product/filter`, allProcudts)
      .then((res) => setData(res.data.product))
      .catch((e) => console.log(e))
  }, [allProcudts])

  function hendelCategory() {
    console.log(chosenColours, 'chosenColor')
    let arr = []
    let brand = []
    let speed = []
    let maxLoad = []
    let color = []
    chosenCategories.map((item) => {
      if (item.categoryTitle === 'All Products') {
        arr.push(
          'Hoverboards',
          'Electric Unicycles',
          'Electric Scooter',
          'Electric Skateboards',
          'Extras'
        )
      } else {
        arr.push(item.categoryTitle)
      }
      return arr
    })
    if (arr.length) {
      let filteredItems = arr.filter((v, i) => arr.indexOf(v) === i)
      setAllProducts((prevState) => {
        return {
          ...prevState,
          categories: filteredItems,
        }
      })
    } else {
      setAllProducts((prevState) => {
        return {
          ...prevState,
          categories: [
            'Hoverboards',
            'Electric Unicycles',
            'Electric Scooter',
            'Electric Skateboards',
            'Extras',
          ],
        }
      })
    }
    chosenBrands &&
      chosenBrands.map((selectedBrand) => {
        if (selectedBrand.brandTitle === 'All Brands') {
          brand.push(
            'Minimotors',
            'Dualtron e-Scooter',
            'Speedway e-Scooter',
            'Weped',
            'Currus',
            'Immotion',
            'Kingsong'
          )
        } else {
          brand.push(selectedBrand.brandTitle)
        }
        return brand
      })

    if (brand.length) {
      let filteredItem = brand.filter((v, i) => brand.indexOf(v) === i)
      setAllProducts((prevState) => {
        return {
          ...prevState,
          brand: filteredItem,
        }
      })
    } else {
      setAllProducts((prevState) => {
        return {
          ...prevState,
          brand: undefined,
        }
      })
    }
    chosenMaxSpeeds &&
      chosenMaxSpeeds.map((chosenSpeed) => {
        speed.push(+chosenSpeed.speedNum)
        return speed
      })
    if (speed.length) {
      setAllProducts((prevState) => {
        return {
          ...prevState,
          max_speed_filter: speed,
        }
      })
    } else {
      setAllProducts((prevState) => {
        return {
          ...prevState,
          max_speed_filter: undefined,
        }
      })
    }
    chosenMaxLoads &&
      chosenMaxLoads.map((chosenLoad) => {
        if (chosenLoad.loadNum === '120-150') {
          maxLoad.push(120, 130, 140, 150)
        } else {
          maxLoad.push(+chosenLoad.loadNum)
        }
        return maxLoad
      })
    if (maxLoad.length) {
      let filteredItem = maxLoad.filter((v, i) => maxLoad.indexOf(v) === i)
      setAllProducts((prevState) => {
        return {
          ...prevState,
          max_load_filter: filteredItem,
        }
      })
    } else {
      setAllProducts((prevState) => {
        return {
          ...prevState,
          max_load_filter: undefined,
        }
      })
    }
    chosenColours &&
      chosenColours.map((selectedColor) => {
        color.push(selectedColor.colour)
        return color
      })
    if (color.length) {
      setAllProducts((prevState) => {
        return {
          ...prevState,
          colour: color,
        }
      })
    } else {
      setAllProducts((prevState) => {
        return {
          ...prevState,
          colour: undefined,
        }
      })
    }
  }

  return (
    <section className="ecommerce-products">
      <div className="ecommerce-products__navigation wrapper2">
        <ul className="ecommerce-products__navigation-list">
          <li>
            <Link to="/"> Home / </Link>
          </li>
          <li>
            <Link to="*"> Trending / </Link>
          </li>
          <li>
            <Link to="/products"> Products TTTT </Link>
          </li>
        </ul>
      </div>
      <div className="ecommerce-products__container wrapper2">
        <div className="ecommerce-products__filter-bar">
          <button
            type="button"
            className="filter-bar__btn"
            onClick={() => setFilterAreaIsOpen((prevState) => !prevState)}
          >
            <i className="filter-bar__icon" />
            <h4 className="filter-bar__title"> Filter </h4>
          </button>
          {filterAreaIsOpen && (
            <React.Fragment>
              <FilterCard title="Price">
                <Slider />
              </FilterCard>
              <FilterCard title="Categories">
                <ul className="filter-bar__items-list">
                  {categories.map((category, index) => {
                    return (
                      <CategoryItem
                        key={index}
                        category={category}
                        chosenCategories={chosenCategories}
                        hendelCategory={hendelCategory}
                        onPass={passAndChangeCategoryHandler}
                      />
                    )
                  })}
                </ul>
              </FilterCard>
              <FilterCard title="Brands">
                <ul className="filter-bar__items-list">
                  {SHOWN_BRANDS.map((brand, index) => {
                    return (
                      <BrandItem
                        key={index}
                        brand={brand}
                        chosenBrands={chosenBrands}
                        hendelCategory={hendelCategory}
                        onPass={passAndChangeBrandHandler}
                      />
                    )
                  })}
                </ul>
                {!allBrandsAreShown && (
                  <SeeAllButton onShow={() => setAllBrandsAreShown(true)} />
                )}
              </FilterCard>
              <FilterCard title="Max Speed">
                <ul className="filter-bar__items-list">
                  {SHOWN_MAX_SPEEDS.map((maxSpeed, index) => {
                    return (
                      <MaxSpeedItem
                        key={index}
                        maxSpeed={maxSpeed}
                        hendelCategory={hendelCategory}
                        onPass={passAndChangeMaxSpeedHandler}
                      />
                    )
                  })}
                </ul>
                {!allMaxSpeedsAreShown && (
                  <SeeAllButton onShow={() => setAllMaxSpeedsAreShown(true)} />
                )}
              </FilterCard>
              <FilterCard title="Max Load">
                <ul className="filter-bar__items-list">
                  {maxLoads.map((maxLoad, index) => {
                    return (
                      <MaxLoadItem
                        key={index}
                        maxLoad={maxLoad}
                        hendelCategory={hendelCategory}
                        onPass={passAndChangeMaxLoadHandler}
                      />
                    )
                  })}
                </ul>
              </FilterCard>
              <FilterCard title="Colour">
                <ul className="filter-bar__items-list">
                  {colours.map((colour, index) => {
                    return (
                      <ColourItem
                        key={index}
                        colour={colour}
                        index={index}
                        hendelCategory={hendelCategory}
                        onPass={passAndChangeColourHandler}
                      />
                    )
                  })}
                </ul>
              </FilterCard>
            </React.Fragment>
          )}
        </div>
        <div className="ecommerce-products__all-products">
          <h2 className="all-products__title"> Products </h2>
          <div className="all-products__actions">
            <div className="actions__products-show">
              <p className="all-products__result-text">
                <span className="all-products__result-span"> 1-24 </span>
                of
                <span className="all-products__result-span"> 48 Results </span>
              </p>
              <ShowDropdown onPass={passLimitHandler} />
            </div>
            <div className="actions__products-actions">
              <SortByDropdown />
              <ViewAsDropdown onPass={passViewOptionHandler} />
            </div>
          </div>
          <ChosenFiltersContainer
            // onPass={ passAndChangeCategoryHandler }
            // onPass={ passAndChangeCategoryHandler }
            // category={ category }
            chosenCategories={chosenCategories}
            chosenBrands={chosenBrands}
            chosenMaxSpeeds={chosenMaxSpeeds}
            chosenMaxLoads={chosenMaxLoads}
            chosenColours={chosenColours}
            passAndChangeCategoryHandler={passAndChangeCategoryHandler}
            passAndChangeBrandHandler={passAndChangeBrandHandler}
            passAndChangeMaxSpeedHandler={passAndChangeMaxSpeedHandler}
            passAndChangeMaxLoadHandler={passAndChangeMaxLoadHandler}
            passAndChangeColourHandler={passAndChangeColourHandler}
          />
          <div
            className={
              chosenViewOption === '_gallery_view'
                ? 'ecommerce-products__electric-unicycles'
                : 'ecommerce-products__electric-unicycles--lineCard'
            }
          >
            {
              // (chosenViewOption === "_gallery_view") && (
              data &&
                data.map((unicycle, index) => {
                  return (
                    <GalleryViewElectricUnicycle
                      // key={unicycle.product[0].id}
                      unicycle={unicycle.product[0]}
                      index={index}
                      chosenViewOption={chosenViewOption}
                      allProcudts={allProcudts}
                    />
                  )
                })
              // )
            }
            {/* {
                            (chosenViewOption === "_list_view") && (
                                SHOWN_ELECTRIC_UNICYCLES.map((unicycle, index) => {
                                    return (
                                        <ListViewElectricUnicycle 
                                            key={ unicycle.id }
                                            unicycle={ unicycle }
                                            index={ index }
                                        />
                                    );
                                })
                            )
                        } */}
          </div>

          {/* <ReactPaginate 
                        previousLabel={ prev } 
                        nextLabel={ next }
                        pageCount={ pageCount }
                        onPageChange={ changePageHandler }
                        containerClassName="pagination-butns"
                        previousLinkClassName="previous-butn"
                        nextLinkClassName="next-butn"
                        disabledClassName="pagination-disabled"
                        activeClassName="pagination-active"
                    /> */}
          <AdTextContainer />
        </div>
      </div>
    </section>
  )
}

export default Products
