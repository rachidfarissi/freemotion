import React, { useState, useEffect } from 'react'
import BlogItem from '../../items/home-page/blogItem/BlogItem'
import { BLOG_LIST } from '../../../dummy-datas/dummyDatas'
import './singleBlogSlider.scss'

import OWLcorusel from 'react-owl-carousel'
import 'owl.carousel/dist/assets/owl.carousel.min.css'
import 'owl.carousel/dist/assets/owl.theme.default.min.css'
import axios from 'axios'

const options = {
  responsive: {
    0: {
      items: 1,
    },
    400: {
      items: 1,
    },
    650: {
      items: 2,
    },
    1000: {
      items: 3,
    },
  },
}

const SingleBlogSlider = () => {
  const [Text, setText] = useState('')

  console.log('true')

  const Subscribe = (event) => {
    if (Text !== '') {
      alert(Text)
      setText((Text) => '')
      event.preventDefault()
    } else {
      alert('error')
      event.preventDefault()
    }
  }

  return (
    <div className="home__blog">
      <div className="home__blog-container">
        <h2 className="home__blog__title wrapper"> Blog </h2>
        <div className="blog__blog__slider wrapper">
          <OWLcorusel
            items="4"
            autoplay
            center
            autoplayHoverPause
            dots
            loop
            margin={6}
            responsive={options.responsive}
          >
            {BLOG_LIST.map((blog) => (
              <BlogItem blog={blog} key={blog.id} />
            ))}
          </OWLcorusel>
        </div>
      </div>
    </div>
  )
}

export default SingleBlogSlider
