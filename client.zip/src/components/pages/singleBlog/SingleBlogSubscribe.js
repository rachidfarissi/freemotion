import React, { useState } from 'react'
import './singleBlogSubscribe.scss'

const SingleBlogSubscribe = () => {
  const [Text, setText] = useState('')

  const Subscribe = (event) => {
    if (Text !== '') {
      alert(Text)
      setText((Text) => '')
      event.preventDefault()
    } else {
      alert('error')
      event.preventDefault()
    }
  }

  return (
    <div className="exclusive-deals">
      <div className="exclusive-deals-container wrapper">
        <div className="exclusive-deals-content wrapper">
          <h1 className="exclusive-deals__title"> Subscribe for news </h1>
          <p className="exclusive-deals__text">
            {' '}
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been
          </p>
          <form
            name=""
            id=""
            className="exclusive-deals__subscribe-form"
            onSubmit={(e) => Subscribe(e)}
          >
            <div className="exclusive-deals__subscribe-box">
              <input
                type="text"
                placeholder="Enter your email"
                onChange={(e) => setText(e.target.value)}
                value={Text}
              />
              <button type="submit" className="exclusive-deals__subscribe-btn">
                {' '}
                Subscribe{' '}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default SingleBlogSubscribe
