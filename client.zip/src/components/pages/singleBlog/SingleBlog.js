import React, { useState, useEffect } from 'react'
import './singleBlog.scss'
import Image from '../../../assets/images/renderImage.png'
import BlogAuthor from '../../../assets/images/blogAuthor.png'
import BlogComparison from '../../../assets/images/blogComparison.png'
import BlogVideo from '../../../assets/images/blogVideo.png'
import FacebookIcon from '../../../assets/images/facebook.png'
import LinkdinIcon from '../../../assets/images/linkdin.png'
import TwitterIcon from '../../../assets/images/Twitter.png'
import CopyIcon from '../../../assets/images/copy.png'
import BlogSubscribe from '../../../assets/images/blogSubscribe.png'
import SingleBlogSlider from './SingleBlogSlider'
import SingleBlogSubscribe from './SingleBlogSubscribe'

const SingleBlog = () => {
  return (
    <div className="singleBlog">
      <div className="singleBlog_header">
        <div className="singleBlog_header_block">
          <div>
            <img src={Image} alt="blogImg" />
          </div>
          <div className="test">
            <div className="singleBlog_content">
              <div className="singleBlog_content_category">
                Electric Unicycles
              </div>
              <p>8 min read</p>
            </div>
            <div className="singleBlog_title">
              <h1>
                How To Maximize Electric Scooters And Electric Unicycles
                Lithium-ion Battery Lifespan?
              </h1>
            </div>
            <div className="singleBlog_author">
              <img src={BlogAuthor} />
              <div className="singleBlog_author_desc">
                <p>John Smith</p>
                <p>March 5, 2020</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="singleBlog_description">
        <div className="singleBlog_description_content">
          <p>
            InMotion's electric unicycle lineup is sleek, modern, and uniform -
            but there are some pretty large differences between them. So which
            one is the best model for you? The most important thing to consider
            is your intended usage habits. Urban commuters may have drastically
            different needs compared to those who seek pure outdoor adventure
            and exploration. Ask yourself the following questions:
          </p>
          <div className="singleBlog_description_content_border">
            <p>
              1. Where do I plan to ride on a regular basis, and how much room
              do I have to stow my wheel throughout the day?
            </p>
            <p>
              2. Where do I plan to ride on a regular basis, and how much room
              do I have to stow my wheel throughout the day?
            </p>
            <p>
              3. Where do I plan to ride on a regular basis, and how much room
              do I have to stow my wheel throughout the day?
            </p>
            <p>
              4. Where do I plan to ride on a regular basis, and how much room
              do I have to stow my wheel throughout the day?
            </p>
            <p>
              5. Where do I plan to ride on a regular basis, and how much room
              do I have to stow my wheel throughout the day?
            </p>
          </div>
          <div className="singleBlog_description_comparison">
            <h2>Size Comparison</h2>
            <img src={BlogComparison} />
            <h4>V10 / V10F</h4>
            <h5>Performance King</h5>
            <h6>V10 Product Page</h6>
            <p>
              This is by far our most powerful, fastest, and longest range
              electric unicycle. But that doesn't mean it's the obvious choice
              for everyone, as all that range and power adds to the overall
              weight, size, and price. However, for those seeking incredible
              performance, V10 manages to do all of this in a remarkably thin
              and sleek package. These important considerations also make V10 as
              comfortable to ride as it is exhilarating. With its large
              cushioned pedals and advanced firmware ride mode customizations,
              there is a very noticeable upgrade in ride quality that makes it
              the clear choice for anyone seeking the most advanced model. If
              you more speed, range, and raw power, this is the wheel for you.
            </p>
            <p className="singleBlog_description_comparison_padding">
              Payload Recommendation: Up to ~220lbs for great performance.
              Structural support is rated up to 260lbs by InMotion, but riders
              above the 200 - 220 lbs range will start to notice some degraded
              performance in speed and range.
            </p>
            <h4>V8 / Glide 3</h4>
            <h5>Best All-Arounder & Bang For Your Buck</h5>
            <h6>V8 Product Page</h6>
            <p>
              This is by far our most powerful, fastest, and longest range
              electric unicycle. But that doesn't mean it's the obvious choice
              for everyone, as all that range and power adds to the overall
              weight, size, and price. However, for those seeking incredible
              performance, V10 manages to do all of this in a remarkably thin
              and sleek package. These important considerations also make V10 as
              comfortable to ride as it is exhilarating. With its large
              cushioned pedals and advanced firmware ride mode customizations,
              there is a very noticeable upgrade in ride quality that makes it
              the clear choice for anyone seeking the most advanced model. If
              you more speed, range, and raw power, this is the wheel for you.
            </p>
            <p className="singleBlog_description_comparison_padding">
              Payload Recommendation: Up to ~220lbs for great performance.
              Structural support is rated up to 260lbs by InMotion, but riders
              above the 200 - 220 lbs range will start to notice some degraded
              performance in speed and range.
            </p>
            <h4>V5F / Glide 2</h4>
            <h5>Champion Of Portability, Lowest Price Point</h5>
            <h6>Glide 2 Product Page</h6>
            <p>
              This is by far our most powerful, fastest, and longest range
              electric unicycle. But that doesn't mean it's the obvious choice
              for everyone, as all that range and power adds to the overall
              weight, size, and price. However, for those seeking incredible
              performance, V10 manages to do all of this in a remarkably thin
              and sleek package. These important considerations also make V10 as
              comfortable to ride as it is exhilarating. With its large
              cushioned pedals and advanced firmware ride mode customizations,
              there is a very noticeable upgrade in ride quality that makes it
              the clear choice for anyone seeking the most advanced model. If
              you more speed, range, and raw power, this is the wheel for you.
            </p>
            <p className="singleBlog_description_comparison_padding">
              Payload Recommendation: Up to ~220lbs for great performance.
              Structural support is rated up to 260lbs by InMotion, but riders
              above the 200 - 220 lbs range will start to notice some degraded
              performance in speed and range.
            </p>
          </div>
          <div className="singleBlog_description_title">
            <p>Title</p>
            <div className="singleBlog_description_title_block">
              <p>
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make a type specimen book.
              </p>
            </div>
          </div>
          <div className="singleBlog_description_video">
            <p>Comparison</p>
            <img src={BlogVideo} />
          </div>
          <div className="singleBlog_description_share">
            <div>
              <span>Share Post</span>
            </div>
            <div className="singleBlog_description_share_icons">
              <img src={LinkdinIcon} />
              <img src={FacebookIcon} />
              <img src={TwitterIcon} />
              <img src={CopyIcon} />
            </div>
          </div>
          <div className="singleBlog_description_hashtag">
            <p>
              <span>#</span>electric unicycles
            </p>
            <p>
              <span>#</span>
              electric unicycles
            </p>
          </div>
        </div>
      </div>
      <div className="singleBlog_slider">
        <SingleBlogSlider />
      </div>
      <SingleBlogSubscribe />
    </div>
  )
}

export default SingleBlog
