import React from 'react'
import { useHistory } from 'react-router'
import DarkButton from '../UI/buttons/DarkButton'
import './Congratulations.css'

function Congratulations() {
  const history = useHistory()

  return (
    <div className="ecommerce__congratulations">
      <div className="congratulations__container">
        <div className="congratulations__content">
          <h2 className="congratulations__title"> Congratulations </h2>
          <p className="congratulations__msg-text">
            {' '}
            Password has been successfully changed.{' '}
          </p>
          <DarkButton
            className="congratulations__login-btn"
            butnType="button"
            label="Log In"
            onButnClick={() => history.push('/sign-in')}
          />
        </div>
      </div>
    </div>
  )
}

export default Congratulations
