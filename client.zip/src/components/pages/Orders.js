import React from 'react'
import './Orders.css'

export default function Orders() {
  return <div>orders ctx here</div>
}
