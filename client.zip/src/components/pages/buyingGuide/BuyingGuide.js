import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import FAQItem from '../../items/single-product-page/faqItem/FAQItem'
import BuyingGuideItem from '../../items/buyingGuide/BuyingGuideItem'
import axios from 'axios'
// import Search from '../../../assets/icons/support/search.png';

// import FAQItem from '../../';
import './buyingGuide.scss'

const BuyingGuide = () => {
  const FAQ_ITEM_TITLE = 'Cost'
  const FAQ_ITEM_TEXT =
    'Starting around $750, Electric Scooters are within the reach of just about anyone, with an acquisition cost less than the yearly maintenance cost of an automobile. '
  const FAQ_ITEM_DESCRIPTION =
    'It is possible to find electric scooters far cheaper than the above-quoted price. At this price point expect under-powered motors, low capacity batteries, small wheels, and worst of all weak brakes. Any scooters in this LOW BUDGET class are not recommended for anything but minimal or light recreational use, and then only with close attention to safety. A few dollars pays for a lot of safety. '

  // const [searchValue, setSearchValue] = useState('')
  const [openCast, setOpenCast] = useState(true)

  // const search = (event) => {
  //     alert(searchValue)
  //     event.preventDefault();
  // }

  let url = 'https://freemotion-shop-back.herokuapp.com'

  const [data, setData] = useState([])

  useEffect(() => {
    axios
      .get(`${url}/faq/list`)
      .then((res) => setData(res.data.faq))
      // .then(res => console.log(res.data.faq))
      .catch((e) => console.log(e))
  }, [url])

  // console.log(data)

  return (
    <div className="buyingGuide wrapper2">
      <h1 className="buyingGuide__Title">Buying guide for beginners</h1>
      <p className="buyingGuide__Text">
        Electric Scooters may be the ideal solution for personal transport.
        Using a scooter is easy, without the hassle or cost associated with
        public transport or driving. No need to find a parking space, no need
        for a garage.
      </p>
      <div className="buyingGuide__page">
        <div className="buyingGuide__nav">
          <p
            className="buyingGuide__nav-cose"
            onClick={() => setOpenCast((openCast) => !openCast)}
          >
            Cost
          </p>
          {openCast ? (
            <nav>
              <ul className="buyingGuide__nav-ul">
                <li className="buyingGuide__nav-item">
                  <Link to="">Easy to use</Link>
                </li>
                <li className="buyingGuide__nav-item">
                  <Link to="">Comfort</Link>
                </li>
                <li className="buyingGuide__nav-item">
                  <Link to="">Safety</Link>
                </li>
                <li className="buyingGuide__nav-item">
                  <Link to="">Range</Link>
                </li>
                <li className="buyingGuide__nav-item">
                  <Link to="">Battery</Link>
                </li>
                <li className="buyingGuide__nav-item">
                  <Link to="">Capacity</Link>
                </li>
                <li className="buyingGuide__nav-item">
                  <Link to="faq">FAQ</Link>
                </li>
              </ul>
            </nav>
          ) : null}
        </div>
        <div className="buyingGuide__container">
          <sectin className="buyingGuide__items">
            <BuyingGuideItem
              title={FAQ_ITEM_TITLE}
              text={FAQ_ITEM_TEXT}
              description={FAQ_ITEM_DESCRIPTION}
            />
            <BuyingGuideItem
              title={FAQ_ITEM_TITLE}
              text={FAQ_ITEM_TEXT}
              description={FAQ_ITEM_DESCRIPTION}
            />
            <BuyingGuideItem
              title={FAQ_ITEM_TITLE}
              text={FAQ_ITEM_TEXT}
              description={FAQ_ITEM_DESCRIPTION}
            />
            {/* <div className='buyingGuide__item'>

                        </div>
                        <div className='buyingGuide__item'>

                        </div>
                        <div className='buyingGuide__item'>

                        </div> */}
          </sectin>
          <div className="buyingGuide__box">
            <h2 className="buyingGuide__title">Electric Unicycle safety FAQ</h2>
            <div className="buyingGuide__content">
              {data &&
                data.map((faq, index) => (
                  <FAQItem faq={faq} key={faq.id} index={index} />
                ))}
              {/* <FAQItem 
                                title={ FAQ_ITEM_TITLE }
                                text={ FAQ_ITEM_TEXT }
                            />
                            <FAQItem 
                                title={ FAQ_ITEM_TITLE }
                                text={ FAQ_ITEM_TEXT }
                            /> */}
            </div>
          </div>
          <div className="buyingGuide__box">
            <h2 className="buyingGuide__title">
              Owning an electric unicycle FAQ
            </h2>
            <div className="buyingGuide__content">
              {data &&
                data.map((faq, index) => (
                  <FAQItem faq={faq} key={faq.id} index={index} />
                ))}
              {/* <FAQItem 
                                title={ FAQ_ITEM_TITLE }
                                text={ FAQ_ITEM_TEXT }
                            />
                            <FAQItem 
                                title={ FAQ_ITEM_TITLE }
                                text={ FAQ_ITEM_TEXT }
                            />
                            <FAQItem 
                                title={ FAQ_ITEM_TITLE }
                                text={ FAQ_ITEM_TEXT }
                            /> */}
            </div>
          </div>
          <div className="buyingGuide__box">
            <h2 className="buyingGuide__title">
              Buying an electric unicycle FAQ
            </h2>
            <div className="buyingGuide__content">
              {data &&
                data.map((faq, index) => (
                  <FAQItem faq={faq} key={faq.id} index={index} />
                ))}
              {/* <FAQItem 
                                title={ FAQ_ITEM_TITLE }
                                text={ FAQ_ITEM_TEXT }
                            />
                            <FAQItem 
                                title={ FAQ_ITEM_TITLE }
                                text={ FAQ_ITEM_TEXT }
                            />
                            <FAQItem 
                                title={ FAQ_ITEM_TITLE }
                                text={ FAQ_ITEM_TEXT }
                            />
                            <FAQItem 
                                title={ FAQ_ITEM_TITLE }
                                text={ FAQ_ITEM_TEXT }
                            />
                            <FAQItem 
                                title={ FAQ_ITEM_TITLE }
                                text={ FAQ_ITEM_TEXT }
                            /> */}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default BuyingGuide
