import React , { useState } from "react";
import { Link } from 'react-router-dom';
import './noMatch.scss'
import Slider from '../../sliderRelease/SliderRelease';
import error404 from './../../../assets/images/error404.png'
import searchIcon from './../../../assets/icons/search.png'
import arrow from './../../../assets/images/financing/arrow.png'



function NoMatch() {

    const [ searchValue , setSearchValue ] = useState('')

    const search = (evt) => {
        evt.preventDefault();
        console.log(searchValue)
    }


    return(
        <div className='noMatch'>
            <div className='noMatch__nav'>

            </div>
            <div className='noMatch__container wrapper2'>
                <Link to='/' className='noMatch__link'><img src={arrow} alt='arrow icon'  className='noMatch__link-arrow'/>Go to home</Link>
                <h1 className='noMatch__title'>Oops !</h1>
                <p className='noMatch__text'>That page can’t be found</p>
                <img src={error404} alt='error pic' className='noMatch__img'/>
                <p className='noMatch__text'>Nothing has been found at this location. </p>
                <p className='noMatch__text'>Try searching, or check out the links below.</p>
                <form className='noMatch__search-container' onSubmit={ search }>
                    <button className='noMatch__search-btn'>
                        <img src={searchIcon} className='noMatch__search-icon' alt='search icon'/>
                    </button>
                    <input placeholder='Search...' className='noMatch__input'  onChange={e => setSearchValue(e.target.value)} value={ searchValue }/>
                </form>
            </div>

            <Slider title={'Popular Products'}/>
        </div>
    )
}

export default NoMatch