import React, { useState } from 'react'
import { useHistory } from 'react-router'
import './SignUp.scss'
import { Link } from 'react-router-dom'
import ShowPasswordButton from '../../UI/buttons/ShowPasswordButton'
import DarkButton from '../../UI/buttons/DarkButton'
import SelectCountryDropdown from '../../UI/dropdowns/SelectCountryDropdown'
import { useValidity } from '../../custom-hooks/form-validity'
import axios from 'axios'
import jwt_decode from 'jwt-decode'

function Register({ onLogin }) {
  const history = useHistory()

  const [passwordIsShown, serPasswordIsShown] = useState(false)
  const [confirmPasswordIsShown, setConfirmPasswordIsShown] = useState(false)
  const [agree, setAgree] = useState(false)
  const [selectedCountry, setSelectedCountry] = useState('')
  const [countryInputIsInvalid, setCountryInputIsInvalid] = useState(false)
  const [user, setUser] = useState('')

  const isNotEmpty = (value) => value.trim() !== ''

  const passSelectedCountry = (country) => {
    setSelectedCountry(country)
  }

  const countryInputIsValid = isNotEmpty(selectedCountry)

  const {
    enteredValue: enteredFirstName,
    inputIsValid: firstNameInputIsValid,
    inputIsInvalid: firstNameInputIsInvalid,
    changeInputValueHandler: changeFirstNameInputValueHandler,
    blurInputHandler: blurFirstNameInputHandler,
  } = useValidity(isNotEmpty)

  const {
    enteredValue: enteredLastName,
    inputIsValid: lastNameInputIsValid,
    inputIsInvalid: lastNameInputIsInvalid,
    changeInputValueHandler: changeLastNameInputValueHandler,
    blurInputHandler: blurLastNameInputHandler,
  } = useValidity(isNotEmpty)

  const {
    enteredValue: enteredEmailAddress,
    inputIsValid: emailAddressInputIsValid,
    inputIsInvalid: emailAddressInputIsInvalid,
    changeInputValueHandler: changeEmailAddressInputValueHandler,
    blurInputHandler: blurEmailAddressInputHandler,
  } = useValidity((value) => /\w+(\.|-|_)?\w+@\w+\.\w{2,3}/.test(value))

  const {
    enteredValue: enteredStreetAddress,
    inputIsValid: streetAddressInputIsValid,
    inputIsInvalid: streetAddressInputIsInvalid,
    changeInputValueHandler: changeStreetAddressInputValueHandler,
    blurInputHandler: blurStreetAddressInputHandler,
  } = useValidity(isNotEmpty)

  const {
    enteredValue: enteredTownCity,
    inputIsValid: townCityInputIsValid,
    inputIsInvalid: townCityInputIsInvalid,
    changeInputValueHandler: changeTownCityInputValueHandler,
    blurInputHandler: blurTownCityInputHandler,
  } = useValidity(isNotEmpty)

  const {
    enteredValue: enteredStateRegion,
    inputIsValid: stateRegionInputIsValid,
    inputIsInvalid: stateRegionInputIsInvalid,
    changeInputValueHandler: changeStateRegionInputValueHandler,
    blurInputHandler: blurStateRegionInputHandler,
  } = useValidity(isNotEmpty)

  const {
    enteredValue: enteredPostcode,
    inputIsValid: postcodeInputIsValid,
    inputIsInvalid: postcodeInputIsInvalid,
    changeInputValueHandler: changePostcodeInputValueHandler,
    blurInputHandler: blurPostcodeInputHandler,
  } = useValidity(isNotEmpty)

  const {
    enteredValue: enteredPassword,
    inputIsValid: passwordInputIsValid,
    inputIsInvalid: passwordInputIsInvalid,
    changeInputValueHandler: changePasswordInputValueHandler,
    blurInputHandler: blurPasswordInputHandler,
  } = useValidity((value) => value.trim().length >= 8)

  const {
    enteredValue: enteredConfirmPassword,
    inputIsValid: confirmPasswordInputIsValid,
    inputIsInvalid: confirmPasswordInputIsInvalid,
    changeInputValueHandler: changeConfirmPasswordInputValueHandler,
    blurInputHandler: blurConfirmPasswordInputHandler,
  } = useValidity((value) => value === enteredPassword)

  const registerFormIsValid =
    firstNameInputIsValid &&
    lastNameInputIsValid &&
    emailAddressInputIsValid &&
    streetAddressInputIsValid &&
    townCityInputIsValid &&
    stateRegionInputIsValid &&
    postcodeInputIsValid &&
    passwordInputIsValid &&
    confirmPasswordInputIsValid &&
    agree

  const submitRegisterForm = (evt) => {
    evt.preventDefault()
    if (!registerFormIsValid) return
    if (!countryInputIsValid) {
      setCountryInputIsInvalid(true)
      return
    }
    const registerFormData = {
      first_name: enteredFirstName,
      last_name: enteredLastName,
      email: enteredEmailAddress,
      country: selectedCountry,
      street: enteredStreetAddress,
      city: enteredTownCity,
      region: enteredStateRegion,
      zip: enteredPostcode,
      password: enteredPassword,
    }
    axios
      .post(`https://freemotion-shop-back.herokuapp.com/auth/signup`, {
        first_name: enteredFirstName,
        last_name: enteredLastName,
        email: enteredEmailAddress,
        country: selectedCountry,
        street: enteredStreetAddress,
        city: enteredTownCity,
        region: enteredStateRegion,
        zip: enteredPostcode,
        password: enteredPassword,
      })
      .then((res) => {
        const token = res.data.token
        const data = jwt_decode(token)
        setUser(data)
      })
      .catch((e) => console.log(e))
    onLogin()

    history.push('/my-account')
    // console.log(registerFormData);
  }

  return (
    <section className="ecommerce__register wrapper">
      <div className="ecommerce-products__navigation">
        <ul className="ecommerce-products__navigation-list">
          <li>
            {' '}
            <Link to="/"> Home / </Link>{' '}
          </li>
          <li>
            {' '}
            <Link to="/signin"> Sign In / </Link>{' '}
          </li>
          <li>
            {' '}
            <Link to="/signup"> Register </Link>{' '}
          </li>
        </ul>
      </div>
      <div className="register__container">
        <div className="register__content">
          <h2 className="register__title"> Register </h2>
          <div className="register__form-container">
            <form
              action="#"
              name="registerForm"
              id="register_form"
              onSubmit={submitRegisterForm}
            >
              <div className="ecommerce-input__container">
                <label
                  htmlFor="first-name"
                  className={`ecommerce-input__label ${
                    firstNameInputIsInvalid && 'invalid-label'
                  }`}
                >
                  First name *
                </label>
                <div
                  className={`ecommerce-input__input-box ${
                    firstNameInputIsInvalid && 'invalid-input'
                  }`}
                >
                  <input
                    type="text"
                    id="first-name"
                    className="ecommerce-input__input"
                    value={enteredFirstName}
                    onChange={changeFirstNameInputValueHandler}
                    onBlur={blurFirstNameInputHandler}
                    placeholder="Enter first name"
                    autoComplete="off"
                  />
                </div>
                {firstNameInputIsInvalid && (
                  <p className="invalid-msg-info"> Invalid first name msg </p>
                )}
              </div>
              <div className="ecommerce-input__container">
                <label
                  htmlFor="last-name"
                  className={`ecommerce-input__label ${
                    lastNameInputIsInvalid && 'invalid-label'
                  }`}
                >
                  Last name *
                </label>
                <div
                  className={`ecommerce-input__input-box ${
                    lastNameInputIsInvalid && 'invalid-input'
                  }`}
                >
                  <input
                    type="text"
                    id="last-name"
                    className="ecommerce-input__input"
                    value={enteredLastName}
                    onChange={changeLastNameInputValueHandler}
                    onBlur={blurLastNameInputHandler}
                    placeholder="Enter last name"
                    autoComplete="off"
                  />
                </div>
                {lastNameInputIsInvalid && (
                  <p className="invalid-msg-info"> Invalid last name msg </p>
                )}
              </div>
              <div className="ecommerce-input__container">
                <label
                  htmlFor="email-address"
                  className={`ecommerce-input__label ${
                    emailAddressInputIsInvalid && 'invalid-label'
                  }`}
                >
                  Email address *
                </label>
                <div
                  className={`ecommerce-input__input-box ${
                    emailAddressInputIsInvalid && 'invalid-input'
                  }`}
                >
                  <input
                    type="email"
                    id="email-address"
                    className="ecommerce-input__input"
                    value={enteredEmailAddress}
                    onChange={changeEmailAddressInputValueHandler}
                    onBlur={blurEmailAddressInputHandler}
                    placeholder="Enter email address"
                    autoComplete="off"
                  />
                </div>
                {emailAddressInputIsInvalid && (
                  <p className="invalid-msg-info">
                    {' '}
                    Invalid email address msg{' '}
                  </p>
                )}
              </div>
              <SelectCountryDropdown
                onPass={passSelectedCountry}
                selectedCountry={selectedCountry}
                countryInputIsInvalid={countryInputIsInvalid}
                onReset={() => setCountryInputIsInvalid(false)}
              />
              <div className="ecommerce-input__container">
                <label
                  htmlFor="street-address"
                  className={`ecommerce-input__label ${
                    streetAddressInputIsInvalid && 'invalid-label'
                  }`}
                >
                  Street address *
                </label>
                <div
                  className={`ecommerce-input__input-box ${
                    streetAddressInputIsInvalid && 'invalid-input'
                  }`}
                >
                  <input
                    type="text"
                    id="street-address"
                    className="ecommerce-input__input"
                    value={enteredStreetAddress}
                    onChange={changeStreetAddressInputValueHandler}
                    onBlur={blurStreetAddressInputHandler}
                    placeholder="Enter street address"
                    autoComplete="off"
                  />
                </div>
                {streetAddressInputIsInvalid && (
                  <p className="invalid-msg-info">
                    {' '}
                    Invalid street address msg{' '}
                  </p>
                )}
              </div>
              <div className="ecommerce-input__container">
                <label
                  htmlFor="town-city"
                  className={`ecommerce-input__label ${
                    townCityInputIsInvalid && 'invalid-label'
                  }`}
                >
                  Town / city *
                </label>
                <div
                  className={`ecommerce-input__input-box ${
                    townCityInputIsInvalid && 'invalid-input'
                  }`}
                >
                  <input
                    type="text"
                    id="town-city"
                    className="ecommerce-input__input"
                    value={enteredTownCity}
                    onChange={changeTownCityInputValueHandler}
                    onBlur={blurTownCityInputHandler}
                    placeholder="Enter town / city"
                    autoComplete="off"
                  />
                </div>
                {townCityInputIsInvalid && (
                  <p className="invalid-msg-info"> Invalid town / city msg </p>
                )}
              </div>
              <div className="ecommerce-input__container">
                <label
                  htmlFor="state-region"
                  className={`ecommerce-input__label ${
                    stateRegionInputIsInvalid && 'invalid-label'
                  }`}
                >
                  State / region *
                </label>
                <div
                  className={`ecommerce-input__input-box ${
                    stateRegionInputIsInvalid && 'invalid-input'
                  }`}
                >
                  <input
                    type="text"
                    id="state-region"
                    className="ecommerce-input__input"
                    value={enteredStateRegion}
                    onChange={changeStateRegionInputValueHandler}
                    onBlur={blurStateRegionInputHandler}
                    placeholder="Enter state / region"
                    autoComplete="off"
                  />
                </div>
                {stateRegionInputIsInvalid && (
                  <p className="invalid-msg-info">
                    {' '}
                    Invalid state / region msg{' '}
                  </p>
                )}
              </div>
              <div className="ecommerce-input__container">
                <label
                  htmlFor="postcode-zip"
                  className={`ecommerce-input__label ${
                    postcodeInputIsInvalid && 'invalid-label'
                  }`}
                >
                  Postcode / ZIP *
                </label>
                <div
                  className={`ecommerce-input__input-box ${
                    postcodeInputIsInvalid && 'invalid-input'
                  }`}
                >
                  <input
                    type="text"
                    id="postcode-zip"
                    className="ecommerce-input__input"
                    value={enteredPostcode}
                    onChange={changePostcodeInputValueHandler}
                    onBlur={blurPostcodeInputHandler}
                    placeholder="Enter postcode / ZIP"
                    autoComplete="off"
                  />
                </div>
                {postcodeInputIsInvalid && (
                  <p className="invalid-msg-info"> Invalid postcode msg </p>
                )}
              </div>
              <div className="ecommerce-input__container">
                <label
                  htmlFor="password"
                  className={`ecommerce-input__label ${
                    passwordInputIsInvalid && 'invalid-label'
                  }`}
                >
                  Password *
                </label>
                <div
                  className={`ecommerce-input__input-box ${
                    passwordInputIsInvalid && 'invalid-input'
                  }`}
                >
                  <input
                    type={passwordIsShown ? 'text' : 'password'}
                    id="password"
                    className="ecommerce-input__input"
                    value={enteredPassword}
                    onChange={changePasswordInputValueHandler}
                    onBlur={blurPasswordInputHandler}
                    placeholder="Enter password"
                    autoComplete="off"
                  />
                  <ShowPasswordButton
                    isShown={passwordIsShown}
                    onShow={() => serPasswordIsShown((prevState) => !prevState)}
                  />
                </div>
                {passwordInputIsInvalid && (
                  <p className="invalid-msg-info"> Invalid password msg </p>
                )}
              </div>
              <div className="ecommerce-input__container">
                <label
                  htmlFor="confirm-password"
                  className={`ecommerce-input__label ${
                    confirmPasswordInputIsInvalid && 'invalid-label'
                  }`}
                >
                  Confirm Password *
                </label>
                <div
                  className={`ecommerce-input__input-box ${
                    confirmPasswordInputIsInvalid && 'invalid-input'
                  }`}
                >
                  <input
                    type={confirmPasswordIsShown ? 'text' : 'password'}
                    id="confirm-password"
                    className="ecommerce-input__input"
                    value={enteredConfirmPassword}
                    onChange={changeConfirmPasswordInputValueHandler}
                    onBlur={blurConfirmPasswordInputHandler}
                    placeholder="Enter confirm password"
                    autoComplete="off"
                  />
                  <ShowPasswordButton
                    isShown={confirmPasswordIsShown}
                    onShow={() =>
                      setConfirmPasswordIsShown((prevState) => !prevState)
                    }
                  />
                </div>
                {confirmPasswordInputIsInvalid && (
                  <p className="invalid-msg-info">
                    {' '}
                    Invalid confirm password msg{' '}
                  </p>
                )}
              </div>
              <label
                htmlFor="terms-and-conds"
                className="filter-bar__item-label register__terms-and-conds-label"
              >
                <input
                  className="filter-bar__item-input"
                  type="checkbox"
                  id="terms-and-conds"
                  checked={agree}
                  onChange={(evt) => setAgree(evt.target.checked)}
                />
                <div className="filter-bar__checkbox register__terms-and-conds-checkbox" />
                <p>
                  {' '}
                  I agree to the{' '}
                  <Link to="/terms-and-conditions">
                    {' '}
                    Terms & Conditions{' '}
                  </Link>{' '}
                </p>
              </label>
              <DarkButton
                className="register__create-account-btn"
                butnType="submit"
                label="Create an account"
                butnDisabled={!registerFormIsValid}
              />
            </form>
          </div>
        </div>
        <div className="register__already-have">
          <div className="already-have__content">
            <h2 className="already-have__title"> Already have an account ? </h2>
            <p className="already-have__text">
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's
            </p>
            <button
              type="button"
              className="already-have__log-in-btn"
              onClick={() => history.push('/signin')}
            >
              Log in
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Register
