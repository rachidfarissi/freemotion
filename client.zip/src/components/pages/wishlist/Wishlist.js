import React , {useState , useEffect} from 'react'
import { Link } from 'react-router-dom';
import axios from 'axios';
import GalleryViewElectricUnicycle from '../../items/products-page/galleryViewElectricUnicycle/GalleryViewElectricUnicycle';
import './wishlist.scss'

function Wishlist() {



    let url = 'https://freemotion-shop-back.herokuapp.com'

    const [data, setData] = useState()
    
    useEffect(() => {
        axios.get(`${url}/product/new/release`)
        .then(res => setData(res.data.new_release))
        .catch(e => console.log(e))
    
    },[url])

    return(
        <div className='wishlist wrapper2'>
            <h1 className='wishlist__title'>My wishlist</h1>
            <p className='wishlist__text'>6 ITEMS</p>
            <div className='wishlist__container'>
                <div className='wishlist__items'>
                    {/* { NEW_RELEASED_PRODUCTS.map((product) => <NewReleaseProducts  product={ product } key={ product.id } />) } */}
                
                
                    {data && data.map((unicycle, index) => {
                                    return (
                                        <GalleryViewElectricUnicycle 
                                            key={ unicycle.id }
                                            unicycle={ unicycle }
                                            index={ index }
                                        />
                                    );
                                })}
                

                </div>
                <div className='wishlist__baner'>
                    <h2 className='wishlist__baner-title'>DON'T LOSE YOUR WISHLIST</h2>
                    <p className='wishlist__baner-text'>Log in to save the items so they won't be lost.</p>
                    <Link to='signup' className='wishlist__baner-btn'>Register</Link>
                    <p className='wishlist__baner-text'>Do you have an account ?</p>
                    <Link to='signin' className='wishlist__baner-link'>LOG IN</Link>
                </div>
            </div>
        </div>
    )
}

export default Wishlist