import React, { useState } from 'react'
import { useHistory } from 'react-router'
import { Link } from 'react-router-dom'
import { useValidity } from '../../custom-hooks/form-validity'
import ForgotPassword from '../../UI/actions/home-page/ForgotPassword'
import DarkButton from '../../UI/buttons/DarkButton'
import ShowPasswordButton from '../../UI/buttons/ShowPasswordButton'
import CustomModal from '../../UI/custom-modal'
import axios from 'axios'
import jwt_decode from 'jwt-decode'
import './SignIn.scss'

function SignIn({ onLogin }) {
  const history = useHistory()

  const [passwordIsShown, serPasswordIsShown] = useState(false)
  const [forgotPasswordDropdownIsOpen, setForgotPasswordDropdownIsOpen] =
    useState(false)
  const [rememberMe, setRememberMe] = useState(false)
  const [user, setUser] = useState('')
  const [error, setError] = useState('')

  const openForgotPasswordModal = () => setForgotPasswordDropdownIsOpen(true)
  const closeForgotPasswordModal = () => setForgotPasswordDropdownIsOpen(false)

  const {
    enteredValue: enteredEmailAddress,
    inputIsValid: emailAddressInputIsValid,
    inputIsInvalid: emailAddressInputIsInvalid,
    changeInputValueHandler: changeEmailAddressInputValueHandler,
    blurInputHandler: blurEmailAddressInputHandler,
  } = useValidity((value) => /\w+(\.|-|_)?\w+@\w+\.\w{2,3}/.test(value))

  const {
    enteredValue: enteredPassword,
    inputIsValid: passwordInputIsValid,
    inputIsInvalid: passwordInputIsInvalid,
    changeInputValueHandler: changePasswordInputValueHandler,
    blurInputHandler: blurPasswordInputHandler,
  } = useValidity((value) => value.trim().length >= 8)

  const signInFormIsValid = emailAddressInputIsValid && passwordInputIsValid

  const submitSignInForm = (evt) => {
    evt.preventDefault()
    if (!signInFormIsValid) return

    const email = enteredEmailAddress
    const password = enteredPassword

    axios
      .post(`https://freemotion-shop-back.herokuapp.com/auth/signin`, {
        email,
        password,
      })
      .then((res) => {
        const token = res.data.token
        const data = jwt_decode(token)
        setUser(data)
        localStorage.setItem('token', token)
        history.push('/my-account')
        onLogin()
      })
      .catch((e) => setError('Login or password is wrong'))
  }

  return (
    <React.Fragment>
      <div className="ecommerce__sign-in wrapper">
        <div className="ecommerce-products__navigation ">
          <ul className="ecommerce-products__navigation-list">
            <li>
              {' '}
              <Link to="/"> Home / </Link>{' '}
            </li>
            <li>
              {' '}
              <Link to="/signin"> Sign In / </Link>{' '}
            </li>
            <li>
              {' '}
              <Link to="/signup"> Register </Link>{' '}
            </li>
          </ul>
        </div>
        <div className="sign-in__container">
          <div className="sign-in__content">
            <h2 className="sign-in__title"> Log in </h2>
            <div className="sign-in__form-container">
              <form
                action="#"
                name="signInForm"
                id="sign-in-form"
                onSubmit={submitSignInForm}
              >
                <div className="ecommerce-input__container">
                  <label
                    htmlFor="email-address"
                    className={`ecommerce-input__label ${
                      emailAddressInputIsInvalid && 'invalid-label'
                    }`}
                  >
                    Email address
                  </label>
                  <div
                    className={`ecommerce-input__input-box ${
                      emailAddressInputIsInvalid && 'invalid-input'
                    }`}
                  >
                    <input
                      type="email"
                      id="email-address"
                      className="ecommerce-input__input"
                      value={enteredEmailAddress}
                      onChange={changeEmailAddressInputValueHandler}
                      onBlur={blurEmailAddressInputHandler}
                      autoComplete="off"
                    />
                  </div>
                  {emailAddressInputIsInvalid && (
                    <p className="invalid-msg-info">
                      {' '}
                      Unknown email address. Check again or try your username.{' '}
                    </p>
                  )}
                </div>
                <div className="ecommerce-input__container">
                  <div className="container__label-and-btn">
                    <label
                      htmlFor="password"
                      className={`ecommerce-input__label ${
                        passwordInputIsInvalid && 'invalid-label'
                      }`}
                    >
                      Password
                    </label>
                    <button
                      type="button"
                      className="forgot-pass__btn"
                      onClick={openForgotPasswordModal}
                    >
                      Forgot your password?
                    </button>
                  </div>
                  <div
                    className={`ecommerce-input__input-box ${
                      passwordInputIsInvalid && 'invalid-input'
                    }`}
                  >
                    <input
                      type={passwordIsShown ? 'text' : 'password'}
                      id="password"
                      className="ecommerce-input__input"
                      value={enteredPassword}
                      onChange={changePasswordInputValueHandler}
                      onBlur={blurPasswordInputHandler}
                      autoComplete="off"
                    />
                    <ShowPasswordButton
                      isShown={passwordIsShown}
                      onShow={() =>
                        serPasswordIsShown((prevState) => !prevState)
                      }
                    />
                  </div>
                  {passwordInputIsInvalid && (
                    <p className="invalid-msg-info"> Invalid password msg </p>
                  )}
                </div>
                <label
                  htmlFor="terms-and-conds"
                  className="filter-bar__item-label register__terms-and-conds-label"
                >
                  <input
                    className="filter-bar__item-input"
                    type="checkbox"
                    id="terms-and-conds"
                    checked={rememberMe}
                    onChange={(evt) => setRememberMe(evt.target.checked)}
                  />
                  <div className="filter-bar__checkbox register__terms-and-conds-checkbox" />
                  <p> Remember me </p>
                  <p>{error}</p>
                </label>
                <DarkButton
                  className="sign-in__login-btn"
                  butnType="submit"
                  label="Log In"
                  butnDisabled={!signInFormIsValid}
                />
              </form>
            </div>
          </div>
          <div className="sign-in__create-account">
            <div className="create-account__content">
              <h2 className="create-account__title"> Register </h2>
              <p className="create-account__text">
                Create an account to benefit from our exclusive services and
                keep up to date with our latest publications.
              </p>
              <button
                type="button"
                className="create-account__create-btn"
                onClick={() => history.push('/signup')}
              >
                Create an account
              </button>
            </div>
          </div>
        </div>
      </div>
      {forgotPasswordDropdownIsOpen && (
        <CustomModal
          popupClassName="forgot-password__popup"
          closerClassName="forgot-password__closer"
          closeModal={closeForgotPasswordModal}
        >
          <ForgotPassword />
        </CustomModal>
      )}
    </React.Fragment>
  )
}

export default SignIn
