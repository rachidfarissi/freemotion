import React from 'react'
import { RECOMMENDED_PRODUCTS } from '../../dummy-datas/dummyDatas'
// import RelatedProductItem from '../items/single-product-page/relatedProductItem/RelatedProductItem';
import RelatedProductItem from '../items/single-product-page/reloadProductItem/RelatedProductItem'

import SliderButtons from '../UI/buttons/SliderButtons'
import './MyAccount.css'

function MyAccount() {
  return (
    <section className="my-account">
      <div className="my-account__container">
        <div className="my-account__greeting-user">
          <h1 className="greeting-user__text"> Hello Max </h1>
          <div className="greeting-user__balance-visitor">
            <div className="greeting-user__balance">
              <p className="balance__title"> Balance </p>
              <p className="balance__date"> As of 2/9/2021 </p>
              <h5 className="balance__price"> $1000 </h5>
            </div>
            <div className="greeting-user__visitor">
              <p className="visitor__title"> Visitors </p>
              <p className="visitor__date"> As of 2/9/2021 </p>
              <h5 className="visitor__quantity"> 25 </h5>
            </div>
          </div>
        </div>
        <div className="my-account__recommended-products">
          <div className="related-products__slider-actions">
            <h2 className="related-products__title"> Recommended Products </h2>
            <SliderButtons className="new-release__slider-btns" />
          </div>
          <div className="related-products__content ">
            {RECOMMENDED_PRODUCTS.map((product) => (
              <RelatedProductItem product={product} key={product.id} />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default MyAccount
