import React from 'react'
import { useHistory } from 'react-router'
import { ReactComponent as Register } from '../../../assets/images/Register.svg'
import { ReactComponent as GetLinks } from '../../../assets/images/GetLinks.svg'
import { ReactComponent as GetPaid } from '../../../assets/images/GetPaid.svg'
import AffiliateFilter from './AffiliateFilter'
import { useSelector } from 'react-redux'
import './affiliateProgram.scss'

const AffiliateProgram = () => {
  const data = [
    {
      id: 1,
      answer:
        'Lorem Ipsum is simply dummy text of the printing and typesetting',
      questions: 'What is an Affiliate Program?',
    },
    {
      id: 2,
      answer:
        'Lorem Ipsum is simply dummy text of the printing and typesetting',
      questions: 'What are the Benefits of Affiliate Marketing?',
    },
    {
      id: 3,
      answer:
        'Lorem Ipsum is simply dummy text of the printing and typesetting',
      questions: 'Things To Consider When Developing Your Affiliate Marketing?',
    },
    {
      id: 4,
      answer:
        'Lorem Ipsum is simply dummy text of the printing and typesetting',
      questions: 'Common Affiliate Program Challenges',
    },
    {
      id: 5,
      answer:
        'Lorem Ipsum is simply dummy text of the printing and typesetting',
      questions:
        'Examples of Software to Manage an Ecommerce Affiliate Program',
    },
    {
      id: 6,
      answer:
        'Lorem Ipsum is simply dummy text of the printing and typesetting',
      questions: 'Executive Summary',
    },
  ]

  const history = useHistory()
  const user = useSelector((store) => store.user)
  console.log(user)

  const dataFiltering = () => {
    return data.map((faq, index) => (
      <AffiliateFilter faq={faq} key={faq.id} index={index} />
    ))
  }
  return (
    <div className="AffiliateProgram">
      <div className="AffiliateProgram_container">
        <h2>Freemotion Affiliate Program</h2>
        <p>Get commissions each time you refer a new customer</p>
        <button
          onClick={() =>
            user.sub ? history.push('/my-account') : history.push('/signup')
          }
        >
          Apply now
        </button>
      </div>
      <div className="AffiliateProgram_started">
        <div className="AffiliateProgram_started__content">
          <p className="AffiliateProgram_started__content__number">01</p>
          <Register className="AffiliateProgram_started__content__img" />
          <h2>Register</h2>
          <p>
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry.
          </p>
        </div>
        <div className="AffiliateProgram_started__content">
          <p className="AffiliateProgram_started__content__number">02</p>
          <GetLinks className="AffiliateProgram_started__content__img" />
          <h2>Get paid</h2>
          <p>
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry.
          </p>
        </div>
        <div className="AffiliateProgram_started__content">
          <p className="AffiliateProgram_started__content__number">03</p>
          <GetPaid className="AffiliateProgram_started__content__img" />
          <h2>Register</h2>
          <p>
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry.
          </p>
        </div>
      </div>
      <div className="AffiliateProgram_started__box">
        <h2 className="">Shipping & Returns</h2>
        <div className="faq__content AffiliateProgram_started__box__contnet">
          {dataFiltering()}
        </div>
      </div>
      <div className="AffiliateProgram_purchase">
        <h2>Redeem your Rewards Credit on future purchases</h2>
        <p>
          Lorem Ipsum is simply dummy text of the printing and typesetting.{' '}
        </p>
        <button
          onClick={() =>
            user.sub ? history.push('/my-account') : history.push('/signup')
          }
        >
          Apply now
        </button>
      </div>
    </div>
  )
}
export default AffiliateProgram
