import React, { useEffect, useState } from 'react'
import Paginator from 'react-hooks-paginator'
import BlogSubscribe from '../../blogSubscribe/BlogSubscribe'
import BlogItem from '../../items/blogItem/BlogItem'
import './blog.scss'

function Blog() {
  const pageLimit = 11
  const [offset, setOffset] = useState(0)
  const [currentPage, setCurrentPage] = useState(1)
  const [data, setData] = useState([])
  const [blogList, setBlogList] = useState()
  const [currentData, setCurrentData] = useState([])
  let url = 'http://147.182.155.217:8372'

  useEffect(() => {
    fetch(`${url}/blog/list`)
      .then((res) => res.json())
      .then((res) => setBlogList(res))
      .catch((e) => console.log(e.message, 'error message'))
  }, [])

  let mediaCardElementRevers
  let mediaCardElement

  if (blogList) {
    mediaCardElementRevers = blogList.map((el) => (
      <BlogItem rel="preload" el={el} key={el.id} alt="tt" />
    ))
    mediaCardElement = mediaCardElementRevers.reverse()
  }

  useEffect(() => {
    setCurrentData(mediaCardElement?.slice(offset, offset + pageLimit))
  }, [offset, data, blogList])

  return (
    <>
      <div className="blogPage">
        <div className="blog_cards wrapper2">
          {blogList &&
            currentData?.map((mediaCardElement) => <>{mediaCardElement}</>)}
          <BlogSubscribe />
        </div>
        {blogList && (
          <Paginator
            totalRecords={mediaCardElement.length}
            pageLimit={pageLimit}
            pageNeighbours={1}
            setOffset={setOffset}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
          />
        )}
      </div>
      <BlogSubscribe />
    </>
  )
}

export default Blog
