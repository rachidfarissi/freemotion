import React, { useState, useEffect } from 'react'
import { Link, useParams } from 'react-router-dom'
import './SingleProduct.scss'
import { homeMainIcons, singleProductImages } from '../../../dummy-datas/images'
import ColorDropdown from '../../UI/dropdowns/ColorDropdown'
import WheelSizeDropdown from '../../UI/dropdowns/WheelSizeDropdown'
import ChooseProductQuantity from '../../UI/actions/ChooseProductQuantity'
import LightButton from '../../UI/buttons/LightButton'
import DarkButton from '../../UI/buttons/DarkButton'
import AddToCompare from '../../UI/actions/addToCompare/AddToCompare'
import AddToFavourite from '../../UI/actions/addToFavourite/AddToFavourite'
import BuyTogetherAndSave from '../../UI/actions/buyTogetherAndSave/BuyTogetherAndSave'
import NavigateBetweenSections from '../../UI/actions/NavigateBetweenSections'
import Description from '../../inner-sections/description/Description'
import Parameters from '../../inner-sections/Parameters/Parameters'
import ShippingAndWarranty from '../../inner-sections/ShippingAndWarranty'
import FAQ from '../../inner-sections/faq/FAQ'
import PhotoAndVideo from '../../inner-sections/PhotoAndVideo'
import Reviews from '../../inner-sections/reviews/Reviews'
import RelatedProducts from '../../inner-sections/relatedProducts/RelatedProducts'
import FindSimilarProducts from '../../inner-sections/FindSimilarProducts'
import { url } from '../../../configs/config'
import axios from 'axios'
import DiscountedProduct from '../../discountedProduct/DiscountedProduct'
import ImageGallery from 'react-image-gallery'
import duty_free_icon from './../../../assets/icons/footer/duty-free22.png'
import pay_bright_icon from './../../../assets/icons/footer/pay-bright.png'
import klarna_icon from './../../../assets/icons/footer/klarna.png'

const SingleProduct = () => {
  const [singleData, setSingleData] = useState()
  const params = useParams()
  // console.log(params);

  useEffect(() => {
    axios
      .get(`${url}/product/single/${params.id}`)
      .then((res) => setSingleData(res.data.product))
      .catch((e) => console.log(e.message))
  }, [])

  const data = []

  // const arr = []

  singleData?.product_gallery.gallery.map((imageUrl) =>
    data.push({
      original: `${url}/${imageUrl}`,
      thumbnail: `${url}/${imageUrl}`,
    })
  )

  return (
    <>
      {singleData && (
        <section className="single-product wrapper2">
          <div className="single-products__navigation wrapper2">
            {/* <ul className="ecommerce-products__navigation-list">
                            <li> <Link to="/"> Home / </Link> </li>
                            <li> <Link to="*"> Trending / </Link> </li>
                            <li> <Link to="/single-product"> East Hampton Fleece Hoodie </Link> </li>
                        </ul> */}
          </div>
          <div className="single-product__actions">
            {data && <ImageGallery items={data} thumbnailPosition={'left'} />}

            <div className="actions__product-intro">
              <div className="product-intro__copy-share">
                <div className="product-intro__copy">
                  <h6 className="product-intro__info">
                    {' '}
                    SKU: <em> {'unicycle.SKU'} </em>{' '}
                  </h6>
                  <img src={singleProductImages.copy_icon} alt="copy" />
                </div>
                <h6 className="product-intro__share"> share </h6>
              </div>
              <div className="product-intro__des-and-rate">
                <h2 className="product-intro__title">
                  {singleData.title}
                  {/* ********SEGWAY ES2 SCOOTER + Extended battery (Used certified)  */}
                </h2>
                <div className="product-intro__rating-box">
                  <span className="electric-unicycle__rating">
                    {' '}
                    {singleData.rate} / 5{' '}
                  </span>
                  <ul className="electric-unicycle__rating-list product-intro__rating-list">
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBorderIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBorderIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBorderIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBorderIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBorderIcon}
                        alt="star"
                      />{' '}
                    </li>
                  </ul>
                  {/* <img src={ 'singleProductImages.vector_down_icon' } alt="vector down" /> */}
                  {/* <span className="product-intro__ratings"> 3,506 ratings </span> */}
                </div>
                <div className="product-intro__price-info">
                  <div className="new-price-box">
                    <span className="new-price-box__currency"> C$ </span>
                    <p className="electric-unicycle__new-price">
                      {' '}
                      {singleData.price}.00{' '}
                    </p>
                  </div>
                  <div className="old-price-box">
                    <span className="old-price-box__currency"> C$ </span>
                    <p className="electric-unicycle__old-price">
                      <span className="product-intro__number">
                        {singleData.discounted_price}.00
                      </span>
                      <span className="product-intro__discount">
                        {' '}
                        {Math.floor(
                          100 -
                            (singleData.discounted_price / singleData.price) *
                              100
                        )}
                        %{' '}
                      </span>
                      <span className="product-intro__off">
                        {' '}
                        C$ {singleData.discounted_price -
                          singleData.price} OFF{' '}
                      </span>
                    </p>
                  </div>
                </div>
              </div>
              <div className="product-intro__colors-wheel-size">
                <ColorDropdown />
                <WheelSizeDropdown />
              </div>
              <ChooseProductQuantity />
              <div className="product-intro__actions">
                <DarkButton
                  butnType={'button'}
                  label={'Buy it now'}
                  // onButnClick={}
                />
                <LightButton
                  className={'product-intro__add-to-cart-butn'}
                  butnType={'button'}
                  label={'Add to cart'}
                  // onButnClick={}
                />
                <div className="buttons_container">
                  <AddToCompare />
                  <AddToFavourite />
                </div>
              </div>
              <div className="product-intro__payment-ways">
                <div className="payment-ways__pay-bright">
                  {/* <img className={paybright} alt='^^'/> */}
                  <img src={pay_bright_icon} alt="paybright" />
                </div>
                <div className="payment-ways__klarna">
                  {/* <img className={klarna_icon} alt='^^'/> */}
                  <img src={klarna_icon} alt="klarna" />
                </div>
                <div className="payment-ways__duty-free">
                  <img src={duty_free_icon} alt="Duty Free" />
                </div>
              </div>
            </div>
          </div>
          <DiscountedProduct />
          <BuyTogetherAndSave />
          <NavigateBetweenSections />
          <Description singleData={singleData} />
          <Parameters singleData={singleData} />
          <ShippingAndWarranty />
          <FAQ />
          <PhotoAndVideo />
          <Reviews id={params.id} rate={singleData.rate} />
          <RelatedProducts />
          <FindSimilarProducts />
        </section>
      )}
    </>
  )
}

export default SingleProduct
