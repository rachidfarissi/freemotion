import React from 'react'
import './Shipping.css'

export default function Shipping() {
  return <div>shipping</div>
}
