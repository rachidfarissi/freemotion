import React from 'react'
import './privacyPolicy.scss'

function PrivacyPolicy() {
  return (
    <div className="privacy-policy wrapper">
      <h1 className="privacy-policy__title">Security & Privacy Policy</h1>
      <p className="privacy-policy__text">
        We value your privacy and ensure a secure purchase. Robot Canada Inc at
        FreeMotionShop.com is committed to respecting and protecting your
        privacy and confidential information. Once we have received your data,
        we will apply strict procedures to prevent unauthorized access; however,
        we cannot guarantee the security of the information. We will never share
        your information unless we are legally obliged to do so. Uses of
        Information
      </p>
      <ul className="privacy-policy__ul">
        <li className="privacy-policy__list">
          We don’t sell or rent your personal information to any third party.
        </li>
        <li className="privacy-policy__list">
          We utilize your information to fulfill your requests, meet your needs,
          administer various programs, deliver product and services, and attain
          other formal purposes.
        </li>
        <li className="privacy-policy__list">
          Your personal information may be used to provide you latest marketing
          communications.
        </li>
        <li className="privacy-policy__list">
          In some circumstances, FreeMotion may share your details with certain
          third parties to execute services on our behalf.
        </li>
      </ul>
      <div className="privacy-policy__box">
        <h2 className="privacy-policy__subtitle">Updates </h2>
        <p className="privacy-policy__text">
          Should we amend, update or make any variations to our security and
          privacy policy, we will post the changes here.
        </p>
      </div>
      <div className="privacy-policy__box">
        <h2 className="privacy-policy__subtitle">Analytics</h2>
        <p className="privacy-policy__text">
          We may collect information regarding your computer, including your
          browser type, operation system, and IP address, to create reports,
          maintain a safe environment for our users, and meet system
          administration requirements. We may analyze details of your visits to
          our website, or usage of our mobile app, including, but not limited
          to, location, traffic, and other communication data and resources that
          you access.
        </p>
      </div>
      <div className="privacy-policy__box">
        <h2 className="privacy-policy__subtitle">Cookies</h2>
        <p className="privacy-policy__text">
          Our cookies help you to personalize your experience with our website,
          and ensure your sign up process is as quick and safe as possible.
          These do not share any of your personal information with us; moreover,
          we would never utilize any details delivered through cookies to try to
          identify anyone.
        </p>
      </div>
      <div className="privacy-policy__box">
        <h2 className="privacy-policy__subtitle">Contact</h2>
        <p className="privacy-policy__text">
          We welcome your queries, comments, and requests regarding our security
          and privacy policy, and encourage you to address them via the contact
          form.
        </p>
      </div>
      <div className="privacy-policy__box">
        <h2 className="privacy-policy__subtitle">Consent</h2>
        <p className="privacy-policy__text">
          By accessing our website FreeMotionShop.com, you as a result of this
          consent to our security and privacy policy and accept its terms.
        </p>
      </div>
    </div>
  )
}

export default PrivacyPolicy
