import React, { useState } from 'react';
import { useHistory } from 'react-router';
import { useValidity } from '../custom-hooks/form-validity';
import DarkButton from '../UI/buttons/DarkButton';
import ShowPasswordButton from '../UI/buttons/ShowPasswordButton';
import './ResetPassword.css';


function ResetPassword() {
    const history = useHistory();

    const [passwordIsShown, serPasswordIsShown] = useState(false);
    const [confirmPasswordIsShown, setConfirmPasswordIsShown] = useState(false);

    const {
        enteredValue: enteredNewPassword,
        inputIsValid: newPasswordInputIsValid,
        inputIsInvalid: newPasswordInputIsInvalid,
        changeInputValueHandler: changeNewPasswordInputValueHandler,
        blurInputHandler: blurNewPasswordInputHandler
    } = useValidity(value => value.trim().length >= 8);

    const {
        enteredValue: enteredConfirmNewPassword,
        inputIsValid: confirmNewPasswordInputIsValid,
        inputIsInvalid: confirmNewPasswordInputIsInvalid,
        changeInputValueHandler: changeConfirmNewPasswordInputValueHandler,
        blurInputHandler: blurConfirmNewPasswordInputHandler
    } = useValidity(value => value === enteredNewPassword);

    const resetPasswordFormIsValid = newPasswordInputIsValid && confirmNewPasswordInputIsValid;

    const submitResetPasswordForm = (evt) => { 
        evt.preventDefault(); 
        if(!resetPasswordFormIsValid) return;
        const resetPasswordFormData = {
            password: enteredNewPassword
        };
        console.log(resetPasswordFormData);
        history.push('/congrats'); 
    };

    return (
        <div className="ecommerce__reset-password">
            <div className="reset-password__container">
                <div className="reset-password__content">
                    <h2 className="reset-password__title"> Reset password </h2>
                    <div className="reset-password__form-container">
                        <form action="#" name="resetPasswordForm" id="reset-password-form" onSubmit={ submitResetPasswordForm }>
                            <div className="ecommerce-input__container">
                                <label 
                                    htmlFor="password" 
                                    className={ `ecommerce-input__label ${ newPasswordInputIsInvalid && "invalid-label" }` }
                                > 
                                    New password 
                                </label>
                                <div className={ `ecommerce-input__input-box ${ newPasswordInputIsInvalid && "invalid-input" }` }>
                                    <input 
                                        type={ passwordIsShown ? "text" : "password" }
                                        id="password"
                                        className="ecommerce-input__input"
                                        value={ enteredNewPassword }
                                        onChange={ changeNewPasswordInputValueHandler }
                                        onBlur={ blurNewPasswordInputHandler }
                                        placeholder="Enter new password"
                                        autoComplete="off"
                                    />
                                    <ShowPasswordButton
                                        isShown={ passwordIsShown } 
                                        onShow={ () => serPasswordIsShown((prevState) => !prevState) } 
                                    />
                                </div> 
                                { newPasswordInputIsInvalid && <p className="invalid-msg-info"> Invalid new password msg </p> }
                            </div>
                            <div className="ecommerce-input__container">
                                <label 
                                    htmlFor="confirm-password" 
                                    className={ `ecommerce-input__label ${ confirmNewPasswordInputIsInvalid && "invalid-label" }` }
                                > 
                                    Confirm new password 
                                </label>
                                <div className={ `ecommerce-input__input-box ${ confirmNewPasswordInputIsInvalid && "invalid-input" }` }>
                                    <input 
                                        type={ confirmPasswordIsShown ? "text" : "password" }
                                        id="confirm-password"
                                        className="ecommerce-input__input"
                                        value={ enteredConfirmNewPassword }
                                        onChange={ changeConfirmNewPasswordInputValueHandler }
                                        onBlur={ blurConfirmNewPasswordInputHandler }
                                        placeholder="Enter confirm new password"
                                        autoComplete="off"
                                    />
                                    <ShowPasswordButton
                                        isShown = { confirmPasswordIsShown }
                                        onShow={ () => setConfirmPasswordIsShown((prevState) => !prevState) } 
                                    />
                                </div>
                                { confirmNewPasswordInputIsInvalid && <p className="invalid-msg-info"> Invalid confirm new password msg </p> }
                            </div>
                            <DarkButton 
                                className="reset-password__change-password-btn"
                                butnType="submit" 
                                label="Create an account"
                                butnDisabled={ !resetPasswordFormIsValid }
                            />
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ResetPassword;
