import React from 'react'
import './Affiliate.scss'

export default function Affiliate() {
  return <div>Affiliate ctx here</div>
}
