import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import './support.scss'
import Search from '../../../assets/icons/support/search.png'
import MessigeSend from '../../../assets/icons/support/messigeSend.png'
import { url } from '../../../configs/config'

import { ReactComponent as Mexa } from '../../../assets/icons/support/mexa.svg'
import { ReactComponent as Book } from '../../../assets/icons/support/Book.svg'
import { ReactComponent as Trek } from '../../../assets/icons/support/Trek.svg'
import { ReactComponent as Question } from '../../../assets/icons/support/Question.svg'
import axios from 'axios'

const Support = () => {
  ////////////////////// form //////////////////////////
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [subject, setSubject] = useState('')
  const [message, setMessage] = useState('')

  const [messageSend, setMessageSend] = useState(true)

  const [searchValue, setSearchValue] = useState('')
  const [error, setError] = useState('')
  const [nameError, setNameError] = useState('')
  const [emailError, setEmailError] = useState('')
  const [subjectError, setSubjectError] = useState('')
  const [messsageError, setMessageError] = useState('')

  const [valid, setValid] = useState(false)

  const search = (event) => {
    alert(searchValue)
    event.preventDefault()
  }
  const validateInputs = () => {
    let validEmail =
      /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
    let validateEmail = email.match(validEmail)
    // if (!validateEmail) {
    //   setError('please use correct email address')
    // } else {
    //   setError('')
    // }
    if (!email.trim() === '' || !validateEmail) {
      setEmailError('is required')
      setValid(false)
    } else {
      setEmailError('')
      setValid(true)
    }
    if (name.trim() === '') {
      setNameError('is required')
      setValid(false)
    } else {
      setNameError('')
      setValid(true)
    }
    if (subject.trim() === '') {
      setSubjectError('is required')
      setValid(false)
    } else {
      setSubjectError('')
      setValid(true)
    }
    if (message.trim() === '') {
      setMessageError('is required')
      setValid(false)
    } else {
      setMessageError('')
      setValid(true)
    }
    console.log(valid)
    return valid
  }

  const sendMessige = (event) => {
    event.preventDefault()

    let validEmail =
      /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/

    if (name && email.match(validEmail) && subject && message) {
      axios
        .post(`${url}/support/add/message`, { name, email, subject, message })
        .then((res) => setMessageSend((messageSend) => !messageSend))
    } else {
      if (name.trim() === '') {
        setNameError('is required')
      }
      if (email.trim() === '' || !validEmail) {
        setEmailError('is required')
      }
      if (subject.trim() === '') {
        setSubjectError('is required')
      }
      if (message.trim() === '') {
        setMessageError('is required')
      }
    }
  }

  function resetForm() {
    // alert(1)
    setName((name) => '')
    setEmail((email) => '')
    setSubject((subject) => '')
    setMessage((message) => '')
    // setEmail('')
  }

  return (
    <div className="support">
      <section className="support__bg">
        <h1 className="support__title">How can we help you?</h1>
        <form className="search" onSubmit={(e) => search(e)}>
          <img className="search__icon" src={Search} alt="search icon" />
          <input
            className="search__input"
            type="search"
            placeholder="What are you looking for?"
            onChange={(e) => setSearchValue(e.target.value)}
            value={searchValue}
          />
          <button className="search__btn">Search</button>
        </form>
      </section>
      <section className="support-nav wrapper">
        <Link to="faq" className="support-nav__item">
          <Question className="support-nav__item-img" alt="search icon" />
          FAQ
        </Link>
        <Link to="shippingAndReturns" className="support-nav__item">
          <Book className="support-nav__item-img" alt="search icon" />
          Shipping & Returns
        </Link>
        <Link to="/buyingGuide" className="support-nav__item">
          <Trek className="support-nav__item-img" alt="search icon" />
          Buying guide
        </Link>
        <Link to="/warrantyRegistration" className="support-nav__item">
          <Mexa className="support-nav__item-img" />
          Warranty registration
        </Link>
      </section>
      <section className="support-form__container wrapper">
        {messageSend ? (
          <form className="support-form" onSubmit={(e) => sendMessige(e)}>
            <p className="support-form-text">
              Please fill in the form below to get in touch with our support
              team
            </p>
            <label className="support-form__item">
              <span
                className={`support-form__text ${
                  nameError && 'warningMessage'
                }`}
              >
                Your Name * {nameError}
              </span>
              <input
                className={`${nameError && 'borderError'}`}
                placeholder="Enter your name here"
                type="text"
                onChange={(e) => setName(e.target.value)}
                value={name}
              />
            </label>
            <label className="support-form__item">
              <span
                className={`support-form__text ${
                  emailError && 'warningMessage'
                }`}
              >
                Your Email * {emailError}
              </span>
              <input
                className={`${emailError && 'borderError'}`}
                placeholder="Enter your email here"
                type="text"
                onChange={(e) => setEmail(e.target.value)}
                value={email}
              />
            </label>
            <label className="support-form__item">
              <span
                className={`support-form__text ${
                  subjectError && 'warningMessage'
                }`}
              >
                Subject {subjectError}
              </span>
              <input
                className={`${subjectError && 'borderError'}`}
                placeholder="Enter your subject here"
                type="text"
                onChange={(e) => setSubject(e.target.value)}
                value={subject}
              />
            </label>
            <label className="support-form__item">
              <span
                className={`support-form__text ${
                  messsageError && 'warningMessage'
                }`}
              >
                Your Message {messsageError}
              </span>
              <textarea
                placeholder="Enter your message here ..."
                className={`support-form__textarea ${
                  messsageError && 'borderError'
                }`}
                type="text"
                onChange={(e) => setMessage(e.target.value)}
                value={message}
              />
            </label>
            <div className="support-form__buttons">
              <button
                className="support-form__resetBtn"
                type="button"
                onClick={() => resetForm()}
              >
                Reset form
              </button>
              <button className="support-form__submitBtn" type="submit">
                submit
              </button>
            </div>
          </form>
        ) : (
          <div className="support-form__messageSend">
            <img
              src={MessigeSend}
              alt="messageSend"
              className="support-form__messageSend-icon"
            />
            <p className="support-form__messageSend-text">
              Your message has been successfully sent
            </p>
          </div>
        )}
        <div className="support-form__contacts">
          <p className="support-form-text">Or use our contact details</p>
          <address className="support-form__contacts-item support-form__contacts-item-address">
            San Diego, California, USA Montreal, QC, Canada
          </address>
          <a className="support-form__contacts-item" href="tel:(626) 295-6599">
            (626) 295-6599
          </a>
          <a className="support-form__contacts-item" href="tel:(514) 922-7332">
            (514) 922-7332
          </a>
          <a
            className="support-form__contacts-item"
            href="mailto:info@freemotion.com "
          >
            info@freemotion.com{' '}
          </a>
        </div>
      </section>
    </div>
  )
}

export default Support
