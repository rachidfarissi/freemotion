import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { homeMainIcons } from '../../../dummy-datas/images'
import ImageItem from '../../../assets/images/testimonailsItems.png'
import CheckIcon from '../../../assets/images/check.png'
import './customerTestimonials.scss'

const CustomerTestimonials = () => {
  let url = 'https://freemotion-shop-back.herokuapp.com'
  const [dataRate, setDataRate] = useState([])
  const [link, setLink] = React.useState(0)

  const likElements = [
    'All reviews',
    'Electric Unicycles',
    'Electric Scooters',
    'Electric Skateboard',
  ]
  const [data, setData] = useState([])
  console.log(url)
  useEffect(() => {
    console.log(url)
    axios
      .get(`${url}/review/product/61addfaeb77e226c21dd51bd`)
      .then((res) => setData(res.data.review))
      // .then(res => console.log(res.data.faq))
      .catch((e) => console.log(e))
  }, [])

  useEffect(() => {
    console.log(url)
    axios
      .get(`${url}/rate/get/61addfaeb77e226c21dd51bd`)
      .then((res) => setDataRate(res.data.message))
      // .then(res => console.log(res.data.faq))
      .catch((e) => console.log(e))
  }, [])

  function handleNavigation(index, element = 'All reviews') {
    setLink(index)
  }

  return (
    <div className="wrapper2 CustomerTestimonials">
      <p className="CustomerTestimonials__title">Customer Testimonials</p>
      <div className="CustomerTestimonials_container">
        <div className="CustomerTestimonials_container__rateBlock">
          <div className="reviews " id="reviews">
            <div className="reviews__content border">
              <div className="reviews__rating flex">
                <div className="reviews__content-box flex">
                  <div className="reviews__user-review">
                    <h6 className="reviews-details__text CustomerTestimonials_container__text">
                      {' '}
                      {dataRate.rate__total}150 User Reviews{' '}
                    </h6>
                    <h2 className="CustomerTestimonials_container__rate">
                      5.0
                    </h2>
                  </div>
                  <div className="reviews__rating-container">
                    <h3 className="reviews-details__rating-point">
                      {' '}
                      {dataRate.rate}{' '}
                    </h3>
                    <ul className="product-info__rating-list reviews-details__rating-list">
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangePeaceOfBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBorderIcon}
                          alt="star"
                        />{' '}
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="reviews__rating-status">
                  <div className="rating-info__rating-status-item">
                    <span className="rating-info__count CustomerTestimonials_container__count">
                      {' '}
                      5{' '}
                    </span>
                    <img
                      src={homeMainIcons.starOrangeBgIcon}
                      alt="rating star"
                    />
                    <div className="rating-info__box review__rating-info">
                      <i
                        style={{
                          width: dataRate.rate_five_procent + '%',
                          backgroundColor: `rgb(${
                            255 -
                            dataRate.rate_five_procent * 2.5 +
                            ',' +
                            dataRate.rate_five_procent * 2.5
                          }, 0)`,
                        }}
                        className="rating-info__percentage"
                      />
                    </div>
                    <span className="rating-info__percent CustomerTestimonials_container__count">
                      {dataRate.rate_five_procent}%{' '}
                    </span>
                  </div>
                  <div className="rating-info__rating-status-item">
                    <span className="rating-info__count CustomerTestimonials_container__count">
                      {' '}
                      4{' '}
                    </span>
                    <img
                      src={homeMainIcons.starOrangeBgIcon}
                      alt="rating star"
                    />
                    <div className="rating-info__box">
                      <i
                        style={{
                          width: dataRate.rate_four_procent + '%',
                          backgroundColor: `rgb(${
                            255 -
                            dataRate.rate_four_procent * 2.5 +
                            ',' +
                            dataRate.rate_four_procent * 2.5
                          }, 0)`,
                        }}
                        className="rating-info__percentage"
                      />
                    </div>
                    <span className="rating-info__percent CustomerTestimonials_container__count">
                      {' '}
                      {dataRate.rate_four_procent}%{' '}
                    </span>
                  </div>
                  <div className="rating-info__rating-status-item">
                    <span className="rating-info__count CustomerTestimonials_container__count">
                      {' '}
                      3{' '}
                    </span>
                    <img
                      src={homeMainIcons.starOrangeBgIcon}
                      alt="rating star"
                    />
                    <div className="rating-info__box">
                      <i
                        style={{
                          width: dataRate.rate_three_procent + '%',
                          backgroundColor: `rgb(${
                            255 -
                            dataRate.rate_three_procent * 2.5 +
                            ',' +
                            dataRate.rate_three_procent * 2.5
                          }, 0)`,
                        }}
                        className="rating-info__percentage"
                      />
                    </div>
                    <span className="rating-info__percent CustomerTestimonials_container__count">
                      {' '}
                      {dataRate.rate_three_procent}%{' '}
                    </span>
                  </div>
                  <div className="rating-info__rating-status-item">
                    <span className="rating-info__count CustomerTestimonials_container__count">
                      {' '}
                      2{' '}
                    </span>
                    <img
                      src={homeMainIcons.starOrangeBgIcon}
                      alt="rating star"
                    />
                    <div className="rating-info__box">
                      <i
                        style={{
                          width: dataRate.rate_two_procent + '%',
                          backgroundColor: `rgb(${
                            255 -
                            dataRate.rate_two_procent * 2.5 +
                            ',' +
                            dataRate.rate_two_procent * 2.5
                          }, 0)`,
                        }}
                        className="rating-info__percentage "
                      />
                    </div>
                    <span className="rating-info__percent CustomerTestimonials_container__count">
                      {' '}
                      {dataRate.rate_two_procent}%{' '}
                    </span>
                  </div>
                  <div className="rating-info__rating-status-item">
                    <span className="rating-info__count CustomerTestimonials_container__count">
                      {' '}
                      1{' '}
                    </span>
                    <img
                      src={homeMainIcons.starOrangeBgIcon}
                      alt="rating star"
                    />
                    <div className="rating-info__box">
                      <i
                        style={{
                          width: dataRate.rate_one_procent + '%',
                          backgroundColor: `rgb(${
                            255 -
                            dataRate.rate_one_procent * 2.5 +
                            ',' +
                            dataRate.rate_one_procent * 2.5
                          }, 0)`,
                        }}
                        className="rating-info__percentage"
                      />
                    </div>
                    <span className="rating-info__percent CustomerTestimonials_container__count">
                      {' '}
                      {dataRate.rate_one_procent}%
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* {data.slice(0, visible).map((verifiedReview) => (
              <VerifiedReviewItem
                verifiedReview={verifiedReview}
                key={verifiedReview.id}
              />
            ))}

            <div className="reviews__actions">
              <LightButton
                className={'reviews__write-a-review-btn'}
                butnType={'button'}
                label={'Write a review'}
                onButnClick={openModalHandler}
              />
              {data.length >= 3 && (
                <button
                  type="button"
                  className="content__change-btn"
                  onClick={readMore}
                >
                  Load more
                </button>
              )}
            </div> */}
          </div>
        </div>
        <div className="CustomerTestimonials_container__items">
          <div className="Table-Navigation CustomerTestimonials_container__items__header">
            {likElements.map((elem, index) => (
              <p
                className={link === index ? 'Table-Navigation__active' : ''}
                onClick={() => handleNavigation(index, elem)}
                key={index}
              >
                {elem}
              </p>
            ))}
          </div>
          {/* maped Element */}
          <div className="CustomerTestimonials_container__items__elements">
            <div className="CustomerTestimonials_container__items__elements_con">
              <img src={ImageItem} />
              <span className="CustomerTestimonials_container__items__elements__text">
                InMotion L8F ELECTRIC SCOOTER (Water Proof German Version)
              </span>
              <p>Max Cooper</p>
              <div className="CustomerTestimonials_container__items__elements__rate">
                <div>
                  <h3 className="reviews-details__rating-point">
                    {' '}
                    {dataRate.rate}{' '}
                  </h3>
                  <ul className="product-info__rating-list reviews-details__rating-list">
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangePeaceOfBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBorderIcon}
                        alt="star"
                      />{' '}
                    </li>
                  </ul>
                </div>
                <p>December 17, 2020</p>
              </div>
              <div className="CustomerTestimonials_container__items__elements__description">
                <p className="CustomerTestimonials_container__items__elements__description__header">
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen.
                </p>
                <p className="CustomerTestimonials_container__items__elements__description__title">
                  Pros: <span>Copy Lorem Ipsum is simply dummy</span>
                </p>

                <p className="CustomerTestimonials_container__items__elements__description__title">
                  Cons:: <span>Lorem Ipsum is</span>
                </p>
                <div className="CustomerTestimonials_container__items__elements__description__check">
                  <img className="image" src={CheckIcon} />
                  <span className="CustomerTestimonials_container__items__elements__description__verified">
                    Verified purchase
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div className="CustomerTestimonials_container__items__elements">
            <div className="CustomerTestimonials_container__items__elements_con">
              <img src={ImageItem} />
              <span className="CustomerTestimonials_container__items__elements__text">
                InMotion L8F ELECTRIC SCOOTER (Water Proof German Version)
              </span>
              <p>Max Cooper</p>
              <div className="CustomerTestimonials_container__items__elements__rate">
                <div>
                  <h3 className="reviews-details__rating-point">
                    {' '}
                    {dataRate.rate}{' '}
                  </h3>
                  <ul className="product-info__rating-list reviews-details__rating-list">
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangePeaceOfBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBorderIcon}
                        alt="star"
                      />{' '}
                    </li>
                  </ul>
                </div>
                <p>December 17, 2020</p>
              </div>
              <div className="CustomerTestimonials_container__items__elements__description">
                <p className="CustomerTestimonials_container__items__elements__description__header">
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen.
                </p>
                <p className="CustomerTestimonials_container__items__elements__description__title">
                  Pros: <span>Copy Lorem Ipsum is simply dummy</span>
                </p>

                <p className="CustomerTestimonials_container__items__elements__description__title">
                  Cons:: <span>Lorem Ipsum is</span>
                </p>
                <div className="CustomerTestimonials_container__items__elements__description__check">
                  <img className="image" src={CheckIcon} />
                  <span className="CustomerTestimonials_container__items__elements__description__verified">
                    Verified purchase
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div className="CustomerTestimonials_container__items__elements">
            <div className="CustomerTestimonials_container__items__elements_con">
              <img src={ImageItem} />
              <span className="CustomerTestimonials_container__items__elements__text">
                InMotion L8F ELECTRIC SCOOTER (Water Proof German Version)
              </span>
              <p>Max Cooper</p>
              <div className="CustomerTestimonials_container__items__elements__rate">
                <div>
                  <h3 className="reviews-details__rating-point">
                    {' '}
                    {dataRate.rate}{' '}
                  </h3>
                  <ul className="product-info__rating-list reviews-details__rating-list">
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangePeaceOfBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBorderIcon}
                        alt="star"
                      />{' '}
                    </li>
                  </ul>
                </div>
                <p>December 17, 2020</p>
              </div>
              <div className="CustomerTestimonials_container__items__elements__description">
                <p className="CustomerTestimonials_container__items__elements__description__header">
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen.
                </p>
                <p className="CustomerTestimonials_container__items__elements__description__title">
                  Pros: <span>Copy Lorem Ipsum is simply dummy</span>
                </p>

                <p className="CustomerTestimonials_container__items__elements__description__title">
                  Cons:: <span>Lorem Ipsum is</span>
                </p>
                <div className="CustomerTestimonials_container__items__elements__description__check">
                  <img className="image" src={CheckIcon} />
                  <span className="CustomerTestimonials_container__items__elements__description__verified">
                    Verified purchase
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div className="CustomerTestimonials_container__items__elements">
            <div className="CustomerTestimonials_container__items__elements_con">
              <img src={ImageItem} />
              <span className="CustomerTestimonials_container__items__elements__text">
                InMotion L8F ELECTRIC SCOOTER (Water Proof German Version)
              </span>
              <p>Max Cooper</p>
              <div className="CustomerTestimonials_container__items__elements__rate">
                <div>
                  <h3 className="reviews-details__rating-point">
                    {' '}
                    {dataRate.rate}{' '}
                  </h3>
                  <ul className="product-info__rating-list reviews-details__rating-list">
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangePeaceOfBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBorderIcon}
                        alt="star"
                      />{' '}
                    </li>
                  </ul>
                </div>
                <p>December 17, 2020</p>
              </div>
              <div className="CustomerTestimonials_container__items__elements__description">
                <p className="CustomerTestimonials_container__items__elements__description__header">
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen.
                </p>
                <p className="CustomerTestimonials_container__items__elements__description__title">
                  Pros: <span>Copy Lorem Ipsum is simply dummy</span>
                </p>

                <p className="CustomerTestimonials_container__items__elements__description__title">
                  Cons:: <span>Lorem Ipsum is</span>
                </p>
                <div className="CustomerTestimonials_container__items__elements__description__check">
                  <img className="image" src={CheckIcon} />
                  <span className="CustomerTestimonials_container__items__elements__description__verified">
                    Verified purchase
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div className="CustomerTestimonials_container__items__elements">
            <div className="CustomerTestimonials_container__items__elements_con">
              <img src={ImageItem} />
              <span className="CustomerTestimonials_container__items__elements__text">
                InMotion L8F ELECTRIC SCOOTER (Water Proof German Version)
              </span>
              <p>Max Cooper</p>
              <div className="CustomerTestimonials_container__items__elements__rate">
                <div>
                  <h3 className="reviews-details__rating-point">
                    {' '}
                    {dataRate.rate}{' '}
                  </h3>
                  <ul className="product-info__rating-list reviews-details__rating-list">
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangePeaceOfBgIcon}
                        alt="star"
                      />{' '}
                    </li>
                    <li>
                      {' '}
                      <img
                        src={homeMainIcons.starOrangeBorderIcon}
                        alt="star"
                      />{' '}
                    </li>
                  </ul>
                </div>
                <p>December 17, 2020</p>
              </div>
              <div className="CustomerTestimonials_container__items__elements__description">
                <p className="CustomerTestimonials_container__items__elements__description__header">
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen.
                </p>
                <p className="CustomerTestimonials_container__items__elements__description__title">
                  Pros: <span>Copy Lorem Ipsum is simply dummy</span>
                </p>

                <p className="CustomerTestimonials_container__items__elements__description__title">
                  Cons:: <span>Lorem Ipsum is</span>
                </p>
                <div className="CustomerTestimonials_container__items__elements__description__check">
                  <img className="image" src={CheckIcon} />
                  <span className="CustomerTestimonials_container__items__elements__description__verified">
                    Verified purchase
                  </span>
                </div>
              </div>
            </div>
          </div>
          {/* maped Element */}
        </div>
      </div>
      <div className="CustomerTestimonials__btn">
        <button>Load more</button>
      </div>
    </div>
  )
}

export default CustomerTestimonials
