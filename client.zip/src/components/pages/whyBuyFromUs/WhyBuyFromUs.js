import React, { useState, useEffect } from 'react'
import './whyBuyFromUs.scss'
// import {url} from '../../../configs/config';
// import axios from 'axios';

// import VerifiedReviewItem from '../../items/single-product-page/VerifiedReviewItem';
import { homeMainIcons } from '../../../dummy-datas/images'
import ImageItem from '../../../assets/images/testimonailsItems.png'
import CheckIcon from '../../../assets/images/check.png'
import axios from 'axios'

function WhyBuyFromUs() {
  let url = 'https://freemotion-shop-back.herokuapp.com'
  const [dataRate, setDataRate] = useState([])
  const [link, setLink] = React.useState(0)
  const likElements = [
    'All reviews',
    'Electric Unicycles',
    'Electric Scooters',
    'Electric Skateboard',
  ]
  const [data, setData] = useState([])
  useEffect(() => {
    console.log(url)
    axios
      .get(`${url}/review/product/61addfaeb77e226c21dd51bd`)
      .then((res) => setData(res.data.review))
      // .then(res => console.log(res.data.faq))
      .catch((e) => console.log(e))
  }, [])
  function handleNavigation(index, element = 'All reviews') {
    setLink(index)
  }
  // const [data ,setData] = useState([])

  // useEffect(() => {
  //     console.log(url);
  //     axios.get(`${url}/review/product/${id}`)
  //     .then(res =>  setData(res.data.review))
  //     // .then(res => console.log(res.data.faq))
  //     .catch(e => console.log(e))
  // }, [])

  // const [visible, setVisible] = useState(3)

  // const readMore = () => {
  //     setVisible((prevValue) => prevValue +3)
  // }

  return (
    <div className="whyBuyFromUs wrapper2">
      <h1 className="whyBuyFromUs__title">Why Buy From Us</h1>
      <p className="whyBuyFromUs__text">
        Lorem Ipsum is simply dummy text of the printing and typesetting
        industry. Lorem Ipsum has been the industry's standard dummy text ever
        since the 1500s, when an unknown printer took a galley of type and
        scrambled it to make a type specimen book. Lorem Ipsum is simply dummy
        text of the printing and typesetting industry. Lorem Ipsum has been the
        industry's standard dummy text ever since the 1500s, when an unknown
        printer took a galley of type and scrambled it to make a type specimen
        book.
      </p>
      <h2 className="whyBuyFromUs__subtitle">
        A Few Of The Reasons You Should Buy From Us:
      </h2>
      <ul className="whyBuyFromUs__ul">
        <li className="whyBuyFromUs__list">Secure Ordering available</li>
        <li className="whyBuyFromUs__list">Lowest pricing available online</li>
        <li className="whyBuyFromUs__list">
          Courteous, knowledgeable and professional support
        </li>
        <li className="whyBuyFromUs__list">Tons of satisfied customers</li>
        <li className="whyBuyFromUs__list">
          Quality name brand all natural products. You will love our products
        </li>
        <li className="whyBuyFromUs__list">
          100% Satisfaction Money back guarantee.
        </li>
        <li className="whyBuyFromUs__list">
          All items in stock & ready to ship
        </li>
        <li className="whyBuyFromUs__list">
          Everyone that uses our products, come back for more. We must be doing
          something right!
        </li>
      </ul>
      <p className="whyBuyFromUs__text">
        From the moment that you click through our shop and browse through our
        different product sections all the way to the selection of products and
        ordering, we ensure that you’ll check out with 100% satisfaction
        guaranteed! But our service doesn’t end there. With our enthusiastic and
        helpful customer service team, we promise you a great aftersales service
        that extends way beyond the moment you receive your orders!
      </p>
      <section className="whyBuyFromUs__customer">
        <h1 className="whyBuyFromUs__customer-title">Customer Testimonials</h1>
        {/* <div className='whyBuyFromUs__customer'> */}
        <div className="whyBuyFromUs__customer-review">
          <div className="reviews__rating">
            <div className="reviews__content-box">
              <div className="reviews__user-review">
                <h6 className="reviews-details__text"> 0 User Reviews </h6>
              </div>
              <div className="reviews__rating-container">
                <h3 className="reviews-details__rating-point"> 5.0 </h3>
                <ul className="product-info__rating-list reviews-details__rating-list">
                  <li>
                    {' '}
                    <img src={homeMainIcons.starOrangeBgIcon} alt="star" />{' '}
                  </li>
                  <li>
                    {' '}
                    <img src={homeMainIcons.starOrangeBgIcon} alt="star" />{' '}
                  </li>
                  <li>
                    {' '}
                    <img src={homeMainIcons.starOrangeBgIcon} alt="star" />{' '}
                  </li>
                  <li>
                    {' '}
                    <img
                      src={homeMainIcons.starOrangePeaceOfBgIcon}
                      alt="star"
                    />{' '}
                  </li>
                  <li>
                    {' '}
                    <img
                      src={homeMainIcons.starOrangeBorderIcon}
                      alt="star"
                    />{' '}
                  </li>
                </ul>
              </div>
            </div>
            <div className="reviews__rating-status">
              <div className="rating-info__rating-status-item">
                <span className="rating-info__count"> 5 </span>
                <img src={homeMainIcons.starOrangeBgIcon} alt="rating star" />
                <div className="rating-info__box review__rating-info">
                  <i
                    style={{ width: 75 + '%' }}
                    className="rating-info__percentage"
                  />
                </div>
                <span className="rating-info__percent">{75}% </span>
              </div>
              <div className="rating-info__rating-status-item">
                <span className="rating-info__count"> 4 </span>
                <img src={homeMainIcons.starOrangeBgIcon} alt="rating star" />
                <div className="rating-info__box">
                  <i
                    style={{ width: 10 + '%' }}
                    className="rating-info__percentage"
                  />
                </div>
                <span className="rating-info__percent"> {10}% </span>
              </div>
              <div className="rating-info__rating-status-item">
                <span className="rating-info__count"> 3 </span>
                <img src={homeMainIcons.starOrangeBgIcon} alt="rating star" />
                <div className="rating-info__box">
                  <i
                    style={{ width: 10 + '%' }}
                    className="rating-info__percentage"
                  />
                </div>
                <span className="rating-info__percent"> {10}% </span>
              </div>
              <div className="rating-info__rating-status-item">
                <span className="rating-info__count"> 2 </span>
                <img src={homeMainIcons.starOrangeBgIcon} alt="rating star" />
                <div className="rating-info__box">
                  <i
                    style={{ width: 5 + '%' }}
                    className="rating-info__percentage"
                  />
                </div>
                <span className="rating-info__percent"> {5}% </span>
              </div>
              <div className="rating-info__rating-status-item">
                <span className="rating-info__count"> 1 </span>
                <img src={homeMainIcons.starOrangeBgIcon} alt="rating star" />
                <div className="rating-info__box">
                  <i
                    style={{ width: 0 + '%' }}
                    className="rating-info__percentage"
                  />
                </div>
                <span className="rating-info__percent"> {0}%</span>
              </div>
            </div>
          </div>
          <div className="whyBuyFromUs__customer-review-content">
            {/* maped Element */}
            <div className="Table-Navigation CustomerTestimonials_container__items__header">
              {likElements.map((elem, index) => (
                <p
                  className={link === index ? 'Table-Navigation__active' : ''}
                  onClick={() => handleNavigation(index, elem)}
                  key={index}
                >
                  {elem}
                </p>
              ))}
            </div>
            <div className="CustomerTestimonials_container__items__elements">
              <div className="CustomerTestimonials_container__items__elements_con">
                <img src={ImageItem} />
                <span className="CustomerTestimonials_container__items__elements__text">
                  InMotion L8F ELECTRIC SCOOTER (Water Proof German Version)
                </span>
                <p>Max Cooper</p>
                <div className="CustomerTestimonials_container__items__elements__rate">
                  <div>
                    <h3 className="reviews-details__rating-point">
                      {' '}
                      {dataRate.rate}{' '}
                    </h3>
                    <ul className="product-info__rating-list reviews-details__rating-list">
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangePeaceOfBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBorderIcon}
                          alt="star"
                        />{' '}
                      </li>
                    </ul>
                  </div>
                  <p>December 17, 2020</p>
                </div>
                <div className="CustomerTestimonials_container__items__elements__description">
                  <p className="CustomerTestimonials_container__items__elements__description__header">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a
                    type specimen.
                  </p>
                  <p className="CustomerTestimonials_container__items__elements__description__title">
                    Pros: <span>Copy Lorem Ipsum is simply dummy</span>
                  </p>

                  <p className="CustomerTestimonials_container__items__elements__description__title">
                    Cons:: <span>Lorem Ipsum is</span>
                  </p>
                  <div className="CustomerTestimonials_container__items__elements__description__check">
                    <img className="image" src={CheckIcon} />
                    <span className="CustomerTestimonials_container__items__elements__description__verified">
                      Verified purchase
                    </span>
                  </div>
                </div>
              </div>
            </div>
            {/* maped Element */}
            <div className="CustomerTestimonials_container__items__elements">
              <div className="CustomerTestimonials_container__items__elements_con">
                <img src={ImageItem} />
                <span className="CustomerTestimonials_container__items__elements__text">
                  InMotion L8F ELECTRIC SCOOTER (Water Proof German Version)
                </span>
                <p>Max Cooper</p>
                <div className="CustomerTestimonials_container__items__elements__rate">
                  <div>
                    <h3 className="reviews-details__rating-point">
                      {' '}
                      {dataRate.rate}{' '}
                    </h3>
                    <ul className="product-info__rating-list reviews-details__rating-list">
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangePeaceOfBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBorderIcon}
                          alt="star"
                        />{' '}
                      </li>
                    </ul>
                  </div>
                  <p>December 17, 2020</p>
                </div>
                <div className="CustomerTestimonials_container__items__elements__description">
                  <p className="CustomerTestimonials_container__items__elements__description__header">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a
                    type specimen.
                  </p>
                  <p className="CustomerTestimonials_container__items__elements__description__title">
                    Pros: <span>Copy Lorem Ipsum is simply dummy</span>
                  </p>

                  <p className="CustomerTestimonials_container__items__elements__description__title">
                    Cons:: <span>Lorem Ipsum is</span>
                  </p>
                  <div className="CustomerTestimonials_container__items__elements__description__check">
                    <img className="image" src={CheckIcon} />
                    <span className="CustomerTestimonials_container__items__elements__description__verified">
                      Verified purchase
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="CustomerTestimonials_container__items__elements">
              <div className="CustomerTestimonials_container__items__elements_con">
                <img src={ImageItem} />
                <span className="CustomerTestimonials_container__items__elements__text">
                  InMotion L8F ELECTRIC SCOOTER (Water Proof German Version)
                </span>
                <p>Max Cooper</p>
                <div className="CustomerTestimonials_container__items__elements__rate">
                  <div>
                    <h3 className="reviews-details__rating-point">
                      {' '}
                      {dataRate.rate}{' '}
                    </h3>
                    <ul className="product-info__rating-list reviews-details__rating-list">
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangePeaceOfBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBorderIcon}
                          alt="star"
                        />{' '}
                      </li>
                    </ul>
                  </div>
                  <p>December 17, 2020</p>
                </div>
                <div className="CustomerTestimonials_container__items__elements__description">
                  <p className="CustomerTestimonials_container__items__elements__description__header">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a
                    type specimen.
                  </p>
                  <p className="CustomerTestimonials_container__items__elements__description__title">
                    Pros: <span>Copy Lorem Ipsum is simply dummy</span>
                  </p>

                  <p className="CustomerTestimonials_container__items__elements__description__title">
                    Cons:: <span>Lorem Ipsum is</span>
                  </p>
                  <div className="CustomerTestimonials_container__items__elements__description__check">
                    <img className="image" src={CheckIcon} />
                    <span className="CustomerTestimonials_container__items__elements__description__verified">
                      Verified purchase
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="CustomerTestimonials_container__items__elements">
              <div className="CustomerTestimonials_container__items__elements_con">
                <img src={ImageItem} />
                <span className="CustomerTestimonials_container__items__elements__text">
                  InMotion L8F ELECTRIC SCOOTER (Water Proof German Version)
                </span>
                <p>Max Cooper</p>
                <div className="CustomerTestimonials_container__items__elements__rate">
                  <div>
                    <h3 className="reviews-details__rating-point">
                      {' '}
                      {dataRate.rate}{' '}
                    </h3>
                    <ul className="product-info__rating-list reviews-details__rating-list">
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangePeaceOfBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBorderIcon}
                          alt="star"
                        />{' '}
                      </li>
                    </ul>
                  </div>
                  <p>December 17, 2020</p>
                </div>
                <div className="CustomerTestimonials_container__items__elements__description">
                  <p className="CustomerTestimonials_container__items__elements__description__header">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a
                    type specimen.
                  </p>
                  <p className="CustomerTestimonials_container__items__elements__description__title">
                    Pros: <span>Copy Lorem Ipsum is simply dummy</span>
                  </p>

                  <p className="CustomerTestimonials_container__items__elements__description__title">
                    Cons:: <span>Lorem Ipsum is</span>
                  </p>
                  <div className="CustomerTestimonials_container__items__elements__description__check">
                    <img className="image" src={CheckIcon} />
                    <span className="CustomerTestimonials_container__items__elements__description__verified">
                      Verified purchase
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="CustomerTestimonials_container__items__elements">
              <div className="CustomerTestimonials_container__items__elements_con">
                <img src={ImageItem} />
                <span className="CustomerTestimonials_container__items__elements__text">
                  InMotion L8F ELECTRIC SCOOTER (Water Proof German Version)
                </span>
                <p>Max Cooper</p>
                <div className="CustomerTestimonials_container__items__elements__rate">
                  <div>
                    <h3 className="reviews-details__rating-point">
                      {' '}
                      {dataRate.rate}{' '}
                    </h3>
                    <ul className="product-info__rating-list reviews-details__rating-list">
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangePeaceOfBgIcon}
                          alt="star"
                        />{' '}
                      </li>
                      <li>
                        {' '}
                        <img
                          src={homeMainIcons.starOrangeBorderIcon}
                          alt="star"
                        />{' '}
                      </li>
                    </ul>
                  </div>
                  <p>December 17, 2020</p>
                </div>
                <div className="CustomerTestimonials_container__items__elements__description">
                  <p className="CustomerTestimonials_container__items__elements__description__header">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard dummy text ever since the 1500s, when an unknown
                    printer took a galley of type and scrambled it to make a
                    type specimen.
                  </p>
                  <p className="CustomerTestimonials_container__items__elements__description__title">
                    Pros: <span>Copy Lorem Ipsum is simply dummy</span>
                  </p>

                  <p className="CustomerTestimonials_container__items__elements__description__title">
                    Cons:: <span>Lorem Ipsum is</span>
                  </p>
                  <div className="CustomerTestimonials_container__items__elements__description__check">
                    <img className="image" src={CheckIcon} />
                    <span className="CustomerTestimonials_container__items__elements__description__verified">
                      Verified purchase
                    </span>
                  </div>
                </div>
              </div>
            </div>
            {/* maped Element */}
            {/* <section>
                                { data.slice(0, visible).map((verifiedReview) => <VerifiedReviewItem verifiedReview={ verifiedReview } key={ verifiedReview.id } />) }
                            </section>
                            <button
                                type="button"
                                className="content__change-btn"
                                onClick={readMore}
                            >
                                Load more 
                            </button> */}
          </div>
        </div>
        <div className="CustomerTestimonials__btn">
          <button>Load more</button>
        </div>
      </section>
    </div>
  )
}

export default WhyBuyFromUs
