import React from 'react'
import { Link } from 'react-router-dom'
import FirstImg from '../../../assets/images/deals/first.png'
import SecondImg from '../../../assets/images/deals/second.png'
import ThirdImg from '../../../assets/images/deals/third.png'
import SaleImg from '../../../assets/images/deals/saleImg.png'
import './deals.scss'

const Deals = () => {
  return (
    <div className="deals">
      <div className="deals_wrapper">
        <h2 className="deals_header_title">Deals</h2>
        <div className="deals_main">
          <div className="a deals_day">
            <img className="deals_day__img" src={SaleImg} />
            <div className="deals_day__content">
              <h3 className="deals_day__title">Deals of the Day</h3>
              <p className="deals_day__text">
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make a type{' '}
              </p>
              <Link
                className="deals_item__content__link the_day"
                to="/products"
              >
                Start shopping &#62;
              </Link>
            </div>
          </div>
          <div className="b deals_item">
            <div>
              <img src={FirstImg} />
            </div>
            <div className="deals_item__content">
              <h3 className="deals_item__content__title">
                Repeat Сustomer Discount
              </h3>
              <p className="deals_item__content__text">
                Buy at Freemotion and get a coupon code that you can use as a 5%
                discount for your future order.
              </p>
              <Link className="deals_item__content__link" to="/products">
                Start shopping &#62;
              </Link>
            </div>
          </div>
          <div className="c deals_item">
            {' '}
            <div>
              <img src={SecondImg} />
            </div>
            <div className="deals_item__content">
              <h3 className="deals_item__content__title">
                Repeat Сustomer Discount
              </h3>
              <p className="deals_item__content__text">
                Buy at Freemotion and get a coupon code that you can use as a 5%
                discount for your future order.
              </p>
              <Link className="deals_item__content__link" to="/products">
                Start shopping &#62;
              </Link>
            </div>
          </div>
          <div className="d deals_item">
            {' '}
            <div>
              <img src={ThirdImg} />
            </div>
            <div className="deals_item__content">
              <h3 className="deals_item__content__title">
                Repeat Сustomer Discount
              </h3>
              <p className="deals_item__content__text">
                Buy at Freemotion and get a coupon code that you can use as a 5%
                discount for your future order.
              </p>
              <Link className="deals_item__content__link" to="/products">
                Start shopping &#62;
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
export default Deals
