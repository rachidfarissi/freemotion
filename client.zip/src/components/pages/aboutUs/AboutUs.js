import React from 'react'
import './about.scss'
import aboutBg from './../../../assets/images/aboutBG.png'
import aboutBgMobile from './../../../assets/images/aboutBgMobile.png'
import Authorized from './../../../assets/images/authorized.png'
import lowestCost from './../../../assets/images/lowestCost.png'
import monetBack from './../../../assets/images/monetBack.png'
import year from './../../../assets/images/year.png'
import { useHistory } from 'react-router'

import { Link } from 'react-router-dom'

const AboutUs = () => {
  const history = useHistory()
  const redirection = (url) => history.push(url)
  return (
    <div className="aboutUs">
      <section className="aboutUs__content">
        <ul className="aboutUs__menu wrapper">
          <li>
            <Link to="/" className="aboutUs__menu-item">
              home
            </Link>
          </li>
          <span className="aboutUs__menu-line">/</span>
          <li>
            <Link to="/about-us" className="aboutUs__menu-item">
              about Us
            </Link>
          </li>
        </ul>
        <div className="aboutUs__container wrapper">
          <div className="aboutUs__container-text">
            <h1 className="aboutUs__container-title">Who we are</h1>
            <p className="aboutUs__container-paragraph">
              FreeMotion is an online shopping venue delivering the latest
              electric mobility products. Since 2014, FreeMotion has been a
              highly trusted vendor of 21st century mobility solutions that do
              not contribute to the pollution of our earth. We supply all types
              of accessories to service all of our transportation solutions.
            </p>
            <p className="aboutUs__container-paragraph">
              Powered by our dream of being part of the revolution in urban and
              suburban mobility, FreeMotion delivers top branded, smart electric
              mobility devices to enthusiastic & technology-savvy customers
              worldwide. We have a wide range of cutting-edge electric mobility
              solutions ranging from electronic hoverboards, electric unicycles,
              electric scooters, to electric skateboards. All are electric
              powered; very clean, and all bring a sense of fun and adventure to
              your travels or commute. To add to the revolution, FreeMotion is
              determined to keep our prices affordable and within the reach of
              most consumers.{' '}
            </p>
          </div>
          <picture className="aboutBg">
            <source srcset={aboutBg} media="(min-width:650px)" />
            <img src={aboutBgMobile} alt="aboutBg" className="aboutBgIn" />
          </picture>
        </div>
      </section>
      <section className="aboutUs__quality">
        <div className="aboutUs__quality-block wrapper">
          <div className="aboutUs__quality-icons">
            <div
              onClick={() => redirection('/deals')}
              className="aboutUs__quality-icons__item"
            >
              <img
                src={Authorized}
                alt="Authorized icon"
                className="aboutUs__quality-icons__item-icon"
              />
              <h2 className="aboutUs__quality-icons__item-title">authorized</h2>
              <p className="aboutUs__quality-icons__item-text">
                Distributor/dealer
              </p>
            </div>
            <div
              onClick={() => redirection('/about-us')}
              className="aboutUs__quality-icons__item"
            >
              <img
                src={lowestCost}
                alt="lowest Cost icon"
                className="aboutUs__quality-icons__item-icon"
              />
              <h2 className="aboutUs__quality-icons__item-title">
                LOWEST COST
              </h2>
              <p className="aboutUs__quality-icons__item-text">
                Lowest price guarantee
              </p>
            </div>
            <div
              onClick={() => redirection('/about-us')}
              className="aboutUs__quality-icons__item"
            >
              <img
                src={year}
                alt="yea ion"
                className="aboutUs__quality-icons__item-icon"
              />
              <h2 className="aboutUs__quality-icons__item-title">1 YEAR</h2>
              <p className="aboutUs__quality-icons__item-text">
                1 year complete warranty
              </p>
            </div>
            <div
              onClick={() => redirection('/shippingAndReturns')}
              className="aboutUs__quality-icons__item"
            >
              <img
                src={monetBack}
                alt="monet Back icon"
                className="aboutUs__quality-icons__item-icon"
              />
              <h2 className="aboutUs__quality-icons__item-title">MONEY BACK</h2>
              <p className="aboutUs__quality-icons__item-text">
                Easy free returns
              </p>
            </div>
          </div>
          <div className="aboutUs__quality-content">
            <h1 className="aboutUs__quality-content-title">
              Quality and Support
            </h1>
            <p className="aboutUs__quality-content-text">
              Being an e-commerce website, we understand that every customer
              wants a convenient online purchase, quality product, quick
              delivery, a 24/7 access to customer service, and uncomplicated
              exchange policies. This is the goal of FreeMotion, Everyone at
              FreeMotion believes in, and works toward that goal. We assist
              customers through our interactive website and catalogs, our 24/7
              available service and device experts, and our consumer-friendly
              exchange & return policies. FreeMotion believes that happy
              customers are repeat customers. As our products are cutting-edge,
              FreeMotion makes sure the customer has a resource to turn to for
              information and support.
            </p>
          </div>
        </div>
      </section>
      <section className="aboutUs__our-values">
        <h1 className="aboutUs__our-values__title wrapper">Our Values </h1>
        <h3 className="aboutUs__our-values__subtitle wrapper">
          FreeMotion believes in the values of Quality, Trust, and Transparency.
        </h3>
        <div className="aboutUs__our-values__container wrapper">
          <article className="aboutUs__our-values__item">
            <h2 className="aboutUs__our-values__item-number">1</h2>
            <h3 className="aboutUs__our-values__item-title">Quality</h3>
            <p className="aboutUs__our-values__item-text">
              Quality matters! FreeMotion believes in selling quality over
              quantity. We believe that providing our customers with a quality
              product will produce happy customers. A happy customer always
              lands back at FreeMotion. All our products are certified and abide
              by the regulations of North America Safety Standards.
            </p>
          </article>
          <article className="aboutUs__our-values__item">
            <h2 className="aboutUs__our-values__item-number">2</h2>
            <h3 className="aboutUs__our-values__item-title">Trust</h3>
            <p className="aboutUs__our-values__item-text">
              FreeMotion knows the reason behind the success of any company is
              its workforce. FreeMotion believes in and takes care of its
              employees, partly because happy employees service customers
              efficiently and with a smile. We Solve Problems. And solving
              problems engenders TRUST. Trust between FreeMotion and its
              customers accounts for the many repeat customers we enjoy.{' '}
            </p>
          </article>
          <article className="aboutUs__our-values__item">
            <h2 className="aboutUs__our-values__item-number">3</h2>
            <h3 className="aboutUs__our-values__item-title">Transparency</h3>
            <p className="aboutUs__our-values__item-text">
              In a more and more online world, FreeMotion wants to make you feel
              as if we are just one step away. We engage as much as possible
              with our clients. FreeMotion is open for genuine discussions and
              feedback from the customers. If you just feel like writing about
              your electric mobility, just drop us a line.
            </p>
          </article>
        </div>
      </section>
      <section className="aboutUs__our-goals">
        <div className="wrapper">
          <div className="aboutUs__our-goals__content">
            <h1 className="aboutUs__our-goals__content-title">Our Goals </h1>
            <p className="aboutUs__our-goals__content-text">
              FreeMotion aims at becoming a leading e-commerce portal for 21st
              century mobility. We are well on our way towards this goal and we
              intend to remain here at the top. FreeMotion wants to become the
              first choice of its customers for all electric mobility products
              and accessories. FreeMotion is your destination to assure a smooth
              purchase, fast delivery, and real support of high-quality mobility
              products at reasonable prices. Let us not forget, all our products
              are certified by and abide by the North America Safety Standards.
              FreeMotion should be first in mindshare when anyone is thinking
              about high quality electric personal transportation with long term
              durability and excellent end-to-end customer service and support.{' '}
            </p>
            <p className="aboutUs__our-goals__content-text">
              Start exploring the unseen, visit more of your world, find your
              FREEDOM, and make your journey count with FreeMotion’s latest
              Eco-friendly mobility solutions and world class service and
              support.
            </p>
          </div>
        </div>
      </section>
      {/* <Foote */}
    </div>
  )
}

export default AboutUs
