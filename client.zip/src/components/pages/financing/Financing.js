import React, { useState, useEffect } from 'react'
import arrow from './../../../assets/images/financing/arrow.png'
import axios from 'axios'
import { Link } from 'react-router-dom'
import './financing.scss'

const Financing = () => {
  const [data, setData] = useState()
  let url = 'https://freemotion-shop-back.herokuapp.com'

  useEffect(() => {
    axios
      .get(`${url}/finance/list`)
      .then((res) => setData(res.data.finance))
      .catch((e) => console.log(e))
  }, [])

  return (
    <div className="financing">
      <div className="financing__hGrup wrapper">
        <h1 className="financing-title">Financing</h1>
        <p className="financing-subtitle">
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry's standard dummy text ever
          since the 1500s
        </p>
      </div>
      <section className="financing__container wrapper">
        {data &&
          data.map((element) => {
            return (
              <article className="financing__item">
                <div className="financing__item__info">
                  <img
                    src={`${url}/${element.img}`}
                    className="financing__item__img"
                    alt="klarna icon"
                  />
                  <Link to="" className="financing__link">
                    {' '}
                    Visit website{' '}
                    <img
                      src={arrow}
                      alt="arrow icon"
                      className="financing__link-icon"
                    />
                  </Link>
                </div>
                <div className="financing__content">
                  <h2 className="financing__title">{element.title_one}</h2>
                  <p className="financing__text">{element.description_one}</p>
                  <h3 className="financing__subtitle">{element.title_two}</h3>
                  {element.description_two.map((list) => (
                    <ul className="financing__ul">
                      <li className="financing__list">{list}</li>
                    </ul>
                  ))}
                </div>
              </article>
            )
          })}
      </section>
    </div>
  )
}

export default Financing
