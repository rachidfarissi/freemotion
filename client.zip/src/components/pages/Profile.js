import React from 'react'
import './Profile.css'

export default function Profile() {
  return <div>profile data</div>
}
