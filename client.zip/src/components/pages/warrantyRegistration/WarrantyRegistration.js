import React, { useState } from 'react'
import { useHistory } from 'react-router'
import { useValidity } from '../../custom-hooks/form-validity'
import axios from 'axios'
import jwt_decode from 'jwt-decode'
import SelectCountryDropdown from '../../UI/dropdowns/SelectCountryDropdown'

// import FAQItem from '../../';
import './warrantyRegistration.scss'

const WarrantyRegistration = ({ onLogin }) => {
  const history = useHistory()
  const [agree, setAgree] = useState(false)
  const [selectedCountry, setSelectedCountry] = useState('')
  const [countryInputIsInvalid, setCountryInputIsInvalid] = useState(false)
  const [user, setUser] = useState('')

  const isNotEmpty = (value) => value.trim() !== ''

  const passSelectedCountry = (country) => {
    setSelectedCountry(country)
  }

  const countryInputIsValid = isNotEmpty(selectedCountry)

  const {
    enteredValue: enteredFirstName,
    inputIsValid: firstNameInputIsValid,
    inputIsInvalid: firstNameInputIsInvalid,
    changeInputValueHandler: changeFirstNameInputValueHandler,
    blurInputHandler: blurFirstNameInputHandler,
  } = useValidity(isNotEmpty)

  const {
    enteredValue: enteredLastName,
    inputIsValid: lastNameInputIsValid,
    inputIsInvalid: lastNameInputIsInvalid,
    changeInputValueHandler: changeLastNameInputValueHandler,
    blurInputHandler: blurLastNameInputHandler,
  } = useValidity(isNotEmpty)

  const {
    enteredValue: enteredTownCity,
    inputIsValid: townCityInputIsValid,
    inputIsInvalid: townCityInputIsInvalid,
    changeInputValueHandler: changeTownCityInputValueHandler,
    blurInputHandler: blurTownCityInputHandler,
  } = useValidity(isNotEmpty)

  const {
    enteredValue: enteredStreetAddress,
    inputIsValid: streetAddressInputIsValid,
    inputIsInvalid: streetAddressInputIsInvalid,
    changeInputValueHandler: changeStreetAddressInputValueHandler,
    blurInputHandler: blurStreetAddressInputHandler,
  } = useValidity(isNotEmpty)

  const {
    enteredValue: enteredPhoneNumber,
    inputIsValid: phoneNumberInputIsValid,
    inputIsInvalid: phoneNumberInputIsInvalid,
    changeInputValueHandler: changePhoneNumberInputValueHandler,
    blurInputHandler: blurPhoneNumberInputHandler,
  } = useValidity(isNotEmpty)

  const {
    enteredValue: enteredEmailAddress,
    inputIsValid: emailAddressInputIsValid,
    inputIsInvalid: emailAddressInputIsInvalid,
    changeInputValueHandler: changeEmailAddressInputValueHandler,
    blurInputHandler: blurEmailAddressInputHandler,
  } = useValidity((value) => /\w+(\.|-|_)?\w+@\w+\.\w{2,3}/.test(value))

  const {
    enteredValue: enteredStateRegion,
    inputIsValid: stateRegionInputIsValid,
    inputIsInvalid: stateRegionInputIsInvalid,
    changeInputValueHandler: changeStateRegionInputValueHandler,
    blurInputHandler: blurStateRegionInputHandler,
  } = useValidity(isNotEmpty)

  const {
    enteredValue: enteredPostcode,
    inputIsValid: postcodeInputIsValid,
    inputIsInvalid: postcodeInputIsInvalid,
    changeInputValueHandler: changePostcodeInputValueHandler,
    blurInputHandler: blurPostcodeInputHandler,
  } = useValidity(isNotEmpty)

  const {
    enteredValue: enteredModelPuechased,
    inputIsValid: modelPuechasedInputIsValid,
    inputIsInvalid: modelPuechasedInputIsInvalid,
    changeInputValueHandler: changeModelPuechasedInputValueHandler,
    blurInputHandler: blurModelPuechasedInputHandler,
  } = useValidity(isNotEmpty)

  const {
    enteredValue: enteredPricePaid,
    inputIsValid: pricePaidInputIsValid,
    inputIsInvalid: pricePaidInputIsInvalid,
    changeInputValueHandler: changePricePaidInputValueHandler,
    blurInputHandler: blurPricePaidInputHandler,
  } = useValidity(isNotEmpty)

  const registerFormIsValid =
    firstNameInputIsValid &&
    lastNameInputIsValid &&
    emailAddressInputIsValid &&
    streetAddressInputIsValid &&
    townCityInputIsValid &&
    stateRegionInputIsValid &&
    postcodeInputIsValid &&
    phoneNumberInputIsValid &&
    agree &&
    modelPuechasedInputIsInvalid &&
    pricePaidInputIsValid

  const submitRegisterForm = (evt) => {
    evt.preventDefault()
    if (!registerFormIsValid) return
    if (!countryInputIsValid) {
      setCountryInputIsInvalid(true)
      return
    }
    const registerFormData = {
      first_name: enteredFirstName,
      last_name: enteredLastName,
      email: enteredEmailAddress,
      country: selectedCountry,
      street: enteredStreetAddress,
      city: enteredTownCity,
      region: enteredStateRegion,
      zip: enteredPostcode,
      // password: enteredPassword
    }
    axios
      .post(`https://freemotion-shop-back.herokuapp.com/auth/signup`, {
        first_name: enteredFirstName,
        last_name: enteredLastName,
        email: enteredEmailAddress,
        country: selectedCountry,
        street: enteredStreetAddress,
        city: enteredTownCity,
        region: enteredStateRegion,
        zip: enteredPostcode,
        // password: enteredPassword
      })
      .then((res) => {
        const token = res.data.token
        const data = jwt_decode(token)
        setUser(data)
      })
      .catch((e) => console.log(e))
    onLogin()

    history.push('/my-account')
    // console.log(registerFormData);
  }

  function resetForm() {
    alert(1)
    changeFirstNameInputValueHandler((enteredFirstName) => '')
    // changeLastNameInputValueHandler(enteredLastName => '')
    // changeTownCityInputValueHandler(enteredTownCity => '')
    // changeStreetAddressInputValueHandler(enteredStreetAddress => '')
    // setEmail('')
  }

  return (
    <div className="warrantyRegistration wrapper2">
      <h1 className="warrantyRegistration__Title">
        Warranty / Product Registration Form
      </h1>
      <p className="warrantyRegistration__Text">
        Please take a moment to register your product with us and sign up to
        receive infromation about updates and new products releases. Send
        registration form by mail or electronically
      </p>
      <div className="warrantyRegistration__page">
        <form className="warrantyRegistration__form">
          <div className="ecommerce-input__container">
            <label
              htmlFor="first-name"
              className={`ecommerce-input__label ${
                firstNameInputIsInvalid && 'invalid-label'
              }`}
            >
              First name *
            </label>
            <div
              className={`warrantyRegistration__form-input__input-box ${
                firstNameInputIsInvalid && 'invalid-input'
              }`}
            >
              <input
                type="text"
                id="first-name"
                className="ecommerce-input__input"
                value={enteredFirstName}
                onChange={changeFirstNameInputValueHandler}
                onBlur={blurFirstNameInputHandler}
                placeholder="Enter first name"
                autoComplete="off"
              />
            </div>
            {firstNameInputIsInvalid && (
              <p className="invalid-msg-info"> Invalid first name msg </p>
            )}
          </div>
          <div className="ecommerce-input__container">
            <label
              htmlFor="last-name"
              className={`ecommerce-input__label ${
                lastNameInputIsInvalid && 'invalid-label'
              }`}
            >
              Last name *
            </label>
            <div
              className={`warrantyRegistration__form-input__input-box ${
                lastNameInputIsInvalid && 'invalid-input'
              }`}
            >
              <input
                type="text"
                id="last-name"
                className="ecommerce-input__input"
                value={enteredLastName}
                onChange={changeLastNameInputValueHandler}
                onBlur={blurLastNameInputHandler}
                placeholder="Enter last name"
                autoComplete="off"
              />
            </div>
            {lastNameInputIsInvalid && (
              <p className="invalid-msg-info"> Invalid last name msg </p>
            )}
          </div>
          <div className="ecommerce-input__container">
            <label
              htmlFor="town-city"
              className={`ecommerce-input__label ${
                townCityInputIsInvalid && 'invalid-label'
              }`}
            >
              Town / city *
            </label>
            <div
              className={`warrantyRegistration__form-input__input-box ${
                townCityInputIsInvalid && 'invalid-input'
              }`}
            >
              <input
                type="text"
                id="town-city"
                className="ecommerce-input__input"
                value={enteredTownCity}
                onChange={changeTownCityInputValueHandler}
                onBlur={blurTownCityInputHandler}
                placeholder="Enter town / city"
                autoComplete="off"
              />
            </div>
            {townCityInputIsInvalid && (
              <p className="invalid-msg-info"> Invalid town / city msg </p>
            )}
          </div>
          <div className="ecommerce-input__container">
            <label
              htmlFor="street-address"
              className={`ecommerce-input__label ${
                streetAddressInputIsInvalid && 'invalid-label'
              }`}
            >
              Street address *
            </label>
            <div
              className={`warrantyRegistration__form-input__input-box ${
                streetAddressInputIsInvalid && 'invalid-input'
              }`}
            >
              <input
                type="text"
                id="street-address"
                className="ecommerce-input__input"
                value={enteredStreetAddress}
                onChange={changeStreetAddressInputValueHandler}
                onBlur={blurStreetAddressInputHandler}
                placeholder="Enter street address"
                autoComplete="off"
              />
            </div>
            {streetAddressInputIsInvalid && (
              <p className="invalid-msg-info"> Invalid street address msg </p>
            )}
          </div>
          <div className="ecommerce-input__container">
            <label
              htmlFor="postcode-zip"
              className={`ecommerce-input__label ${
                postcodeInputIsInvalid && 'invalid-label'
              }`}
            >
              Postcode / ZIP *
            </label>
            <div
              className={`warrantyRegistration__form-input__input-box ${
                postcodeInputIsInvalid && 'invalid-input'
              }`}
            >
              <input
                type="number"
                id="postcode-zip"
                className="ecommerce-input__input"
                value={enteredPostcode}
                onChange={changePostcodeInputValueHandler}
                onBlur={blurPostcodeInputHandler}
                placeholder="Enter postcode / ZIP"
                autoComplete="off"
              />
            </div>
            {postcodeInputIsInvalid && (
              <p className="invalid-msg-info"> Invalid postcode msg </p>
            )}
          </div>

          <SelectCountryDropdown
            onPass={passSelectedCountry}
            selectedCountry={selectedCountry}
            countryInputIsInvalid={countryInputIsInvalid}
            onReset={() => setCountryInputIsInvalid(false)}
          />
          <div className="ecommerce-input__container">
            <label
              htmlFor="email-address"
              className={`ecommerce-input__label ${
                emailAddressInputIsInvalid && 'invalid-label'
              }`}
            >
              Email *
            </label>
            <div
              className={`warrantyRegistration__form-input__input-box ${
                emailAddressInputIsInvalid && 'invalid-input'
              }`}
            >
              <input
                type="email"
                id="email-address"
                className="ecommerce-input__input"
                value={enteredEmailAddress}
                onChange={changeEmailAddressInputValueHandler}
                onBlur={blurEmailAddressInputHandler}
                placeholder="Enter email address"
                autoComplete="off"
              />
            </div>
            {emailAddressInputIsInvalid && (
              <p className="invalid-msg-info"> Invalid email address msg </p>
            )}
          </div>
          <div className="ecommerce-input__container">
            <label
              htmlFor="tel"
              className={`ecommerce-input__label ${
                phoneNumberInputIsInvalid && 'invalid-label'
              }`}
            >
              Phone *
            </label>
            <div
              className={`warrantyRegistration__form-input__input-box ${
                phoneNumberInputIsInvalid && 'invalid-input'
              }`}
            >
              <input
                type="tel"
                id="tel"
                className="ecommerce-input__input"
                value={enteredPhoneNumber}
                onChange={changePhoneNumberInputValueHandler}
                onBlur={blurPhoneNumberInputHandler}
                placeholder="E.g. (123) 456-7890"
                autoComplete="off"
              />
            </div>
            {phoneNumberInputIsInvalid && (
              <p className="invalid-msg-info"> Invalid email address msg </p>
            )}
          </div>
          <div className="ecommerce-input__container">
            <label
              htmlFor="ModelPuechased"
              className={`ecommerce-input__label ${
                modelPuechasedInputIsValid && 'invalid-label'
              }`}
            >
              Model Puechased *
            </label>
            <div
              className={`warrantyRegistration__form-input__input-box ${
                modelPuechasedInputIsValid && 'invalid-input'
              }`}
            >
              <input
                type="text"
                id="ModelPuechased"
                className="ecommerce-input__input"
                value={enteredModelPuechased}
                onChange={changeModelPuechasedInputValueHandler}
                onBlur={blurModelPuechasedInputHandler}
                placeholder="Enter model purchased"
                autoComplete="off"
              />
            </div>
            {modelPuechasedInputIsValid && (
              <p className="invalid-msg-info"> Invalid model purchased</p>
            )}
          </div>
          <div className="ecommerce-input__container">
            <label
              htmlFor="PricePaid"
              className={`ecommerce-input__label ${
                pricePaidInputIsInvalid && 'invalid-label'
              }`}
            >
              Price paid *
            </label>
            <div
              className={`warrantyRegistration__form-input__input-box ${
                pricePaidInputIsInvalid && 'invalid-input'
              }`}
            >
              <input
                type="text"
                id="PricePaid"
                className="ecommerce-input__input"
                value={enteredPricePaid}
                onChange={changePricePaidInputValueHandler}
                onBlur={blurPricePaidInputHandler}
                placeholder="Enter price paid"
                autoComplete="off"
              />
            </div>
            {pricePaidInputIsInvalid && (
              <p className="invalid-msg-info"> Invalid email address msg </p>
            )}
          </div>

          <div className="warrantyRegistration__buttons">
            <button
              className="warrantyRegistration__form__resetBtn"
              type="reset"
              onClick={() => resetForm()}
            >
              Reset form
            </button>
            <button
              className="warrantyRegistration__form__submitBtn"
              type="submit"
            >
              Submit
            </button>
          </div>
        </form>
        <section className="WarrantyRegistration__container">
          <article className="warrantyRegistration__item">
            <h2 className="warrantyRegistration__item-title">
              Warranty details{' '}
            </h2>
            <p className="warrantyRegistration__item-text">
              We offer a generous 12-month Limited Warranty that covers the
              original purchaser from any defects under normal use from the date
              of purchase. We also offer free technical support for 12 months,
              including the help of getting repair service and spare parts. We
              offer a 6 months warranty for our used certified items.
              Unfortunately, our warranty does not cover water damage or any
              kind of physical damage including road accidents. Items modified
              by the customer are not covered.
            </p>
          </article>
          <article className="warrantyRegistration__item">
            <h2 className="warrantyRegistration__item-title">
              Warranty Limitations:
            </h2>
            <p className="warrantyRegistration__item-text">
              This Limited Warranty covers the original purchaser from any
              defects in material or workmanship under normal use for one year
              from the date of the invoice. This warranty is only offered to the
              original purchaser of the product and is not transferable to a
              subsequent purchaser. Freemotion will either repair or replace the
              product at no charge, using new or refurbished replacement parts
              at our discretion. Replacements may be different but functionally
              equivalent models. This Limited Warranty does not cover any
              problem that is caused by conditions, malfunctions, or damage not
              resulting from defects in material or workmanship. These
              conditions may include but are not limited to, road hazards,
              accidents, and improper operation or maintenance. Items returned
              for refund must be returned within 14 days from delivery. Under no
              circumstances will we issue refunds after 14 days of delivery.
            </p>
          </article>
          <article className="warrantyRegistration__item">
            <h2 className="warrantyRegistration__item-title">
              Replacement Extended Warranty:
            </h2>
            <p className="warrantyRegistration__item-text">
              All replacement products are covered by the standard warranty
              starting at the date of the original delivery. If for various
              reasons the replacement procedure extends beyond the warranty
              period, we at our discretion will extend the warranty coverage on
              such replacement up to an additional 30 days. Please be advised
              that this extended warranty is final and any additional extensions
              are non-negotiable.
            </p>
          </article>
          <article className="warrantyRegistration__item">
            <h2 className="warrantyRegistration__item-title">
              Limits and Exclusions:
            </h2>
            <p className="warrantyRegistration__item-text">
              There are no express warranties except as listed above. FreeMotion
              shall not be liable for special, incidental, consequential or
              punitive damages, including, without limitation, direct or
              indirect damages for personal injury, loss of goodwill, profits or
              revenue, loss of use this product or any associated equipment,
              cost of substitute equipment, downtime cost, or any other losses,
              or claims of any party dealing with buyers from such damages,
              resulting from the use of or inability to use this product or
              arising from breach of warranty or contract, negligence, or any
              other legal theory. In no event shall FreeMotion be liable for any
              incidental, indirect, special or consequential damages or
              liabilities (including but not limited to incidental or
              consequential damages for loss of time, inconvenience, loss of use
              of product, or any other consequential or incidental loss) in
              connection with the purchase, use, or operation of the product.
              FreeMotion is not liable for property damage, personal injury, or
              death. All express and implied warranties, including the
              warranties of merchantability and fitness for a particular
              purpose, are limited to the applicable warranty period set forth
              above.
            </p>
          </article>
        </section>
      </div>
    </div>
  )
}

export default WarrantyRegistration
