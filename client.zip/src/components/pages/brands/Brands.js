import React, { useState, useEffect } from 'react'
import FAQItem from '../../items/single-product-page/faqItem/FAQItem'
import axios from 'axios'
import { url } from '../../../configs/config'
// import Search from '../../../assets/icons/support/search.png';
import DataTable from './dataTable/DataTable'

// import FAQItem from '../../';
import './brands.scss'
import { Link } from 'react-router-dom'

const BuyingGuide = () => {
  const [data, setData] = useState([])
  const [dataBrands, setDataBrands] = useState([])

  useEffect(() => {
    axios
      .post(`${url}/faq/list`, {
        category: [
          'string',
          'electric_electric_unicycle',
          'owning_electric_unicycle',
          'buying_electric_unicycle',
        ],
      })
      .then((res) => setData(res.data.faq))
      .catch((e) => console.log(e))
  }, [])

  console.log(data)

  useEffect(() => {
    axios
      .get(`${url}/brand/list/brand`)
      .then((res) => setDataBrands(res.data.brand_list))
      .catch((e) => console.log(e))
  }, [])

  console.log(dataBrands, '777')

  function dataFiltering(categoryName) {
    if (data) {
      const filtered = data.filter((item) => item.category === categoryName)
      return filtered.map((faq, index) => (
        <FAQItem faq={faq} key={faq.id} index={index} />
      ))
    }
  }

  return (
    <div className="brands wrapper2">
      <h1 className="brands__Title">Brands</h1>
      <div className="brands__logos">
        {dataBrands &&
          dataBrands.map((brand, index) => (
            <Link
              key={index}
              className="brands__logos-item"
              to={{ pathname: brand.url }}
              target="_blank"
            >
              <img
                src={`${url}/${brand.img}`}
                className="brands__logos-item-img"
                alt="brand icon"
              />
            </Link>
          ))}
      </div>
      <DataTable />
      <div className="brands__page">
        <div className="brands__container">
          <div className="brands__box">
            <h2 className="brands__title">
              {data && 'Electric Unicycle safety FAQ'}
            </h2>
            <div className="brands__content">
              {dataFiltering('electric_electric_unicycle')}
            </div>
          </div>
          <div className="brands__box">
            <h2 className="brands__title">
              {data && 'Owning an electric unicycle FAQ'}
            </h2>
            <div className="brands__content">
              {dataFiltering('owning_electric_unicycle')}
            </div>
          </div>
          <div className="brands__box">
            <h2 className="brands__title">
              {data && 'Buying an electric unicycle FAQ'}
            </h2>
            <div className="brands__content">
              {dataFiltering('buying_electric_unicycle')}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default BuyingGuide
