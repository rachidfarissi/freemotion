import * as React from 'react'
import { Link } from 'react-router-dom'
// import Paper from '@mui/material/Paper'
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TablePagination from '@mui/material/TablePagination'
import TableRow from '@mui/material/TableRow'
import InfoIcon from '@mui/icons-material/Info'
import IconButton from '@mui/material/IconButton'
import { ReactComponent as InfoLogo } from './info.svg'
import Vector from './Vector.png'
import axios from 'axios'
import './dataTable.scss'
import { url } from '../../../../configs/config'
import Stack from '@mui/material/Stack'
import LinearProgress from '@mui/material/LinearProgress'

const columns = [
  { id: 'name', label: null, minWidth: 170 },
  { id: 'code', label: 'InMotion', minWidth: 100 },
  {
    id: 'population',
    label: 'King Song',
    minWidth: 170,
    align: 'right',
    // format: (value) => value.toLocaleString('en-US'),
  },
  {
    id: 'size',
    label: 'Gotway',
    minWidth: 170,
    align: 'right',
    // format: (value) => value.toLocaleString('en-US'),
  },
  {
    id: 'density',
    label: 'Veteran',
    minWidth: 170,
    align: 'right',
    // format: (value) => value.toFixed(2),
  },
]
let b = <img src={Vector} />

function createData(name, code, population, size, density) {
  // const density = population / size
  return { name, code, population, size, density }
}

// const rows = [
//   createData('test', 'test', 1324171354, 3287263, 1),
//   createData('test', 'test', 1403500365, 9596961),
//   createData('test', 'test', 60483973, 301340),
//   createData('test', 'test', 327167434, 9833520),
//   createData('test', 'test', 37602103, 9984670),
//   createData('test', 'test', 25475400, 7692024),
//   createData('test', 'test', 83019200, 357578),
//   createData('test', 'test', 4857000, 70273),
// ]

export default function DataTable() {
  const [page, setPage] = React.useState(0)
  const [rowsPerPage, setRowsPerPage] = React.useState(10)
  const [link, setLink] = React.useState(0)
  const [rowss, setRowss] = React.useState()
  const likElements = [
    'Electric Unicycles',
    'Electric Scooters',
    'Electric Skateboard',
  ]
  const [brandRateList, setBrandRateList] = React.useState()

  React.useEffect(() => {
    axios
      .get(`${url}/brand/rate/get/Electric Unicycles`)
      .then((res) => res.data.brand_rate)
      .then((res) =>
        setRowss([
          createData(
            'Innovation ',
            res[0].innovation,
            res[1].innovation,
            res[2].innovation,
            res[3].innovation
          ),
          createData(
            'Releases',
            res[0].releases,
            res[1].releases,
            res[2].releases,
            res[3].releases
          ),
          createData(
            'Performance',
            res[0].perfomance,
            res[1].perfomance,
            res[2].perfomance,
            res[3].perfomance
          ),
          createData(
            'Value',
            res[0].value,
            res[1].value,
            res[2].value,
            res[3].value
          ),
          createData(
            'Range',
            res[0].range,
            res[1].range,
            res[2].range,
            res[3].range
          ),
          createData(
            'Reliability',
            res[0].reliability,
            res[1].reliability,
            res[2].reliability,
            res[3].reliability
          ),
          createData(
            'Comfort',
            res[0].comfort,
            res[1].comfort,
            res[2].comfort,
            res[3].comfort
          ),
          createData(
            'Aesthetics',
            res[0].aesthetics,
            res[1].aesthetics,
            res[2].aesthetics,
            res[3].aesthetics
          ),
        ])
      )
    // handleNavigation(0)
  }, [])

  function handleNavigation(index, element = 'Electric Unicycles') {
    setRowss([])
    setLink(index)

    // setRowss([
    //   createData('Innovation ', 2, 2, 3, 1),
    //   createData(
    //     'Releases',
    //     'About 1 a year',
    //     'About 2 a year',
    //     '3+ a year',
    //     '1 a year so far'
    //   ),
    //   createData('Performance', 2, 1, 2, 3),
    //   createData('Value', 3, 1, 2, 3),
    //   createData('Range', 2, 1, 2, 3),
    //   createData('Reliability', 3, 1, 2, 3),
    //   createData('Comfort', 2, 2, 2, 1),
    //   createData('Aesthetics', 1, 3, 2, 1),
    // ])

    // setRowss([
    //   createData('Innovation', item.inovation),
    //   createData('Releases', item.releases),
    //   createData('Performance', 2, 1, 2, 3),
    //   createData('Value', item.value),
    //   createData('Range', item.range),
    //   createData('Reliability', item.reliability),
    //   createData('Comfort', item.comfort),
    //   createData('Aesthetics', item.aesthetics),
    // ])
    let arr = []
    switch (element) {
      case 'Electric Unicycles':
        return axios
          .get(`${url}/brand/rate/get/Electric Unicycles`)
          .then((res) => res.data.brand_rate)
          .then((res) =>
            setRowss([
              createData(
                'Innovation ',
                res[0].innovation,
                res[1].innovation,
                res[2].innovation,
                res[3].innovation
              ),
              createData(
                'Releases',
                res[0].releases,
                res[1].releases,
                res[2].releases,
                res[3].releases
              ),
              createData(
                'Performance',
                res[0].perfomance,
                res[1].perfomance,
                res[2].perfomance,
                res[3].perfomance
              ),
              createData(
                'Value',
                res[0].value,
                res[1].value,
                res[2].value,
                res[3].value
              ),
              createData(
                'Range',
                res[0].range,
                res[1].range,
                res[2].range,
                res[3].range
              ),
              createData(
                'Reliability',
                res[0].reliability,
                res[1].reliability,
                res[2].reliability,
                res[3].reliability
              ),
              createData(
                'Comfort',
                res[0].comfort,
                res[1].comfort,
                res[2].comfort,
                res[3].comfort
              ),
              createData(
                'Aesthetics',
                res[0].aesthetics,
                res[1].aesthetics,
                res[2].aesthetics,
                res[3].aesthetics
              ),
            ])
          )
      case 'Electric Scooters':
        return axios
          .get(`${url}/brand/rate/get/Electric Scooters`)
          .then((res) => res.data.brand_rate)
          .then((res) =>
            setRowss([
              createData(
                'Innovation ',
                res[0].innovation,
                res[1].innovation,
                res[2].innovation,
                res[3].innovation
              ),
              createData(
                'Releases',
                res[0].releases,
                res[1].releases,
                res[2].releases,
                res[3].releases
              ),
              createData(
                'Performance',
                res[0].perfomance,
                res[1].perfomance,
                res[2].perfomance,
                res[3].perfomance
              ),
              createData(
                'Value',
                res[0].value,
                res[1].value,
                res[2].value,
                res[3].value
              ),
              createData(
                'Range',
                res[0].range,
                res[1].range,
                res[2].range,
                res[3].range
              ),
              createData(
                'Reliability',
                res[0].reliability,
                res[1].reliability,
                res[2].reliability,
                res[3].reliability
              ),
              createData(
                'Comfort',
                res[0].comfort,
                res[1].comfort,
                res[2].comfort,
                res[3].comfort
              ),
              createData(
                'Aesthetics',
                res[0].aesthetics,
                res[1].aesthetics,
                res[2].aesthetics,
                res[3].aesthetics
              ),
            ])
          )
      case 'Electric Skateboard':
        return axios
          .get(`${url}/brand/rate/get/Electric Skateboard`)
          .then((res) => res.data.brand_rate)
          .then((res) =>
            setRowss([
              createData(
                'Innovation ',
                res[0].innovation,
                res[1].innovation,
                res[2].innovation,
                res[3].innovation
              ),
              createData(
                'Releases',
                res[0].releases,
                res[1].releases,
                res[2].releases,
                res[3].releases
              ),
              createData(
                'Performance',
                res[0].perfomance,
                res[1].perfomance,
                res[2].perfomance,
                res[3].perfomance
              ),
              createData(
                'Value',
                res[0].value,
                res[1].value,
                res[2].value,
                res[3].value
              ),
              createData(
                'Range',
                res[0].range,
                res[1].range,
                res[2].range,
                res[3].range
              ),
              createData(
                'Reliability',
                res[0].reliability,
                res[1].reliability,
                res[2].reliability,
                res[3].reliability
              ),
              createData(
                'Comfort',
                res[0].comfort,
                res[1].comfort,
                res[2].comfort,
                res[3].comfort
              ),
              createData(
                'Aesthetics',
                res[0].aesthetics,
                res[1].aesthetics,
                res[2].aesthetics,
                res[3].aesthetics
              ),
            ])
          )
    }
  }

  return (
    <>
      <div className="Table-Header">
        <div>
          <p className="Table-Header_title">Compare electric unicycle brands</p>
        </div>
        <div className="Table-Navigation">
          {likElements.map((elem, index) => (
            <p
              className={link === index ? 'Table-Navigation__active' : ''}
              onClick={() => handleNavigation(index, elem)}
              key={index}
            >
              {elem}
            </p>
          ))}
        </div>
      </div>
      <div
        className="Table-Navigation__container"
        sx={{ width: '100%', overflow: 'hidden' }}
      >
        {!rowss && (
          <Stack
            className="loader"
            sx={{ width: '100%', color: 'grey.500' }}
            spacing={2}
          >
            <LinearProgress color="inherit" />
          </Stack>
        )}
        <TableContainer>
          <Table stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow>
                {columns.map((column) => (
                  <TableCell
                    key={column.id}
                    align={column.align}
                    style={{ minWidth: column.minWidth, fontWeight: 'bold' }}
                  >
                    {column.label && (
                      <>
                        {column.label}
                        <IconButton>
                          <InfoLogo />
                        </IconButton>
                      </>
                    )}
                    {/* {column.label} */}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody className="Table-body">
              {rowss &&
                rowss
                  // .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((row, index) => {
                    return (
                      <TableRow
                        className="Table-row"
                        hover
                        role="checkbox"
                        tabIndex={-1}
                        key={row.code}
                        style={
                          index % 2 === 0 ? { backgroundColor: '#FDFDFF' } : {}
                        }
                      >
                        {columns.map((column, index) => {
                          const value = row[column.id]
                          return (
                            <TableCell
                              key={column.id}
                              align={column.align}
                              className="Table-column"
                            >
                              {column.format && typeof value === 'number'
                                ? column.format(value)
                                : value}
                            </TableCell>
                          )
                        })}
                      </TableRow>
                    )
                  })}
            </TableBody>
          </Table>
        </TableContainer>

        {/* <TablePagination
        rowsPerPageOptions={[10, 25, 100]}
        component="div"
        count={rows.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      /> */}
      </div>
    </>
  )
}
