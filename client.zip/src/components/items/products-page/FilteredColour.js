import React, { useState, useEffect } from 'react'
import checkboxCloseImg from './../../../assets/icons/checkboxCloseImg.png'

const FilteredColour = ({ chosenColour, onPass }) => {
  const [currCategory, setCurrCategory] = useState(chosenColour)

  useEffect(() => {
    onPass(currCategory)
    console.log(currCategory)
  }, [currCategory, onPass])

  return (
    <div className="filtered-item__box">
      <h5 className="filtered-item__title">
        <em> Colour: </em>
        {chosenColour.colour}
      </h5>
      <img
        src={checkboxCloseImg}
        alt="checkbox Close Img"
        className="checkboxCloseImg"
      />
      <input
        type="checkbox"
        id={chosenColour.id}
        checked={currCategory.isChecked}
        className="filtered-item__reset-butn"
        onChange={(event) => {
          setCurrCategory({ ...currCategory, isChecked: event.target.checked })
        }}
      />
    </div>
  )
}

export default FilteredColour
