import React, { useState, useEffect } from 'react'
import './FilteredItems.css'

const CategoryItem = ({
  category,
  onPass,
  allProcudts,
  hendelCategory,
  chosenCategories,
}) => {
  const [currCategory, setCurrCategory] = useState(category)
  useEffect(() => {
    onPass(currCategory)

    // alert(1)
    // allProcudts.push(currCategory.categoryTitle)
  }, [currCategory, onPass])

  useEffect(() => {
    setCurrCategory({ ...currCategory, isChecked: category.isChecked })
    hendelCategory()
  }, [category.isChecked])

  // console.log(category, 'PPPPPPPPP')

  // console.log(category, '00000000000000000000000000000000000000')
  // console.log(currCategory , '9999999+++++++0099999')
  // console.log(currCategory.categoryTitle , '9999999900000000000099999')
  // const result =  currCategory.filter(currCategory => currCategory.isChecked = true)

  // console.log(result);

  return (
    <li>
      <label htmlFor={category.id} className="filter-bar__item-label">
        <input
          className="filter-bar__item-input"
          type="checkbox"
          name="category"
          id={category.id}
          checked={currCategory.isChecked}
          onChange={(event) => {
            setCurrCategory({
              ...currCategory,
              isChecked: event.target.checked,
            })
          }}
        />
        <div className="filter-bar__checkbox" />
        <p>
          {category.categoryTitle}
          <span className="filter-bar__quantity">
            {`(${category.quantity})`}
          </span>
        </p>
      </label>
    </li>
  )
}

export default CategoryItem
