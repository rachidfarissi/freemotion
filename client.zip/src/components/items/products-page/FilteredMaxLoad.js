import React, { useState, useEffect } from 'react'
import checkboxCloseImg from './../../../assets/icons/checkboxCloseImg.png'

const FilteredMaxLoad = ({ chosenMaxLoad, onPass }) => {
  const [currCategory, setCurrCategory] = useState(chosenMaxLoad)

  useEffect(() => {
    onPass(currCategory)
  }, [currCategory, onPass])

  return (
    <div className="filtered-item__box">
      <h5 className="filtered-item__title">
        <em> Max Load: </em>
        {chosenMaxLoad.loadNum + chosenMaxLoad.loadWeight}
      </h5>
      <img
        src={checkboxCloseImg}
        alt="checkbox Close Img"
        className="checkboxCloseImg"
      />
      <input
        type="checkbox"
        id={chosenMaxLoad.id}
        checked={currCategory.isChecked}
        className="filtered-item__reset-butn"
        onChange={(event) => {
          setCurrCategory({ ...currCategory, isChecked: event.target.checked })
        }}
      />
    </div>
  )
}

export default FilteredMaxLoad
