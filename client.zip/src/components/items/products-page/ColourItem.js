import React, { useState, useEffect } from 'react'
import './FilteredItems.css'

const ColourItem = ({ colour, index, onPass, hendelCategory }) => {
  const [currColour, setCurrColour] = useState(colour)

  useEffect(() => {
    onPass(currColour)
  }, [currColour, onPass])

  useEffect(() => {
    setCurrColour({ ...currColour, isChecked: colour.isChecked })
    hendelCategory()
  }, [colour.isChecked])

  const textClassName =
    index === 0
      ? 'black'
      : index === 1
      ? 'white'
      : index === 2
      ? 'red-and-black'
      : 'white-and-black'

  return (
    <li>
      <label htmlFor={colour.id} className="filter-bar__item-label">
        <input
          className="filter-bar__item-input"
          type="checkbox"
          name="colour"
          id={colour.id}
          checked={currColour.isChecked}
          onChange={(event) =>
            setCurrColour({ ...currColour, isChecked: event.target.checked })
          }
        />
        <div className="filter-bar__checkbox" />
        <p
          className={`filter-bar__colourText filter-bar__colourText-${textClassName}`}
        >
          {(index === 2 || index === 3) && <i className="circle" />}
          {colour.colour}
        </p>
      </label>
    </li>
  )
}

export default ColourItem
