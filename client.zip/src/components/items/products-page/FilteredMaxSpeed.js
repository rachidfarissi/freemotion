import React, { useState, useEffect } from 'react'
import checkboxCloseImg from './../../../assets/icons/checkboxCloseImg.png'

const FilteredMaxSpeed = ({ chosenMaxSpeed, onPass }) => {
  const [currCategory, setCurrCategory] = useState(chosenMaxSpeed)

  useEffect(() => {
    onPass(currCategory)
    console.log(currCategory)
  }, [currCategory, onPass])

  return (
    <div className="filtered-item__box">
      <h5 className="filtered-item__title">
        <em> Max Speed: </em>
        {chosenMaxSpeed.speedNum + chosenMaxSpeed.speed}
      </h5>
      <img
        src={checkboxCloseImg}
        alt="checkbox Close Img"
        className="checkboxCloseImg"
      />
      <input
        type="checkbox"
        id={chosenMaxSpeed.id}
        checked={currCategory.isChecked}
        className="filtered-item__reset-butn"
        onChange={(event) => {
          setCurrCategory({ ...currCategory, isChecked: event.target.checked })
        }}
      />
    </div>
  )
}

export default FilteredMaxSpeed
