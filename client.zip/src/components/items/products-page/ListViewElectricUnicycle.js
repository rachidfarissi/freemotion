import React, { useState, useContext } from 'react';
import './ListViewElectricUnicycle.css';
import { homeMainIcons, homeMainImages, productsMainImages } from '../../../dummy-datas/images';
import AddToCart from '../../UI/actions/addToCart/AddToCart';
import AddToCompare from '../../UI/actions/addToCompare/AddToCompare';
import AddToFavourite from '../../UI/actions/addToFavourite/AddToFavourite';
import { PassingSingleProduct } from '../../contexts/SingleProductContext';
import { useHistory } from 'react-router';


const ListViewElectricUnicycle = ({ unicycle, index }) => {
    const { parameters } = unicycle;

    const [allParametersAreShown, setParametersAreShown] = useState(false);

    const ad_image = (index === 0) ? (
        <img 
            src={ homeMainImages.bestSellerImage } 
            alt="best seller" 
            className="list-view__ad-image"
        />
    ) : (index === 1) ? (
        <img 
            src={ productsMainImages.newLabel } 
            alt="best seller" 
            className="list-view__ad-image"
        />
    ) : null;

    const singleProductCtx = useContext(PassingSingleProduct);

    const history = useHistory();

    const redirectPageHandler = (unicycle) => {
        singleProductCtx.passSingleProduct(unicycle);
        history.push('/single-product');
    };

    return (
        <div 
            className="list-view__electric-unicycle"
            onClick={ redirectPageHandler.bind(null, unicycle) }
        >
            { ad_image }
            <div className="list-view__unicycle-image">
                <img src={ unicycle.image } alt="unicycle" />
            </div>
            <div className="electric-unicycle__main-info">
                <div className="electric-unicycle__des-and-rate list-view__des-and-rate">
                    <h5 className="electric-unicycle__description"> { unicycle.description } </h5>
                    <div className="electric-unicycle__rating-box">
                        <ul className="electric-unicycle__rating-list">
                            <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                            <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                            <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                            <li> <img src={ homeMainIcons.starOrangePeaceOfBgIcon } alt="star" /> </li>
                            <li> <img src={ homeMainIcons.starOrangeBorderIcon } alt="star" /> </li>
                        </ul>
                        <span className="electric-unicycle__rating"> 4/5 </span>
                    </div>
                </div>
                <div className="electric-unicycle__price-info">
                    <p className="electric-unicycle__new-price"> { unicycle.newPrice } </p>
                    <p className="electric-unicycle__old-price">
                        { unicycle.oldPrice }
                        <span className="electric-unicycle__discount"> { unicycle.discount } </span> 
                    </p>
                </div>
                <div className="electric-unicycle__actions">
                    <AddToCart />
                    <AddToCompare />
                    <AddToFavourite />
                </div>
            </div>
            <div className="electric-unicycle__extra-info">
                <h6 className="ad-box__info"> SKU: { unicycle.SKU } </h6>
                <div className="extra-info__box">
                    <ul className="extra-info__list">
                        <li> <p> Model: </p> <span> { parameters.model } </span> </li>
                        <li> <p> Color: </p> <span> { parameters.color } </span> </li>
                        <li> <p> Wheel Size: </p> <span> { parameters.wheelSize } </span> </li>
                        <li> <p> Max Range: </p> <span> { parameters.maxRange } </span> </li>
                        <li> <p> Battery: </p> <span> { parameters.battery } </span> </li>
                        <li> <p> Motor Type: </p> <span> { parameters.motorType } </span> </li>
                        {
                            allParametersAreShown && (
                                <>
                                    <li> <p> Weight: </p> <span> { parameters.weight } </span> </li>
                                    <li> <p> Max Climb Angle: </p> <span> { parameters.maxClimbAngle } </span> </li>
                                    <li> <p> Max Speed: </p> <span> { parameters.maxSpeed } </span> </li>
                                    <li> <p> Max Load: </p> <span> { parameters.maxLoad } </span> </li>
                                </>
                            )
                        }
                    </ul>
                </div>
                <button
                    type="button"
                    className="extra-info__butn"
                    onClick={ () => setParametersAreShown((prevState) => !prevState) }
                >
                    { allParametersAreShown ? "hide" : "see all" }
                </button>
            </div>
        </div>
    );
};

export default ListViewElectricUnicycle;
