import React, { useState, useEffect } from 'react'
import './FilteredItems.css'

const MaxSpeedItem = ({ maxSpeed, onPass, hendelCategory }) => {
  const [currMaxSpeed, setCurrMaxSpeed] = useState(maxSpeed)

  useEffect(() => {
    onPass(currMaxSpeed)
  }, [currMaxSpeed, onPass])

  useEffect(() => {
    setCurrMaxSpeed({ ...currMaxSpeed, isChecked: maxSpeed.isChecked })
    hendelCategory()
  }, [maxSpeed.isChecked])

  return (
    <li>
      <label htmlFor={maxSpeed.id} className="filter-bar__item-label">
        <input
          className="filter-bar__item-input"
          type="checkbox"
          name="max_speed"
          id={maxSpeed.id}
          checked={currMaxSpeed.isChecked}
          onChange={(event) =>
            setCurrMaxSpeed({
              ...currMaxSpeed,
              isChecked: event.target.checked,
            })
          }
        />
        <div className="filter-bar__checkbox" />
        {`${maxSpeed.speedNum} ${maxSpeed.speed}`}
      </label>
    </li>
  )
}

export default MaxSpeedItem
