import React, { useState, useEffect } from 'react'
import './FilteredItems.css'

const MaxLoadItem = ({ maxLoad, onPass, hendelCategory }) => {
  const [currMaxLoad, setCurrMaxLoad] = useState(maxLoad)

  useEffect(() => {
    onPass(currMaxLoad)
  }, [currMaxLoad, onPass])

  useEffect(() => {
    setCurrMaxLoad({ ...currMaxLoad, isChecked: maxLoad.isChecked })
    hendelCategory()
  }, [maxLoad.isChecked])

  return (
    <li>
      <label htmlFor={maxLoad.id} className="filter-bar__item-label">
        <input
          className="filter-bar__item-input"
          type="checkbox"
          name="max_load"
          id={maxLoad.id}
          checked={currMaxLoad.isChecked}
          onChange={(event) =>
            setCurrMaxLoad({ ...currMaxLoad, isChecked: event.target.checked })
          }
        />
        <div className="filter-bar__checkbox" />
        {`${maxLoad.loadNum} (${maxLoad.loadWeight})`}
      </label>
    </li>
  )
}

export default MaxLoadItem
