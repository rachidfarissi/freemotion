import React, { useContext } from 'react'
import { useHistory } from 'react-router'
import {
  homeMainImages,
  homeMainIcons,
  productsMainImages,
} from '../../../../dummy-datas/images'
import { PassingSingleProduct } from '../../../contexts/SingleProductContext'
import AddToCart from '../../../UI/actions/addToCart/AddToCart'
import AddToCompare from '../../../UI/actions/addToCompare/AddToCompare'
import AddToFavourite from '../../../UI/actions/addToFavourite/AddToFavourite'
import './GalleryViewElectricUnicycle.scss'

const GalleryViewElectricUnicycle = ({ unicycle, index, chosenViewOption }) => {
  let url = 'https://freemotion-shop-back.herokuapp.com'
  console.log(unicycle, 'wwww')
  const ad_box =
    index === 0 ? (
      <div className="ad-box">
        <img src={homeMainImages.bestSellerImage} alt="best seller" />
        <h6 className="ad-box__info"> SKU: {unicycle?.SKU} </h6>
      </div>
    ) : index === 1 ? (
      <div className="ad-box">
        <img src={productsMainImages.newLabel} alt="new" />
        <h6 className="ad-box__info"> SKU: {unicycle?.SKU} </h6>
      </div>
    ) : (
      <h6 className="ad-box__info ad-box__info-margin">
        {' '}
        SKU: {unicycle?.SKU}{' '}
      </h6>
    )

  const singleProductCtx = useContext(PassingSingleProduct)

  const history = useHistory()

  const redirectPageHandler = (unicycle) => {
    //  singleProductCtx.passSingleProduct(unicycle);
    // console.log(unicycle, 'wwww')
    history.push('/single-product/' + unicycle._id)
  }

  const stars = []
  const emptyStars = []

  for (let i = 0; i < unicycle?.rate; i++) {
    stars.push(i)
  }

  for (let i = 0; i < 5 - unicycle?.rate; i++) {
    emptyStars.push(i)
  }

  //   console.log(stars, 'stars')
  //   console.log(emptyStars, 'starsE')

  //     console.log(unicycle._id, 'dsadasd')
  // }
  return (
    <article
      // className="gallery-view__electric-unicycle"
      className="gallery-view__electric-unicycle"
      onClick={redirectPageHandler.bind(null, unicycle)}
    >
      {ad_box}
      <div className="gallery-view--state">
        <div className="electric-unicycle__image">
          <img src={`${url}/${unicycle?.img}`} alt="unicycle" />
        </div>
        <div className="gallery-view--state-content">
          <div className="electric-unicycle__des-and-rate">
            <h5 className="electric-unicycle__description">
              {' '}
              {unicycle?.title}{' '}
            </h5>
            <div className="electric-unicycle__rating-box">
              <ul className="electric-unicycle__rating-list">
                {/* <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                                <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                                <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                                <li> <img src={ homeMainIcons.starOrangePeaceOfBgIcon } alt="star" /> </li>
                                <li> <img src={ homeMainIcons.starOrangeBorderIcon } alt="star" /> </li> */}
                {stars.map((star, index) => (
                  <li key={index}>
                    <img src={homeMainIcons.starOrangeBgIcon} alt="star" />
                  </li>
                ))}
                {emptyStars.map((emptyStar, index) => (
                  <li key={index}>
                    <img
                      src={homeMainIcons.starOrangeBorderIcon}
                      alt="star empty"
                    />
                  </li>
                ))}
              </ul>
              <span className="electric-unicycle__rating">
                {' '}
                {unicycle?.rate} / 5{' '}
              </span>
            </div>
          </div>
          <div className="electric-unicycle__price-info">
            <div className="new-price-box">
              <span className="new-price-box__currency"> C$ </span>
              <p className="electric-unicycle__new-price">
                {' '}
                {unicycle?.price}{' '}
              </p>
            </div>
            <div className="old-price-box">
              <span className="old-price-box__currency"> C$ </span>
              <p className="electric-unicycle__old-price">
                {unicycle?.discounted_price}
                <span className="electric-unicycle__discount">
                  {' '}
                  {Math.floor(
                    100 - (unicycle?.discounted_price / unicycle?.price) * 100
                  )}{' '}
                  %{' '}
                </span>
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="electric-unicycle__actions">
        <AddToCart />
        <AddToCompare />
        <AddToFavourite />
      </div>
    </article>
  )
}

export default GalleryViewElectricUnicycle
