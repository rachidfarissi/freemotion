import React, { useState, useEffect } from 'react'
import './FilteredItems.css'

const BrandItem = ({ brand, onPass, hendelCategory }) => {
  const [currBrand, setCurrBrand] = useState(brand)

  useEffect(() => {
    onPass(currBrand)
  }, [currBrand, onPass])

  useEffect(() => {
    setCurrBrand({ ...currBrand, isChecked: brand.isChecked })
    hendelCategory()
  }, [brand.isChecked])

  return (
    <li>
      <label htmlFor={brand.id} className="filter-bar__item-label">
        <input
          className="filter-bar__item-input"
          type="checkbox"
          name="category"
          id={brand.id}
          checked={currBrand.isChecked}
          onChange={(event) =>
            setCurrBrand({ ...currBrand, isChecked: event.target.checked })
          }
        />
        <div className="filter-bar__checkbox" />
        <p>
          {brand.brandTitle}
          <span className="filter-bar__quantity">{`(${brand.quantity})`}</span>
        </p>
      </label>
    </li>
  )
}

export default BrandItem
