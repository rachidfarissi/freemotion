import React, { useState, useEffect } from 'react'
import './FilteredItem.css'
import checkboxCloseImg from './../../../assets/icons/checkboxCloseImg.png'

const FilteredCategory = ({ chosenCategory, onPass }) => {
  const [currCategory, setCurrCategory] = useState(chosenCategory)

  useEffect(() => {
    onPass(currCategory)
  }, [currCategory, onPass])

  return (
    <div className="filtered-item__box">
      <h5 className="filtered-item__title"> {chosenCategory.categoryTitle} </h5>
      <img
        src={checkboxCloseImg}
        alt="checkbox Close Img"
        className="checkboxCloseImg"
      />
      <input
        type="checkbox"
        id={chosenCategory.id}
        checked={currCategory.isChecked}
        className="filtered-item__reset-butn"
        onChange={(event) => {
          setCurrCategory({ ...currCategory, isChecked: event.target.checked })
        }}
      />
    </div>
  )
}

export default FilteredCategory
