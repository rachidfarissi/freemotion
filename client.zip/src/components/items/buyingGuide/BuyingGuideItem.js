import React, {useState} from 'react';
import './buyingGuideItem.scss'
import icCost from './../../../assets/icons/support/ic_cost.png'
 
const BuyingGuideItem = ({ title, text , description}) => {

    const [buyingGuideItem, setBuyingGuideItem] = useState(false);


    return(
        <article className='buyingGuide__item'  onClick={ () => setBuyingGuideItem((prevState) => !prevState) }>
           <img  className='buyingGuide__item-logo' src={icCost} alt='card logo'/>
           <div  className='buyingGuide__item-box'>
                <h2 className='buyingGuide__item-title'>{ title }</h2>
                <p className='buyingGuide__item-text'>{ text }</p>
                {
                    (buyingGuideItem) && (
                        <p className='buyingGuide__item-description'>{description}</p>
                    )
                }
               </div>
        </article>
    )
}

export default BuyingGuideItem;