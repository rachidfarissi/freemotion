import React from 'react'
import { useHistory } from 'react-router-dom'
import './blog.scss'

function BlogItem({ el }) {
  const history = useHistory()
  function singleBlogNavigate() {
    history.push('/single-blog/' + 1)
  }

  let url = 'http://147.182.155.217:8372'
  return (
    <article onClick={singleBlogNavigate} className="blogItem">
      <img src={`${url}/${el.img}`} alt="blog img" className="blogItem__img" />
      <div className="blogItem__content">
        <p className="blogItem__read">{`${el.read_time} min read`}</p>
        <p className="blogItem__status">{el.brand}</p>
        <h2 className="blogItem__name">{el.min_description}</h2>
      </div>
    </article>
  )
}

export default BlogItem
