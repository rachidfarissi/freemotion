import React from 'react';
import './warrantyRegistration.scss'
// import icCost from './../../../assets/icons/support/ic_cost.png'
 
const BuyingGuideItem = ({ title, text}) => {

    return(
        <article className='buyingGuide__item'>
           {/* <img  className='buyingGuide__item-logo' src={icCost} alt='card logo'/> */}
            <div  className='buyingGuide__item-box'>
               <h2 className='buyingGuide__item-title'>{ title }</h2>
               <p className='buyingGuide__item-text'>{ text }</p>
            </div>
        </article>
    )
}

export default BuyingGuideItem;