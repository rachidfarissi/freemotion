import React from 'react'
import './ExclusiveRangeOfProducts.css'
import { useHistory } from 'react-router'

const ExclusiveRangeOfProducts = ({ product }) => {
  const history = useHistory()
  return (
    <div
      className="exclusive-products"
      onClick={() => history.push('/products')}
    >
      <h3 className="exclusive-products__title"> {product.title} </h3>
      <div className="exclusive-products__image">
        <img src={product.image} alt="exclusive product" />
      </div>
    </div>
  )
}

export default ExclusiveRangeOfProducts
