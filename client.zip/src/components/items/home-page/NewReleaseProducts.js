import React from 'react'
import BuyNowButton from '../../UI/buttons/BuyNowButton'
import './NewReleaseProducts.css'
import { homeMainIcons } from '../../../dummy-datas/images'
import { useHistory } from 'react-router'

const NewReleaseProducts = ({ product }) => {
  console.log(product, 'www')
  const history = useHistory()
  let url = 'https://freemotion-shop-back.herokuapp.com'

  const stars = []
  const emptyStars = []

  for (let i = 0; i < product.rate; i++) {
    stars.push(i)
  }

  for (let i = 0; i < 5 - product.rate; i++) {
    emptyStars.push(i)
  }

  console.log(stars, 'stars')
  console.log(emptyStars, 'starsE')

  function singleProductHandler() {
    history.push(`/single-product/${product._id}`)
  }

  return (
    <div className="new-release-product__container">
      <div className="new-release-product__image">
        <img
          onClick={singleProductHandler}
          src={`${url}/${product.img}`}
          alt="new release product"
        />
      </div>
      <div className="new-release-product__info">
        <div className="product-info__rating-box">
          <span className="product-info__rating new-release-product__rating">
            {' '}
            {product.rate}/5{' '}
          </span>
          <ul className="product-info__rating-list new-release-product__rating-list">
            {stars.map((star) => (
              <li>
                <img src={homeMainIcons.starOrangeBgIcon} alt="star" />
              </li>
            ))}
            {emptyStars.map((emptyStar) => (
              <li>
                <img
                  src={homeMainIcons.starOrangeBorderIcon}
                  alt="star empty"
                />
              </li>
            ))}

            {/* <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                        <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                        <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                        <li> <img src={ homeMainIcons.starOrangePeaceOfBgIcon } alt="star" /> </li>
                        <li> <img src={ homeMainIcons.starOrangeBorderIcon } alt="star" /> </li> */}
          </ul>
        </div>
        <h4 className="new-release-product__description"> {product.title} </h4>
        <div className="new-release-product__action-box">
          <div className="new-release-product__price-info">
            {product.price && (
              <p className="product-info__old-price old-price-color old-price-rotate">
                {' '}
                $ {product.price}{' '}
              </p>
            )}
            <p className="product-info__new-price new-price-color">
              {' '}
              $ {product.discounted_price}{' '}
            </p>
          </div>
          <BuyNowButton
            singleProductHandler={singleProductHandler}
            favourIcon={homeMainIcons.heartBlackBorderIcon}
            checkedFavourIcon={homeMainIcons.heartRedBgIcon}
            uncheckedFavourIcon={homeMainIcons.heartRedBorderIcon}
            arrowIcon={homeMainIcons.rightRedArrowIcon}
            className={'best-sellers__buy-now-btn'}
            checkboxId={`favour-black-${product.id}`}
          />
        </div>
      </div>
    </div>
  )
}

export default NewReleaseProducts
