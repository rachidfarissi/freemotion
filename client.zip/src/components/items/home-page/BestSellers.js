import React from 'react'
import './BestSellers.css'
import { homeMainIcons, homeMainImages } from '../../../dummy-datas/images'
import BuyNowButton from '../../UI/buttons/BuyNowButton'
import { useHistory } from 'react-router'

const BestSellers = ({ product }) => {
  console.log(product, '000000000000+++++++++++++++0000000000000')

  const stars = []
  const emptyStars = []
  const history = useHistory()

  for (let i = 0; i < product.rating; i++) {
    stars.push(i)
  }

  for (let i = 0; i < 5 - product.rating; i++) {
    emptyStars.push(i)
  }

  const singlePageHandler = () => history.push(`/single-product/${product.id}`)
  console.log(stars, 'stars')
  console.log(emptyStars, 'starsE')

  return (
    <div className="best-sellers__container">
      <div className="best-seller__image">
        <img src={homeMainImages.bestSellerImage} alt="best seller" />
      </div>
      <div className="best-sellers__info">
        <div className="info__image " onClick={singlePageHandler}>
          <img src={product.image} alt="product" />
        </div>
        <div className="info__details">
          <h4
            onClick={singlePageHandler}
            className="product-info__description description-color"
          >
            {product.description}
          </h4>
          <div className="product-info__rating-box">
            <span className="product-info__rating"> {product.rating}/5 </span>
            <ul className="product-info__rating-list">
              {stars.map((star) => (
                <li>
                  <img src={homeMainIcons.starOrangeBgIcon} alt="star" />
                </li>
              ))}
              {emptyStars.map((emptyStar) => (
                <li>
                  <img
                    src={homeMainIcons.starOrangeBorderIcon}
                    alt="star empty"
                  />
                </li>
              ))}
              {/* <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                            <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                            <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                            <li> <img src={ homeMainIcons.starOrangePeaceOfBgIcon } alt="star" /> </li>
                            <li> <img src={ homeMainIcons.starOrangeBorderIcon } alt="star" /> </li> */}
            </ul>
          </div>
          <p className="product-info__old-price old-price-color">
            {' '}
            {product.oldPrice}{' '}
          </p>
          <p className="product-info__new-price new-price-color">
            {' '}
            {product.newPrice}{' '}
          </p>
          <div onClick={singlePageHandler}>
            <BuyNowButton
              favourIcon={homeMainIcons.heartBlackBorderIcon}
              checkedFavourIcon={homeMainIcons.heartRedBgIcon}
              uncheckedFavourIcon={homeMainIcons.heartRedBorderIcon}
              arrowIcon={homeMainIcons.rightRedArrowIcon}
              className={'best-sellers__buy-now-btn'}
              checkboxId={`favour-black-${product.id}`}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default BestSellers
