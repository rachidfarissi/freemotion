import React from 'react';
import './ProductReview.css';
import moment from 'moment'
import { homeMainIcons } from '../../../dummy-datas/images';


const ProductReview = ({ productReview }) => {
    let url = 'https://freemotion-shop-back.herokuapp.com'


    const { product } = productReview;
    console.log(product , '***3333333333***')
    console.log(productReview , '***3333333333***')


    const stars = []
    const emptyStars = []
    
    for (let i = 0; i < productReview.rate; i++){
        stars.push(i)
    }

    for (let i = 0; i < (5 - productReview.rate); i++){
        emptyStars.push(i)
    }

    console.log(stars, 'stars')
    console.log(emptyStars, 'starsE')

    return (
        <div className="reviews-details__container">
            <div className="product-review__product-info">
                <div className="product-review__product-image">
                    {/* <img src={`${url}/${productReview.product[0].img}`} alt="product" loading='laze'/> */}
                </div>
                {/* <h6>TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT</h6> */}
                <h6 className="product-review__product-description"> { productReview.title } </h6>
            </div>
            <div className="product-review__product-rating">
                <h4 className="product-review__product-title">{ productReview.name } </h4>
                <div className="product-review__rating-review">
                    <p className="product-review__review-text">{ productReview.rate } / 5</p>
                    <ul className="product-info__rating-list reviews-details__rating-list">
                        {
                            stars.map(star => <li><img src={ homeMainIcons.starOrangeBgIcon } alt="star" /></li>)
                        }
                        {
                            emptyStars.map( emptyStar => <li><img src={ homeMainIcons.starOrangeBorderIcon } alt="star empty" /></li>)
                        }
                        {/* <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                        <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                        <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                        <li> <img src={ homeMainIcons.starOrangePeaceOfBgIcon } alt="star" /> </li>
                        <li> <img src={ homeMainIcons.starOrangeBorderIcon } alt="star" /> </li> */}
                    </ul>
                    <span className="product-review__review-date"> { moment(productReview.createdAt ).format('LL')} </span>
                </div>
            </div>
            <div className="product-review__pros-cons">
                <p> Pros: <span> { productReview.pros } </span> </p>
                <p> Cons: <span> { productReview.cons } </span> </p>
            </div>
            <p className="product-review__review-text">{ productReview.review }</p>
            <h5 className="product-review__verified-purchase"> Verified purchase </h5>
        </div>
    );
};

export default ProductReview;
