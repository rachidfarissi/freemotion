import React from 'react';
import { useHistory } from 'react-router';
import './DiscountedProducts.css';


const DiscountedProducts = ({ product, index }) => {
    let url = 'https://freemotion-shop-back.herokuapp.com'
    const containerClassName = (index === 1) ? "different" : "similar";

    console.log(product, 'wwwww');
    const history = useHistory()

    function handleSubmit(product) {
        history.push('single-product/' + product._id)
    }

    return (
        <div className={ `product-info ${containerClassName}` }>
            <img src={`${url}/${product.img}`} alt="discounted product" />
            <div className="product-info__content">
                <h6 className="product-info__name"> { product.name } </h6>
                <h4 className="product-info__description"> { product.title } </h4>
                <p className="product-info__old-price">{ product.discounted_price } </p>
                <p className="product-info__new-price"> { product.price } </p>
                <button
                    className="product-info__buy-now-btn"
                    type="button"
                    onClick={() => handleSubmit(product)}
                >  
                    Buy now
                </button>
            </div>
        </div>
    )
};

export default DiscountedProducts;
