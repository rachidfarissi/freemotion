import React from 'react'
import './BlogItem.scss'
import { useHistory } from 'react-router-dom'

const BlogItem = ({ blog }) => {
  const history = useHistory()

  const singleBlog = () => history.push('/blog')
  return (
    <div className="blog-item__container" onClick={singleBlog}>
      <div className="blog-item__container-box">
        <img src={blog.image} alt="blog" />
        <div className="blog-item__title-bg">
          <h4 className="blog-item__title"> {blog.title} </h4>
        </div>
      </div>
      <div className="blog-item__container-textBox">
        <h5 className="blog-item__date"> {blog.date} </h5>
        <p className="blog-item__text"> {blog.text} </p>
      </div>
    </div>
  )
}

export default BlogItem
