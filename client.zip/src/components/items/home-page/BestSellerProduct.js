import React from 'react'
import './BestSellerProduct.css'
import { homeMainIcons } from '../../../dummy-datas/images'
import BuyNowButton from '../../UI/buttons/BuyNowButton'
import StarOpacity from './../../../assets/icons/StarOpacity.png'
import StarBorder from './../../../assets/icons/StarBorder.png'
import { useHistory } from 'react-router'

const BestSellerProduct = ({ product }) => {
  const stars = []
  const emptyStars = []
  const history = useHistory()

  for (let i = 0; i < 4; i++) {
    stars.push(i)
  }

  for (let i = 0; i < 5 - 4; i++) {
    emptyStars.push(i)
  }

  console.log(stars, 'stars')
  console.log(emptyStars, 'starsE')

  const singlePageHandler = () => history.push(`/single-product/${product.id}`)

  return (
    <div className="best-seller__product">
      <img src={product.image} alt="best seller product" />
      <div className="best-seller__product-info">
        <h6 onClick={singlePageHandler} className="product-info__name">
          {product.title}
        </h6>
        <h4 onClick={singlePageHandler} className="product-info__description">
          {product.description}
        </h4>
        <ul className="product-info__rating-list-general">
          {/* <img src={ StarOpacity } alt="star" /> */}
          {stars.map((star, index) => (
            <li key={index}>
              <img src={StarOpacity} alt="star" />
            </li>
          ))}
          {emptyStars.map((emptyStar, index) => (
            <li key={index}>
              <img src={StarBorder} alt="star empty" />
            </li>
          ))}
          {/* <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                    <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                    <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                    <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                    <li> <img src={ homeMainIcons.starOrangeBorderIcon } alt="star" /> </li> */}
        </ul>
        <p className="product-info__old-price"> {product.oldPrice} </p>
        <p className="product-info__new-price"> {product.newPrice} </p>
        <ul className="product-info__details-list">
          <li> {product.speedInfo} </li>
          <li> {product.batteryInfo} </li>
          <li> {product.motorInfo} </li>
        </ul>
        <div onClick={singlePageHandler}>
          <BuyNowButton
            favourIcon={homeMainIcons.heartWhiteBorderIcon}
            checkedFavourIcon={homeMainIcons.heartRedBgIcon}
            uncheckedFavourIcon={homeMainIcons.heartRedBorderIcon}
            arrowIcon={homeMainIcons.rightWhiteArrowIcon}
            className="best-seller__buy-now-btn"
            checkboxId="favour-white"
          />
        </div>
      </div>
    </div>
  )
}

export default BestSellerProduct
