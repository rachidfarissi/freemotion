import React from 'react';
import './Unicycles.css';
import { E_UNICYCLES } from '../../../dummy-datas/dummyDatas';


const Unicycles = () => {
    return (
        <React.Fragment>
            {
                E_UNICYCLES.map(unicycle => {
                    return (
                        <div key={ unicycle.id } className="unicycle">
                            <div className="unicycle__info">
                                <div className="unicycle__image">
                                    <img src={ unicycle.image } alt="e-unicycle" />
                                </div>
                                <h6 className="unicycle__description"> 
                                    { unicycle.description }
                                </h6>
                            </div>
                            <div className="unicycle__price-info">
                                <div className={ `old-price-box ${ (!unicycle.oldPrice) && "hidden" }` }>
                                    <span className="old-price-box__currency"> C$ </span>
                                    <p className="electric-unicycle__old-price"> 
                                        { unicycle.oldPrice } 
                                    </p>
                                </div>
                                <div className="new-price-box">
                                    <span className="new-price-box__currency"> C$ </span>
                                    <p className="electric-unicycle__new-price"> { unicycle.newPrice } </p>
                                </div>
                            </div>
                        </div>
                    );
                })
            }
        </React.Fragment>
    );
};

export default Unicycles;
