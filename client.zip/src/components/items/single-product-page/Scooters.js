import React from 'react';
import './Scooters.css';
import { E_SCOOTERS } from '../../../dummy-datas/dummyDatas';


const Scooters = () => {
    return (
        <React.Fragment>
            {
                E_SCOOTERS.map(scooter => {
                    return (
                        <div key={ scooter.id } className="unicycle">
                            <div className="unicycle__box">
                                <div className="unicycle__info">
                                    <div className="unicycle__image">
                                        <img src={ scooter.image } alt="e-unicycle" />
                                    </div>
                                    <h6 className="unicycle__description"> 
                                        { scooter.description }
                                    </h6>
                                </div>
                            </div>
                            <div className="unicycle__price-info">
                                <div className={ `old-price-box ${ (!scooter.oldPrice) && "hidden" }` }>
                                    <span className="old-price-box__currency"> C$ </span>
                                    <p className="electric-unicycle__old-price"> 
                                        { scooter.oldPrice } 
                                    </p>
                                </div>
                                <div className="new-price-box">
                                    <span className="new-price-box__currency"> C$ </span>
                                    <p className="electric-unicycle__new-price"> { scooter.newPrice } </p>
                                </div>
                            </div>
                        </div>
                    );
                })
            }
        </React.Fragment>
    );
};

export default Scooters;
