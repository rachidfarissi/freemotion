import React from 'react';
import './Skateboards.css';
import { E_SKATEBOARDS } from '../../../dummy-datas/dummyDatas';


const Skateboards = () => {
    return (
        <React.Fragment>
            {
                E_SKATEBOARDS.map(skateboard => {
                    return (
                        <div key={ skateboard.id } className="unicycle">
                            <div className="unicycle__box">
                                <div className="unicycle__info">
                                    <div className="unicycle__image">
                                        <img src={ skateboard.image } alt="e-skateboard" />
                                    </div>
                                    <h6 className="unicycle__description"> 
                                        { skateboard.description }
                                    </h6>
                                </div>
                            </div>
                            <div className="unicycle__price-info">
                                <div className={ `old-price-box ${ (!skateboard.oldPrice) && "hidden" }` }>
                                    <span className="old-price-box__currency"> C$ </span>
                                    <p className="electric-unicycle__old-price"> 
                                        { skateboard.oldPrice } 
                                    </p>
                                </div>
                                <div className="new-price-box">
                                    <span className="new-price-box__currency"> C$ </span>
                                    <p className="electric-unicycle__new-price"> { skateboard.newPrice } </p>
                                </div>
                            </div>
                        </div>
                    );
                })
            }
        </React.Fragment>
    );
};

export default Skateboards;
