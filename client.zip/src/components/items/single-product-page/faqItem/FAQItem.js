import React, { useState } from 'react';
import { singleProductImages } from '../../../../dummy-datas/images';
import './FAQItem.scss';


const FAQItem = ({ faq }) => {
    const [faqDropdownIsShown, setFaqDropdownIsShown] = useState(false);

    const plus_icon = <img src={ singleProductImages.plus_icon } alt="plus" />;
    const minus_icon = <img src={ singleProductImages.minus_icon } alt="plus" />;
    const inner_text = (faqDropdownIsShown) ? minus_icon : plus_icon;
    const title_class_name = `show-dropdown__title ${ (faqDropdownIsShown) && "shown" }`

    return (
        <div className="faq__item">
            <div className="faq__show-dropdown">
                <h6 className={ title_class_name }> { faq?.questions } </h6>
                <button
                    type="button"
                    className="show-dropdown__btn"
                    onClick={ () => setFaqDropdownIsShown((prevState) => !prevState) }
                >
                    { inner_text }
                </button>
            </div>
            {
                (faqDropdownIsShown) && (
                    <div className="faq__dropdown">
                        <p className="dropdown__text"> { faq.answer } </p>
                    </div>
                )
            }
        </div>
    );
};

export default FAQItem;
