import React from 'react'
import './RelatedProductItem.scss'
import { homeMainIcons } from '../../../../dummy-datas/images'
import BuyNowButton from '../../../UI/buttons/BuyNowButton'
import { useHistory } from 'react-router'

const RelatedProductItem = ({ product }) => {
  const history = useHistory()

  let url = 'https://freemotion-shop-back.herokuapp.com'

  const singlePageHandler = () => history.push(`/single-product/${product._id}`)

  return (
    <div className="related-product__item">
      <div onClick={singlePageHandler} className="related-product__image">
        <img src={`${url}/${product.img}`} alt="new release product" />
      </div>
      <div className="related-product__info">
        <h4 className="new-release-product__description"> {product.title} </h4>
        <div className="new-release-product__price-info">
          <p className="new-release-product_newPrice"> $ {product.price} </p>
          <p
            className={`new-release-product_oldPrice ${
              !product.discounted_price && 'hidden-text'
            }`}
          >
            {' '}
            $ {product.discounted_price}{' '}
          </p>
        </div>
        <div className="new-release-product__action-box related-product__action-box">
          <div onClick={singlePageHandler}>
            <BuyNowButton
              favourIcon={homeMainIcons.heartBlackBorderIcon}
              checkedFavourIcon={homeMainIcons.heartRedBgIcon}
              uncheckedFavourIcon={homeMainIcons.heartRedBorderIcon}
              arrowIcon={homeMainIcons.rightRedArrowIcon}
              className={'best-sellers__buy-now-btn'}
              checkboxId={`favour-black-${product.id}`}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default RelatedProductItem
