import React from 'react';
import './VerifiedReviewItem.css';
import { homeMainIcons } from '../../../dummy-datas/images';
import moment from 'moment'


const VerifiedReviewItem = ({ verifiedReview }) => {
    // const { review } = verifiedReview;
    console.log(verifiedReview, '6666666')

    return (
        <div className="verified-review__container">
            <div className="product-review__product-rating">
                <h4 className="product-review__product-title"> { verifiedReview.name } </h4>
                <div className="verified-review__rating-review">
                    <ul className="product-info__rating-list reviews-details__rating-list">
                        <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                        <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                        <li> <img src={ homeMainIcons.starOrangeBgIcon } alt="star" /> </li>
                        <li> <img src={ homeMainIcons.starOrangePeaceOfBgIcon } alt="star" /> </li>
                        <li> <img src={ homeMainIcons.starOrangeBorderIcon } alt="star" /> </li>
                    </ul>
                    <span className="product-review__review-date"> { moment(verifiedReview.createdAt).format('LL') } </span>
                </div>
            </div>
            <div className="product-review__pros-cons">
                <p> Pros: <span> { verifiedReview.pros } </span> </p>
                <p> Cons: <span> { verifiedReview.cons } </span> </p>
            </div>
            <p className="product-review__review-text"> { verifiedReview.review } </p>
            <h5 className="product-review__verified-purchase"> Verified purchase </h5>
        </div>
    );
};

export default VerifiedReviewItem;
