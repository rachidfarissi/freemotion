import { useState, useCallback } from 'react'

export const useFilterByChecked = (datas) => {
  const [filterableDatas, setFilterableDatas] = useState(datas)

  const passAndChangeDataHandler = useCallback((data) => {
    const filterableDatasClone = [...filterableDatas]
    console.log(data, 'data')
    filterableDatasClone.forEach((filterableData) => {
      if (filterableData.id === data.id) {
        filterableData.isChecked = data.isChecked
      }
    })
    setFilterableDatas(filterableDatasClone)
  }, [])

  const chosenDatas = filterableDatas.filter((data) => data.isChecked)

  return [filterableDatas, passAndChangeDataHandler, chosenDatas]
}
