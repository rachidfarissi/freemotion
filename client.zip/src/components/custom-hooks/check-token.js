export const useToken = () => !!localStorage.getItem('token')
