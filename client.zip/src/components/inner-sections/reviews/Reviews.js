import React, { useState, useEffect } from 'react'
import './Reviews.scss'
import { homeMainIcons } from '../../../dummy-datas/images'
import VerifiedReviewItem from '../../items/single-product-page/VerifiedReviewItem'
import LightButton from '../../UI/buttons/LightButton'
import CustomModal from '../../UI/custom-modal'
import WriteReview from '../../UI/actions/single-product-page/WriteReview'
import axios from 'axios'

const Reviews = ({ id, rate }) => {
  const [modalIsOpen, setModalIsOpen] = useState(false)
  const [stars, setStars] = useState([])

  const openModalHandler = () => setModalIsOpen(true)
  const closeModalHandler = () => setModalIsOpen(false)

  const [visible, setVisible] = useState(3)

  const readMore = () => {
    setVisible((prevValue) => prevValue + 3)
  }

  let url = 'https://freemotion-shop-back.herokuapp.com'

  const [data, setData] = useState([])

  useEffect(() => {
    console.log(url)
    axios
      .get(`${url}/review/product/${id}`)
      .then((res) => setData(res.data.review))
      // .then(res => console.log(res.data.faq))
      .catch((e) => console.log(e))
  }, [url, id])

  console.log(data, 'ppppp')
  console.log(id, rate)

  const [dataRate, setDataRate] = useState([])

  useEffect(() => {
    console.log(url)
    axios
      .get(`${url}/rate/get/${id}`)
      .then((res) => setDataRate(res.data.message))
      // .then(res => console.log(res.data.faq))
      .catch((e) => console.log(e))
  }, [url, id])

  // useEffect(() => {
  // function printStars(){
  //     for(let i = 0 ; i < dataRate.rate +2 ; i++){
  //         // setStars(stars.push('1'))
  //         console.log(stars.push(1) , 'LLL')
  //     }
  // }
  // })

  // printStars()
  console.log(stars.length, 'star111')

  console.log(dataRate, 'TTTTTTTT')

  // let dataRate.rate_five_procent = 80
  return (
    <React.Fragment>
      <div className="reviews" id="reviews">
        <h2 className="reviews__title"> Verified Reviews </h2>
        <div className="reviews__content">
          <div className="reviews__rating">
            <div className="reviews__content-box">
              <div className="reviews__user-review">
                <h6 className="reviews-details__text">
                  {' '}
                  {dataRate.rate__total}0 User Reviews{' '}
                </h6>
              </div>
              <div className="reviews__rating-container">
                <h3 className="reviews-details__rating-point">
                  {' '}
                  {dataRate.rate}{' '}
                </h3>
                <ul className="product-info__rating-list reviews-details__rating-list">
                  <li>
                    {' '}
                    <img src={homeMainIcons.starOrangeBgIcon} alt="star" />{' '}
                  </li>
                  <li>
                    {' '}
                    <img src={homeMainIcons.starOrangeBgIcon} alt="star" />{' '}
                  </li>
                  <li>
                    {' '}
                    <img src={homeMainIcons.starOrangeBgIcon} alt="star" />{' '}
                  </li>
                  <li>
                    {' '}
                    <img
                      src={homeMainIcons.starOrangePeaceOfBgIcon}
                      alt="star"
                    />{' '}
                  </li>
                  <li>
                    {' '}
                    <img
                      src={homeMainIcons.starOrangeBorderIcon}
                      alt="star"
                    />{' '}
                  </li>
                </ul>
              </div>
            </div>
            <div className="reviews__rating-status">
              <div className="rating-info__rating-status-item">
                <span className="rating-info__count"> 5 </span>
                <img src={homeMainIcons.starOrangeBgIcon} alt="rating star" />
                <div className="rating-info__box review__rating-info">
                  <i
                    style={{
                      width: dataRate.rate_five_procent + '%',
                      backgroundColor: `rgb(${
                        255 -
                        dataRate.rate_five_procent * 2.5 +
                        ',' +
                        dataRate.rate_five_procent * 2.5
                      }, 0)`,
                    }}
                    className="rating-info__percentage"
                  />
                </div>
                <span className="rating-info__percent">
                  {dataRate.rate_five_procent}%{' '}
                </span>
              </div>
              <div className="rating-info__rating-status-item">
                <span className="rating-info__count"> 4 </span>
                <img src={homeMainIcons.starOrangeBgIcon} alt="rating star" />
                <div className="rating-info__box">
                  <i
                    style={{
                      width: dataRate.rate_four_procent + '%',
                      backgroundColor: `rgb(${
                        255 -
                        dataRate.rate_four_procent * 2.5 +
                        ',' +
                        dataRate.rate_four_procent * 2.5
                      }, 0)`,
                    }}
                    className="rating-info__percentage"
                  />
                </div>
                <span className="rating-info__percent">
                  {' '}
                  {dataRate.rate_four_procent}%{' '}
                </span>
              </div>
              <div className="rating-info__rating-status-item">
                <span className="rating-info__count"> 3 </span>
                <img src={homeMainIcons.starOrangeBgIcon} alt="rating star" />
                <div className="rating-info__box">
                  <i
                    style={{
                      width: dataRate.rate_three_procent + '%',
                      backgroundColor: `rgb(${
                        255 -
                        dataRate.rate_three_procent * 2.5 +
                        ',' +
                        dataRate.rate_three_procent * 2.5
                      }, 0)`,
                    }}
                    className="rating-info__percentage"
                  />
                </div>
                <span className="rating-info__percent">
                  {' '}
                  {dataRate.rate_three_procent}%{' '}
                </span>
              </div>
              <div className="rating-info__rating-status-item">
                <span className="rating-info__count"> 2 </span>
                <img src={homeMainIcons.starOrangeBgIcon} alt="rating star" />
                <div className="rating-info__box">
                  <i
                    style={{
                      width: dataRate.rate_two_procent + '%',
                      backgroundColor: `rgb(${
                        255 -
                        dataRate.rate_two_procent * 2.5 +
                        ',' +
                        dataRate.rate_two_procent * 2.5
                      }, 0)`,
                    }}
                    className="rating-info__percentage"
                  />
                </div>
                <span className="rating-info__percent">
                  {' '}
                  {dataRate.rate_two_procent}%{' '}
                </span>
              </div>
              <div className="rating-info__rating-status-item">
                <span className="rating-info__count"> 1 </span>
                <img src={homeMainIcons.starOrangeBgIcon} alt="rating star" />
                <div className="rating-info__box">
                  <i
                    style={{
                      width: dataRate.rate_one_procent + '%',
                      backgroundColor: `rgb(${
                        255 -
                        dataRate.rate_one_procent * 2.5 +
                        ',' +
                        dataRate.rate_one_procent * 2.5
                      }, 0)`,
                    }}
                    className="rating-info__percentage"
                  />
                </div>
                <span className="rating-info__percent">
                  {' '}
                  {dataRate.rate_one_procent}%
                </span>
              </div>
            </div>
          </div>
        </div>

        {data.slice(0, visible).map((verifiedReview) => (
          <VerifiedReviewItem
            verifiedReview={verifiedReview}
            key={verifiedReview.id}
          />
        ))}

        <div className="reviews__actions">
          <LightButton
            className={'reviews__write-a-review-btn'}
            butnType={'button'}
            label={'Write a review'}
            onButnClick={openModalHandler}
          />
          {data.length >= 3 && (
            <button
              type="button"
              className="content__change-btn"
              onClick={readMore}
            >
              Load more
            </button>
          )}
        </div>
      </div>

      {modalIsOpen && (
        <CustomModal
          popupClassName={'write-review__popup'}
          closerClassName={'write-review__closer'}
          closeModal={closeModalHandler}
        >
          <WriteReview onClose={closeModalHandler} />
        </CustomModal>
      )}
    </React.Fragment>
  )
}

export default Reviews
