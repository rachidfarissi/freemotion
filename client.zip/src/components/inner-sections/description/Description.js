import React from 'react';
import { singleProductImages } from '../../../dummy-datas/images';
import ProductDetailsInfoCard from '../../UI/cards/ProductDetailsInfoCard';
import './Description.scss';


const Description = ({singleData}) => {

    let url = 'https://freemotion-shop-back.herokuapp.com'


    console.log(singleData)

    return (
        <div className="description" id='description'>
            <h2 className="description__title"> Description </h2>
            <div className="description__content">
                <div className="description__content-image">
                
                    {/* <img src={ singleProductImages.image_6 } alt="man on scooter" /> */}
                    <img src={ `${url}/${singleData.description_img}` } alt="man on scooter" />
                </div>
                <p className="description__content-text">
                    {singleData.short_description}
                    {/* {singleData.short_description} */}
                </p>
                {/* <p className="description__content-text">
                    The RS comes with two different types of motors: The High-speed model, built for Raw speed, and the high torque model for enhanced acceleration, climbing, and braking, useful in off-road riding. Some riders love the unicycle with more torque, allowing incredible off-road performance, or those who value acceleration over the ability to exceed 30mph. The high-speed version allows speed-loving riders to glide at over 40mph to their destination.
                </p>
                <p className="description__content-text">
                    *Keep in mind that performance can vary with load weight, road conditions, battery status, and temperature.
                </p> */}
            </div>
            <div className="clear" />
            <div className="description__product-details">
                {/* <ProductDetailsInfoCard
                    details={ "40+" }
                    title={ "Top Speed (mph)" }
                />
                <ProductDetailsInfoCard
                    details={ "325" }
                    title={ "Max Load (lbs)" }
                /> */}
                <ProductDetailsInfoCard
                    details={singleData.product_parameter.max_speed_filter}
                    title={ "Top Speed (mph)" }
                />
                <ProductDetailsInfoCard
                    details={ singleData.product_parameter.max_load_filter  }
                    title={ "Max Load (lbs)" }
                />
                <ProductDetailsInfoCard
                    details={ "100v" }
                    title={ "Battery (1800Wh)" }
                />
            </div>
        </div>
    );
};

export default Description;
