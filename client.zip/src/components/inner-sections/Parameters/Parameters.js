import React from 'react';
import './Parameters.scss';


const Parameters = ({singleData}) => {

    console.log(singleData , '********')

    return (
        <div className="parameters" id='parameters'>
            <h2 className="parameters__title"> Parameters </h2>
            <div className="extra-info__box parameters__box">
                <ul className="extra-info__list parameters__list">
                    <li> <p> Model: </p> <span> { singleData.product_parameter.model } </span> </li>
                    <li> <p> Color: </p> <span> { singleData.product_parameter.color } </span> </li>
                    <li> <p> Wheel Size: </p> <span> { singleData.wheelSize } </span> </li>
                    <li> <p> Max Speed: </p> <span> { singleData.product_parameter.max_speed } </span> </li>
                    <li> <p> Max Range: </p> <span> { singleData.product_parameter.max_range } </span> </li>
                    <li> <p> Battery: </p> <span> { 'parameters.battery' } </span> </li>
                    <li> <p> Motor Type: </p> <span> { singleData.product_parameter.motor_type } </span> </li>
                    <li> <p> Weight: </p> <span> {  singleData.product_parameter.weight } </span> </li>
                    <li> <p> Max Climb Angle: </p> <span> { singleData.product_parameter.max_climb_angle } </span> </li>
                    <li> <p> Max Load: </p> <span> {  singleData.product_parameter.max_load } </span> </li>
                </ul>
            </div>
        </div>
    );
};

export default Parameters;
