import React, { useState, useEffect } from 'react';
import './PhotoAndVideo.scss';
import { useParams } from 'react-router-dom';
import { Carousel } from 'react-carousel-minimal';
import {url} from '../../configs/config'
import axios from 'axios';
import SliderButtons from '../UI/buttons/SliderButtons';



const PhotoAndVideo = () => {


    const [singleDataPV,setSingleDataVP] = useState()
    const params = useParams()
    console.log(params);
    console.log(singleDataPV, '789');
    // console.log(url);

    useEffect(() => {
        axios.get(`${url}/product/single/${params.id}`)
        .then(res => setSingleDataVP(res.data.product))
        .catch(e => console.log(e.message))
    },[])

    const images  = []

    const captionStyle = {
        fontSize: '2em',
        fontWeight: 'bold',
    }
    const slideNumberStyle = {
      fontSize: '20px',
      fontWeight: 'bold',
    }


    singleDataPV?.product_gallery.big_gallery.map(imageUrlPV => (
        images.push({
            image: `${url}/${imageUrlPV.path}`,
            thumbnails: `${url}/${imageUrlPV.path}`
        })
       ))
    console.log(images );

    return (
        <div className="photo-and-video" id='photoVideo'>
            <div className="photo-and-video__slider-actions">
                <h2 className="photo-and-video__title"> Photo and Video </h2>
                <SliderButtons className="new-release__slider-btns" />
            </div>


            {singleDataPV && (
                <Carousel
                    data={images}
                    time={2000}
                    width="100%"
                    //   height="500px"
                    captionStyle={captionStyle}
                    radius="10px"
                    slideNumber={true}
                    slideNumberStyle={slideNumberStyle}
                    captionPosition="bottom"
                    automatic={false}
                    dots={true}
                    pauseIconColor="white"
                    pauseIconSize="40px"
                    slideBackgroundColor="darkgrey"
                    slideImageFit="cover"
                    thumbnails={true}
                    thumbnailWidth="100px"
                    style={{
                        textAlign: "center",
                        // maxWidth: "100%",
                        // maxHeight: "500px",
                        margin: "40px auto",
                    }}
                />
            )}
        </div>
    );
};

export default PhotoAndVideo;
