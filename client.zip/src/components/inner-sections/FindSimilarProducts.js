import React from 'react';
import './FindSimilarProducts.scss';
import { Link } from 'react-router-dom';


const FindSimilarProducts = () => {
    return (
        <div className="find-similar">
            <h2 className="find-similar__title"> Find similar products </h2>
            <div className="find-similar__content">
                <ul className="find-similar__content-list">
                    <li> <Link to="/products"> Gotway Electric Unicycle </Link> </li>
                    <li> <Link to="/products"> All Products </Link> </li>
                    <li> <Link to="/products"> Electric Unicycles </Link> </li>
                </ul>
            </div>
        </div>
    );
};

export default FindSimilarProducts;
