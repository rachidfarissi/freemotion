import React, { useEffect, useState } from 'react';
import FAQItem from '../../items/single-product-page/faqItem/FAQItem';
import './FAQ.scss';
import axios from "axios";


const FAQ = () => {
    // const FAQ_ITEM_TITLE = "Lorem Ipsum is simply dummy text of the";
    // const FAQ_ITEM_TEXT = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also ";

   
    let url = 'https://freemotion-shop-back.herokuapp.com'

    const [data ,setData] = useState([])

    useEffect(() => {
        axios.post(`${url}/faq/list`,{
            "category": [
            "string", "general"
            ]
          })
        .then(res => setData(res.data.faq))
        // .then(res => console.log(res.data.faq))
        .catch(e => console.log(e))
    }, [])

    // console.log(data ,' bbbbbbbbbbbbbbbbbbb')
   
    return (
        <div className="faq" id='faq'>
            <h2 className="faq__title"> Frequently Asked Questions  </h2>
            <div className="faq__content">
                { data && data.map((faq, index) => <FAQItem faq={ faq } key={ faq.id } index={ index } />) }
            </div>
        </div>
    );
};

export default FAQ;
