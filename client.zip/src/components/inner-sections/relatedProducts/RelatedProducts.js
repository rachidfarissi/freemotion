import React , {useState , useEffect} from 'react';
import './RelatedProducts.scss';
import axios from 'axios';
import RelatedProductItem from '../../items/single-product-page/reloadProductItem/RelatedProductItem';

import OWLcorusel from 'react-owl-carousel'
import 'owl.carousel/dist/assets/owl.carousel.min.css'
import 'owl.carousel/dist/assets/owl.theme.default.min.css'



const options = {
    responsive: {
        0: {
            items: 1,
        },
        400: {
            items: 2,
        },
        650: {
            items: 2,
        },
        1000: {
            items: 3,
  
        }
    },
  };
  


const RelatedProducts = () => {


    let url = 'https://freemotion-shop-back.herokuapp.com'

    const [data, setData] = useState([])
    
    useEffect(() => {
        axios.get(`${url}/product/new/release`)
        .then(res => setData(res.data.new_release))
        .catch(e => console.log(e))
    
    },[])

    return (
        <div className="related-products">
            <div className="related-products__slider-actions">
                <h2 className="related-products__title"> Related Products </h2>
            </div>
            <div className="related-products__content">
                { data.length > 0 && <OWLcorusel  items='3'  center autoplayHoverPause dots loop  margin={6}  responsive={options.responsive} >
                    { data.map((product) => <RelatedProductItem  product={ product } key={ product.id } />) }
                </OWLcorusel> }
            </div>
        </div>
    );
};

export default RelatedProducts;
