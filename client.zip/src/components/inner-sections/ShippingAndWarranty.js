import React from 'react';
import './ShippingAndWarranty.css';


const ShippingAndWarranty = () => {
    return (
        <div className="shipping-and-warranty" id='shipping'>
            <h2 className="shipping-and-warranty__title"> { "Shipping & Warranty" } </h2>
            <div className="shipping-and-warranty__content">
                <p className="shipping-and-warranty__content-text">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but
                </p>
            </div>
        </div>
    );
};

export default ShippingAndWarranty;
