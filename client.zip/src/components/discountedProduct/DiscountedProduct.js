import React from 'react'
import './discountedProduct.scss'
import Authorized from './../../assets/images/authorized.png'
import lowestCost from './../../assets/images/lowestCost.png'
import monetBack from './../../assets/images/monetBack.png'
import year from './../../assets/images/year.png'
import { useHistory } from 'react-router'

function DiscountedProducts() {
  const history = useHistory()
  const redirection = (url) => history.push(url)

  return (
    <div className="suggesting-options wrapper">
      <ul className="suggesting-options__list">
        <li onClick={() => redirection('/deals')}>
          <img
            src={Authorized}
            alt="Authorized icon"
            className="suggesting-options__img"
          />
          <div>
            <p className="suggesting-options__subtitle"> AUTHORIZED </p>
            <span className="suggesting-options__text">Distributor/dealer</span>
          </div>
        </li>
        <li onClick={() => redirection('/about-us')}>
          <img
            src={lowestCost}
            alt="lowest Cost icon"
            className="suggesting-options__img"
          />
          <div>
            <p className="suggesting-options__subtitle"> LOWEST COST </p>
            <span className="suggesting-options__text">
              Lowest price guarantee
            </span>
          </div>
        </li>
        <li onClick={() => redirection('/about-us')}>
          <img src={year} alt="yea ion" className="suggesting-options__img" />
          <div>
            <p className="suggesting-options__subtitle"> 1 YEAR </p>
            <span className="suggesting-options__text">
              1 year complete warranty
            </span>
          </div>
        </li>
        <li onClick={() => redirection('/shippingAndReturns')}>
          <img
            src={monetBack}
            alt="monet Back icon"
            className="suggesting-options__img"
          />
          <div>
            <p className="suggesting-options__subtitle"> MONEY BACK </p>
            <span className="suggesting-options__text">Easy free returns</span>
          </div>
        </li>
      </ul>
    </div>
  )
}

export default DiscountedProducts
