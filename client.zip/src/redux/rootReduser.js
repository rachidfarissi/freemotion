import { combineReducers } from 'redux'
import { unicycleReducer } from './unicycleReducer/unicycleReducer'
import { userReducer } from './user/userReducer'

export const rootReducer = combineReducers({
  unicycleReducer,
  user: userReducer,
})
