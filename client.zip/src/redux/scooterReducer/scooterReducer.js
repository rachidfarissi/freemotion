// blackScooterImage

import { navHoverIcons, homeMainImages } from "../../dummy-datas/images"

const initalState = {
    
    scooter: [
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            newPrice: "1930.00",
        },
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            oldPrice: "1930.00",
            newPrice: "1040.00",
        },
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            oldPrice: "1930.00",
            newPrice: "1040.00",
        },
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            newPrice: "1930.00",
        },
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            oldPrice: "1930.00",
            newPrice: "1040.00",
        },
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            oldPrice: "1930.00",
            newPrice: "1040.00",
        },
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            newPrice: "1930.00",
        },
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            oldPrice: "1930.00",
            newPrice: "1040.00",
        },
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            oldPrice: "1930.00",
            newPrice: "1040.00",
        },
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            newPrice: "1930.00",
        },
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            oldPrice: "1930.00",
            newPrice: "1040.00",
        },
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            oldPrice: "1930.00",
            newPrice: "1040.00",
        },
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            newPrice: "1930.00",
        },
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            oldPrice: "1930.00",
            newPrice: "1040.00",
        },
        {
            id: Math.random().toString(),
            image: homeMainImages.blackScooterImage,
            description: "Gotway Monster Pro Electric Unicycle",
            oldPrice: "1930.00",
            newPrice: "1040.00",
        },
    ]
};

export const scooterReducer = (state = initalState, action) => {
    return state;
}