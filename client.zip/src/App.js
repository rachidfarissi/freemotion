import React from 'react'
import './App.css'
import Footer from './components/footer/Footer'
// import Header from './components/sections/Header';
import Main from './components/sections/Main'
import Nav from './components/sections/navbar/Nav'
import { createStore } from 'redux'
import { rootReducer } from './redux/rootReduser'
import { Provider } from 'react-redux'

const store = createStore(rootReducer)

const App = () => {
  return (
    <Provider store={store}>
      <div className="App">
        {/* <Header /> */}
        <Nav />
        <Main />
        <Footer />
      </div>
    </Provider>
  )
}

export default App
